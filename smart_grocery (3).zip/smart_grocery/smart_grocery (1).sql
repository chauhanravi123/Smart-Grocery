-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 09, 2026 at 05:33 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'jay', 'jay@gmail.com', 'Jay@123');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `slug`, `image`, `status`, `created_at`) VALUES
(1, 'Cold drinks & soft drinks', 'cold-drinks-soft-drinks', '1765991585_cold-drinks.jpg', 1, '2025-12-17 17:13:05'),
(3, 'Biscuits & Cookies', 'biscuits-cookies', '1765992237_biscuits-cookies.jpg', 1, '2025-12-17 17:23:57'),
(4, 'Chips & Namkeens', 'chips-namkeens', '1766028778_694375ea5df50.jpg', 1, '2025-12-17 17:24:50'),
(5, 'Chocolates & Candies', 'chocolates-candies', '1769616560_697a34b01f86d.jpg', 1, '2025-12-17 17:25:41'),
(6, 'Indian Sweets', 'Indian-Sweets', '1769616526_697a348ee9f91.jpg', 1, '2025-12-17 17:26:19'),
(8, 'Fresh Fruits & Vegetables', 'fresh-fruits-vegetables', '1771420958_6995bd1e5622e.webp', 1, '2026-02-18 12:59:53'),
(9, 'Atta, Flours & Sooji', 'atta-flours-shoji', '1771430845_atta-flours-sooji-20240621.webp', 1, '2026-02-18 16:07:25'),
(10, 'Dals & Pulsess', 'dals-pulses', '1772714012_69a9781cdea51.webp', 1, '2026-02-24 05:47:06');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'jaydip', 'jaydip@gmail.com', 'delivery related', 'i order with smart_grocery when i get my items', '2025-12-29 05:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boys`
--

CREATE TABLE `delivery_boys` (
  `delivery_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery_boys`
--

INSERT INTO `delivery_boys` (`delivery_id`, `name`, `phone`, `email`, `password`, `status`, `created_at`) VALUES
(1, 'Ravi Kanzariya', '9724682789', 'Ravi@gmail.com', '$2y$10$m04X0df4bfJJQ91wYggjhO9yEdT/UWFu5FH8kibzW.m22bwCmsHj6', 1, '2026-01-07 11:42:31'),
(2, 'Divyang', '9824323465', 'divyang@gmail.com', '$2y$10$Ah08DWkobgBpj0WHZlaNFeysXkClvekc9stYzaN6ORRe1aZHKlysi', 1, '2026-01-07 12:27:32');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `total` decimal(65,2) DEFAULT NULL,
  `collected_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `collected_at` datetime DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','processing','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `address_id` int DEFAULT NULL,
  `delivery_id` int DEFAULT NULL,
  `delivery_status` enum('Pending','Assigned','Out for Pickup','Out for Delivery','Delivered','Undelivered') DEFAULT 'Pending',
  `delivery_otp` varchar(6) DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `delivery_charge` decimal(10,2) DEFAULT '0.00',
  `savings` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `name`, `phone`, `address`, `total`, `collected_amount`, `collected_at`, `payment_method`, `order_date`, `status`, `address_id`, `delivery_id`, `delivery_status`, `delivery_otp`, `delivered_at`, `delivery_charge`, `savings`) VALUES
(1, NULL, 'jaydip', '9824536561', 'Astron chowk,rajkot', 240.00, 240.00, '2026-01-11 10:26:41', NULL, '2025-12-21 04:23:27', 'delivered', NULL, 1, 'Delivered', NULL, '2026-01-11 10:26:41', 0.00, 0.00),
(2, NULL, 'jaydip', '9824536561', 'Astron chowk,rajkot', 240.00, 0.00, NULL, 'Cash', '2025-12-21 04:29:14', 'delivered', NULL, 1, 'Delivered', NULL, '2026-02-18 20:59:04', 0.00, 0.00),
(3, NULL, 'jaydip', '1234567890', 'botad', 120.00, 0.00, NULL, 'Cash', '2025-12-22 05:16:40', 'delivered', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(4, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 40.00, 0.00, NULL, 'Cash', '2025-12-23 03:53:34', 'delivered', NULL, 1, 'Undelivered', NULL, NULL, 0.00, 0.00),
(5, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 0.00, 0.00, NULL, 'Cash', '2025-12-23 04:00:44', 'cancelled', NULL, 1, 'Undelivered', NULL, NULL, 0.00, 0.00),
(6, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 40.00, 0.00, NULL, 'Cash', '2025-12-23 04:08:14', 'delivered', NULL, 2, 'Delivered', NULL, '2026-02-18 20:56:56', 0.00, 0.00),
(7, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 0.00, 0.00, NULL, NULL, '2025-12-23 04:13:10', 'cancelled', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(8, NULL, 'ravi', '1234567889', 'rajkot', 12630.00, 0.00, NULL, 'Prepaid', '2025-12-23 05:12:16', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(9, NULL, 'jaydip', '1234567890', 'botad', 40.00, 0.00, NULL, NULL, '2025-12-29 05:44:27', 'delivered', NULL, 2, 'Delivered', NULL, '2026-01-08 17:47:16', 0.00, 0.00),
(10, NULL, 'jay', '9824234526', 'near k.k.v hall, kalavad road, rajkot.', 1136.00, 1136.00, '2026-02-18 20:57:14', '0', '2025-12-30 04:08:19', 'pending', NULL, 1, 'Assigned', NULL, '2026-02-18 20:57:14', 0.00, 0.00),
(11, NULL, 'jay', '9824234526', 'Bapa sitaram chowk, Raiya road ,Rajkot.', 10.00, 0.00, NULL, NULL, '2025-12-30 04:17:03', 'pending', NULL, NULL, 'Assigned', NULL, NULL, 0.00, 0.00),
(12, 3, 'jay', '9824234526', 'Dhakaniya Road,Botad ,Gujrat', 40.00, 0.00, NULL, NULL, '2025-12-30 04:25:18', 'pending', NULL, NULL, 'Assigned', NULL, NULL, 0.00, 0.00),
(13, 5, 'Ashish', '9157230155', '', 312.00, 0.00, NULL, NULL, '2026-01-06 06:04:52', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL, 0.00, 0.00),
(14, 3, 'Ashish', '9157230155', '', 10.00, 0.00, NULL, NULL, '2026-01-06 06:27:34', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL, 0.00, 0.00),
(15, 3, 'Ashish', '9157230155', 'Hanuman Madhi, Raiya Road, Rajkot                                , Rajkot - 360007', 150.00, 0.00, NULL, NULL, '2026-01-06 06:40:21', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-07 18:23:12', 0.00, 0.00),
(16, 3, 'Ashish Parmar', '9157230156', 'Hanuman Madhi, Raiya Road, Rajkot                                , Rajkot - 360007', 312.00, 312.00, '2026-01-11 10:41:06', '0', '2026-01-06 06:42:04', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-11 10:41:06', 0.00, 0.00),
(17, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 190.00, 0.00, NULL, 'Cash', '2026-01-11 05:07:58', 'pending', NULL, 2, 'Assigned', NULL, NULL, 0.00, 0.00),
(18, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 80.00, 80.00, '2026-01-27 22:02:51', '0', '2026-01-27 06:00:32', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-27 22:02:51', 0.00, 0.00),
(19, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 346.00, 346.00, '2026-01-27 22:03:31', '0', '2026-01-27 16:25:30', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-27 22:03:31', 0.00, 0.00),
(20, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 90.00, 90.00, '2026-01-28 22:02:08', '0', '2026-01-28 16:00:32', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-28 22:02:08', 0.00, 0.00),
(21, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 564.00, 0.00, NULL, NULL, '2026-01-29 12:08:28', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(22, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 10.00, 0.00, NULL, NULL, '2026-01-29 12:14:53', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(23, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 92.00, 0.00, NULL, NULL, '2026-01-29 12:26:51', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(24, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 175.00, 0.00, NULL, NULL, '2026-01-29 12:27:16', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(25, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:29:29', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(26, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:29:57', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(27, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:30:08', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(28, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:30:42', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(29, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:32:24', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(30, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:34:24', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(31, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:35:18', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(32, 1, 'mahesh', '7019693154', 'Dhakaniya Road,Rajkot ,Gujrat, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-01-29 12:35:26', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(33, 1, 'bhavik', '09876543212', 'k.k.v hall, 150 feet ring road, rajkot, Rajkot - 360002', 249.00, 0.00, NULL, 'Cash', '2026-01-29 12:38:42', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-29 18:21:05', 0.00, 0.00),
(34, 1, 'bhavik', '09876543212', 'k.k.v hall, 150 feet ring road, rajkot, Rajkot - 360002', 78.00, 78.00, '2026-01-29 18:16:38', '0', '2026-01-29 12:42:33', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-29 18:16:38', 0.00, 0.00),
(35, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 45.00, 0.00, NULL, NULL, '2026-02-03 06:26:24', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(36, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 146.00, 0.00, NULL, NULL, '2026-02-06 11:35:54', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(37, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 50.00, 0.00, NULL, NULL, '2026-02-06 11:36:26', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(38, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 234.00, 0.00, NULL, NULL, '2026-02-06 11:37:41', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(39, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1560.00, 0.00, NULL, NULL, '2026-02-06 11:45:34', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(40, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 180.00, 0.00, NULL, NULL, '2026-02-06 11:49:15', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(41, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 2412.00, 0.00, NULL, NULL, '2026-02-06 11:57:34', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(42, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 541.00, 0.00, NULL, 'COD', '2026-02-06 12:54:05', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 102.00),
(43, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 331.00, 0.00, NULL, 'COD', '2026-02-06 12:54:56', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 59.00),
(44, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 101.00, 0.00, NULL, 'COD', '2026-02-06 13:10:31', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 8.00),
(49, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1788.00, 1788.00, '2026-02-15 08:49:23', '0', '2026-02-15 02:53:45', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-15 08:49:23', 0.00, 0.00),
(50, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 51.00, 51.00, '2026-02-15 08:49:37', '0', '2026-02-15 02:55:45', 'pending', NULL, 1, 'Assigned', NULL, '2026-02-15 08:49:37', 0.00, 0.00),
(51, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 9.00, 0.00, NULL, 'Cash', '2026-02-15 02:57:27', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(52, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 294.00, 294.00, '2026-02-18 20:49:16', '0', '2026-02-16 11:57:41', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:49:16', 0.00, 0.00),
(53, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 40.00, 0.00, NULL, NULL, '2026-02-16 11:58:48', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(54, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 744.00, 744.00, '2026-02-18 20:49:33', '0', '2026-02-16 12:13:39', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:49:33', 0.00, 0.00),
(55, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 329.00, 0.00, NULL, NULL, '2026-02-16 12:15:21', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(57, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 40.00, 40.00, '2026-02-18 20:55:26', '0', '2026-02-16 12:16:20', 'pending', NULL, 2, 'Assigned', NULL, '2026-02-18 20:55:26', 0.00, 0.00),
(69, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 0.00, 0.00, NULL, 'Cash', '2026-02-16 12:56:06', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(70, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1245.00, 0.00, NULL, 'Prepaid', '2026-02-16 12:56:06', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(71, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1473.00, 0.00, NULL, NULL, '2026-02-16 12:56:06', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(72, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1971.00, 0.00, NULL, 'UPI', '2026-02-16 12:56:06', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(73, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 2211.00, 0.00, NULL, 'Cash', '2026-02-16 12:56:06', 'pending', NULL, 1, 'Assigned', NULL, '2026-02-18 20:56:17', 0.00, 0.00),
(74, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 2229.00, 2229.00, '2026-02-18 20:56:01', '0', '2026-02-16 12:56:06', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:56:01', 0.00, 0.00),
(75, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 0.00, 0.00, NULL, NULL, '2026-02-16 13:28:27', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(76, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 45.00, 0.00, NULL, NULL, '2026-02-16 13:28:27', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(77, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 0.00, 0.00, NULL, NULL, '2026-02-16 13:49:26', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(78, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 228.00, 0.00, NULL, 'Cash', '2026-02-16 13:49:26', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:54:58', 0.00, 0.00),
(79, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 0.00, 0.00, NULL, NULL, '2026-02-16 14:46:02', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(80, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 0.00, 0.00, NULL, 'Cash', '2026-02-16 14:47:35', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(81, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 132.00, 132.00, '2026-02-18 20:53:49', '0', '2026-02-16 15:09:21', 'pending', NULL, 2, 'Assigned', NULL, '2026-02-18 20:53:49', 0.00, 0.00),
(82, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1076.00, 0.00, NULL, NULL, '2026-02-16 15:11:40', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(83, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 560.00, 560.00, '2026-02-18 20:53:30', '0', '2026-02-16 16:05:16', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:53:30', 0.00, 0.00),
(84, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 476.00, 0.00, NULL, NULL, '2026-02-16 16:15:17', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(85, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 9.00, 0.00, NULL, 'Cash', '2026-02-16 16:15:48', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(86, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1191.00, 0.00, NULL, NULL, '2026-02-16 16:23:49', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(87, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 249.00, 249.00, '2026-02-18 20:50:22', '0', '2026-02-16 16:27:22', 'pending', NULL, 1, 'Assigned', NULL, '2026-02-18 20:50:22', 0.00, 0.00),
(88, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 120.00, 0.00, NULL, NULL, '2026-02-16 16:35:37', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(89, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 40.00, 40.00, '2026-02-18 20:50:08', '0', '2026-02-16 16:36:46', 'pending', NULL, 2, 'Delivered', NULL, '2026-02-18 20:50:08', 0.00, 0.00),
(90, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 870.00, 0.00, NULL, NULL, '2026-02-18 12:28:59', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(91, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 1617.00, 0.00, NULL, 'Cash', '2026-02-18 12:43:24', 'pending', NULL, 1, 'Assigned', NULL, '2026-02-18 20:49:49', 0.00, 0.00),
(92, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 9.00, 0.00, NULL, NULL, '2026-02-24 05:33:40', 'pending', NULL, 2, 'Assigned', NULL, NULL, 0.00, 0.00),
(93, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 240.00, 0.00, NULL, NULL, '2026-03-07 06:08:42', 'pending', NULL, 1, 'Assigned', NULL, NULL, 0.00, 0.00),
(94, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 783.00, 783.00, '2026-03-09 10:49:11', '0', '2026-03-09 05:12:09', 'pending', NULL, 1, 'Delivered', NULL, '2026-03-09 10:49:11', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `image`, `price`) VALUES
(1, 1, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(2, 1, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(3, 1, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(4, 2, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(5, 2, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(6, 2, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(7, 3, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(8, 3, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(9, 4, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(10, 6, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(11, 8, 1, 113, '1766033094_694386c65fc7f.webp', 110.00),
(12, 8, 6, 5, '1766288712_69476d489e474.webp', 40.00),
(13, 9, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(14, 10, 2, 11, '1766056873_6943e3a9cf140.webp', 78.00),
(15, 10, 3, 1, '1766057140_6943e4b4e6bc3.webp', 78.00),
(16, 10, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(17, 10, 7, 4, '1766288857_69476dd90acd6.webp', 40.00),
(18, 11, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(19, 12, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(20, 13, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(21, 14, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(22, 15, 4, 3, '1766057257_6943e529a6625.webp', 10.00),
(23, 15, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(24, 15, 6, 2, '1766288712_69476d489e474.webp', 40.00),
(25, 16, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(26, 17, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(27, 17, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(28, 17, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(29, 18, 6, 1, '1768109318_products1766288712_69476d489e474.webp', 40.00),
(30, 18, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(31, 19, 6, 1, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(32, 19, 3, 2, '1766057140_6943e4b4e6bc3.webp', 78.00),
(33, 19, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(34, 19, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(35, 20, 10, 2, '', 45.00),
(36, 21, 6, 1, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(37, 21, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(38, 21, 14, 1, '1769528114_balaji-simply-salted-potato-wafers-135-g-product-images-o490025528-p490025528-0-202411131812.webp', 38.00),
(39, 21, 13, 1, '', 42.00),
(40, 21, 10, 1, '', 45.00),
(41, 21, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(42, 21, 16, 1, '', 249.00),
(43, 23, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(44, 23, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(45, 23, 13, 1, '', 42.00),
(46, 24, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(47, 24, 3, 1, '1766057140_6943e4b4e6bc3.webp', 78.00),
(48, 24, 10, 1, '', 45.00),
(49, 24, 13, 1, '', 42.00),
(50, 32, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(51, 33, 16, 1, '', 249.00),
(52, 34, 3, 1, '1769530775_6978e597bba20.webp', 78.00),
(53, 35, 10, 1, '1769530715_6978e55b52951.jpg', 45.00),
(54, 36, 4, 3, '1769530757_6978e5850dadb.webp', 10.00),
(55, 36, 14, 1, '1769530680_6978e53868232.webp', 38.00),
(56, 36, 3, 1, '1769530775_6978e597bba20.webp', 78.00),
(57, 37, 4, 5, '1769530757_6978e5850dadb.webp', 10.00),
(58, 38, 3, 3, '1769530775_6978e597bba20.webp', 78.00),
(59, 39, 3, 20, '1769530775_6978e597bba20.webp', 78.00),
(60, 40, 4, 18, '1769530757_6978e5850dadb.webp', 10.00),
(61, 41, 4, 6, '1769530757_6978e5850dadb.webp', 10.00),
(62, 41, 3, 5, '1769530775_6978e597bba20.webp', 78.00),
(63, 41, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(64, 41, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(65, 41, 16, 6, '1769529049_6978ded90c84b.webp', 249.00),
(66, 42, 1, 1, '1769530805_6978e5b558012.webp', 115.00),
(67, 42, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(68, 42, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(69, 42, 4, 1, '1769530757_6978e5850dadb.webp', 9.00),
(70, 42, 10, 1, '1769530715_6978e55b52951.jpg', 45.00),
(71, 42, 16, 1, '1769529049_6978ded90c84b.webp', 249.00),
(72, 43, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(73, 43, 13, 1, '1769530701_6978e54d39c17.webp', 42.00),
(74, 43, 16, 1, '1769529049_6978ded90c84b.webp', 249.00),
(75, 49, 16, 6, '', 249.00),
(76, 49, 4, 6, '1766057257_6943e529a6625.webp', 9.00),
(77, 49, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(78, 50, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(79, 50, 13, 1, '', 42.00),
(80, 51, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(81, 52, 4, 6, '1766057257_6943e529a6625.webp', 9.00),
(82, 52, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(83, 53, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(84, 74, 16, 5, '1769529049_6978ded90c84b.webp', 249.00),
(85, 74, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(86, 74, 3, 6, '1769530775_6978e597bba20.webp', 83.00),
(87, 74, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(88, 74, 4, 2, '1769530757_6978e5850dadb.webp', 9.00),
(89, 74, 6, 6, '1769530728_6978e568b9171.webp', 40.00),
(90, 76, 4, 5, '1769530757_6978e5850dadb.webp', 9.00),
(91, 76, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(92, 78, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(93, 78, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(94, 79, 3, 2, '1769530775_6978e597bba20.webp', 83.00),
(95, 80, 14, 1, '1769530680_6978e53868232.webp', 38.00),
(96, 81, 4, 1, '1769530757_6978e5850dadb.webp', 9.00),
(97, 81, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(98, 81, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(99, 82, 1, 6, '1766033094_694386c65fc7f.webp', 115.00),
(100, 82, 3, 4, '1766057140_6943e4b4e6bc3.webp', 83.00),
(101, 82, 4, 6, '1766057257_6943e529a6625.webp', 9.00),
(102, 83, 5, 14, '1766288607_69476cdfd88b6.webp', 40.00),
(103, 84, 4, 4, '1766057257_6943e529a6625.webp', 9.00),
(104, 84, 5, 11, '1766288607_69476cdfd88b6.webp', 40.00),
(105, 85, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(106, 86, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(107, 86, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(108, 86, 13, 6, '', 42.00),
(109, 86, 1, 6, '1766033094_694386c65fc7f.webp', 115.00),
(110, 87, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(111, 87, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(112, 88, 6, 3, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(113, 89, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(114, 90, 3, 1, '1766057140_6943e4b4e6bc3.webp', 83.00),
(115, 90, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(116, 90, 16, 3, '', 249.00),
(117, 91, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(118, 91, 3, 1, '1766057140_6943e4b4e6bc3.webp', 83.00),
(119, 91, 16, 6, '', 249.00),
(120, 92, 4, 1, '1766057257_6943e529a6625.webp', 9.00),
(121, 93, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(122, 94, 4, 4, '1766057257_6943e529a6625.webp', 9.00),
(123, 94, 16, 3, '', 249.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_updates`
--

CREATE TABLE `order_updates` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `delivery_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collected_amount` decimal(10,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_updates`
--

INSERT INTO `order_updates` (`id`, `order_id`, `delivery_status`, `payment_method`, `collected_amount`, `created_at`) VALUES
(1, 17, 'Out for Pickup', 'Cash', 190.00, '2026-01-11 10:51:59'),
(2, 18, 'Assigned', 'Cash', 80.00, '2026-01-27 22:02:31'),
(3, 18, 'Delivered', 'Cash', 80.00, '2026-01-27 22:02:51'),
(4, 19, 'Delivered', 'Cash', 346.00, '2026-01-27 22:03:31'),
(5, 20, 'Out for Pickup', 'Cash', 90.00, '2026-01-28 22:01:48'),
(6, 20, 'Delivered', 'Cash', 90.00, '2026-01-28 22:02:08'),
(7, 34, 'Out for Delivery', 'UPI', 78.00, '2026-01-29 18:15:54'),
(8, 34, 'Delivered', 'Cash', 78.00, '2026-01-29 18:16:38'),
(9, 33, 'Delivered', 'Cash', 0.00, '2026-01-29 18:21:05'),
(10, 49, 'Delivered', 'Cash', 1788.00, '2026-02-15 08:49:23'),
(11, 50, 'Delivered', 'Cash', 51.00, '2026-02-15 08:49:37'),
(12, 51, 'Undelivered', 'Cash', 9.00, '2026-02-15 08:49:50'),
(13, 52, 'Delivered', 'Cash', 294.00, '2026-02-18 20:49:16'),
(14, 54, 'Delivered', 'Cash', 744.00, '2026-02-18 20:49:33'),
(15, 91, 'Delivered', 'Cash', 0.00, '2026-02-18 20:49:49'),
(16, 89, 'Delivered', 'Cash', 40.00, '2026-02-18 20:50:08'),
(17, 87, 'Delivered', 'Cash', 249.00, '2026-02-18 20:50:22'),
(18, 85, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:50:42'),
(19, 83, 'Delivered', 'Cash', 560.00, '2026-02-18 20:53:30'),
(20, 81, 'Delivered', 'Cash', 132.00, '2026-02-18 20:53:49'),
(21, 80, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:54:13'),
(22, 78, 'Delivered', 'Cash', 0.00, '2026-02-18 20:54:58'),
(23, 57, 'Delivered', 'Cash', 40.00, '2026-02-18 20:55:26'),
(24, 69, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:55:42'),
(25, 74, 'Delivered', 'Cash', 2229.00, '2026-02-18 20:56:01'),
(26, 73, 'Delivered', 'Cash', 0.00, '2026-02-18 20:56:17'),
(27, 3, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:56:41'),
(28, 6, 'Delivered', 'Cash', 0.00, '2026-02-18 20:56:56'),
(29, 10, 'Delivered', 'Cash', 1136.00, '2026-02-18 20:57:14'),
(30, 72, 'Undelivered', 'UPI', 0.00, '2026-02-18 20:57:31'),
(31, 70, 'Undelivered', 'Prepaid', 0.00, '2026-02-18 20:57:47'),
(32, 8, 'Undelivered', 'Prepaid', 0.00, '2026-02-18 20:58:28'),
(33, 2, 'Delivered', 'Cash', 0.00, '2026-02-18 20:59:04'),
(34, 4, 'Undelivered', 'Cash', 40.00, '2026-03-09 10:46:12'),
(35, 5, 'Undelivered', 'Cash', 0.00, '2026-03-09 10:47:04'),
(36, 94, 'Out for Pickup', 'Cash', 783.00, '2026-03-09 10:47:56'),
(37, 94, 'Delivered', 'Cash', 783.00, '2026-03-09 10:49:11');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `mrp` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock_qty` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `status` tinyint DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `product_name`, `short_description`, `price`, `mrp`, `stock_qty`, `image`, `description`, `status`) VALUES
(1, 3, 'Parle-g gold Biscuits-1kg', 'Parle-g gold Biscuits-1kg', 115.00, 149.00, 100, '1766033094_694386c65fc7f.webp', 'General Information\r\nBrand	Parle-G\r\nManufacturer	Parle Products Pvt. Ltd.\r\nManufacturer Address	\r\nAnand Food Products\r\n16-1-486 Saidabad, Haderabad, 500059\r\n\r\nManufacturer Email	cs@parle.biz\r\nManufacturer Website	www.parleproducts.com\r\nSold By	Reliance Retail\r\nJioMart Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	56.25 g\r\nProduct Type	Glucose Biscuits\r\nUsage Details\r\nFood Preference	Vegetarian\r\nAllergens Included	Wheat\r\nProduct Specifications\r\nProduct Type	Glucose & Milk Biscuits\r\nItem Dimensions\r\nHeight	260 mm\r\nLength	40 mm\r\nWidth	210 mm\r\nNet Quantity	1 kg', 1),
(4, 3, 'Oreo cream Biscuits', 'Oreo cream Biscuits', 9.00, 10.00, 0, '1766057257_6943e529a6625.webp', 'Food Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	41.75 g\r\nProduct Type	Cream Biscuits\r\nUsage Details\r\nNutrient Content	Wheat\r\nProduct Specifications\r\nProduct Type	Cream Biscuits & Wafers\r\nItem Dimensions\r\nHeight	45 mm\r\nLength	45 mm\r\nWidth	85 mm\r\nNet Quantity	1 N', 1),
(5, 1, 'Thums-up 750ml', 'Thums-up 750ml', 40.00, 45.00, 65, '1766288607_69476cdfd88b6.webp', 'Delight your guests with Thums Up. It is the perfect drink for any weather. Gatherings are incomplete without it. One glass is never enough! So go ahead buy this product online today.\r\nDisclaimer:\r\nDespite our attempts to provide you with the most accurate information possible, the actual packaging, ingredients and colour of the product may sometimes vary. Please read the label, directions and warnings carefully before use.\r\n\r\nProduct Information\r\nGeneral Information\r\nBrand	Thums Up\r\nManufacturer	Coca-Cola India Pvt. Ltd.\r\nManufacturer Address	\r\nHindustan Coca Cola Beverages Pvt Ltd\r\nPlot No 18, Bidadi Industrial Area, Bidadi Hobli, Bangalore Rural, Karnataka - 562109\r\n\r\nManufacturer Email	indiahelpline@coca-cola.com', 1),
(6, 1, 'Sprite 750ml', 'Sprite 750ml', 40.00, 45.00, 92, '1769493812_products1766288712_69476d489e474.webp', 'Product Information\r\nGeneral Information\r\nBrand	Sprite\r\nManufacturer	Coca-Cola India Pvt. Ltd.\r\nManufacturer Address	\r\nHindustan Coca Cola Beverages Pvt Ltd\r\nPlot No 18, Bidadi Industrial Area, Bidadi Hobli, Bangalore Rural, Karnataka - 562109\r\n\r\nCoca Cola Pvt Ltd\r\nGurgaon, Haryana, India - 122008\r\n\r\nManufacturer Email	indiahelpline@coca-cola.com\r\nManufacturer Website	www.coca-cola.com\r\nSold By	Reliance Retail\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	750 ml\r\nProduct Type	Other Drinks\r\nUsage Details\r\nFood Preference	Vegetarian\r\nPack Of	1\r\nProduct Specifications\r\nProduct Type	Cold Drinks\r\nItem Dimensions\r\nHeight	200 mm\r\nLength	75 mm\r\nWidth	75 mm\r\nNet Quantity	1 N', 1),
(10, 5, ' Cadbury Dairy Milk Fruit & Nut Chocolate Bar 36 g ', 'Product Type	Chocolates Item Dimensions Height	96 mm Length	47 mm Width	10 mm Net Quantity	36 g', 45.00, 49.00, 49, NULL, 'General Information\r\nBrand	Cadbury\r\nManufacturer	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	\r\nMondelez India Foods Pvt. Ltd\r\nMondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\n\r\nSold By	Smart Grocery\r\nJioMart Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	Mondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\nProduct Details\r\nNet Quantity	80 g\r\nUsage Details\r\nProduct Type	Other Chocolates', 1),
(13, 4, 'Balaji wafers Farali Chevdo 235 g', 'Balaji wafers Farali Chevdo 235 g', 42.00, 45.00, 49, NULL, 'Farali Chevdo 235 g.', 1),
(14, 4, 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g', 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g', 38.00, 40.00, 30, '1769528114_balaji-simply-salted-potato-wafers-135-g-product-images-o490025528-p490025528-0-202411131812.webp', 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g\r\n', 1),
(16, 6, 'Haldiram Mini Kaju Katli 250gm', 'Haldiram Mini Kaju Katli 250gm', 249.00, 300.00, 0, NULL, 'Haldiram Mini Kaju Katli 250gm', 1),
(17, 8, 'Orange 1 kg', 'Orange 1 kg', 50.00, 70.00, 15, NULL, 'Kinoo is a hybrid of two citrus cultivators, \'King\' and \'Willow Leaf\'. It is often pronounced as Kinoo or Kinu, and has an exceptionally sweet taste. The tree of this mandarin is high yield, with the size of an orange, but juicier than that of an orange. Kinoo Oranges can be made into jams, marmalades, and preserves with the addition of sugar. They may also be used in salads, desserts, ice creams, sorbets, and savoury dishes. So, go ahead, buy Kinoo Orange 1 kg online now! Sold By Smart Grocery', 1),
(18, 10, 'Tuver Dal', '', 110.00, 150.00, 25, NULL, 'Tuver Dal 1-kg, Manufacture by Good Life P ltd, Sold By Smart Grocery Store', 1),
(19, 9, 'Good Life Besan - 500g', '', 50.00, 55.00, 21, NULL, 'Made from Premium Quality Chana Dal for authentic taste and aroma\r\nFinely Ground Texture ensures smooth batter and perfect consistency\r\nIdeal for Multiple Recipes like pakoras, dhokla, kadhi, laddoos and cheela\r\nRich in Protein & Fibre supporting a balanced diet\r\nNaturally Gluten-Free suitable for gluten-sensitive diets', 1),
(21, 4, 'Gopal Bhavnagari Gathiya-500g', 'Gopal Bhavnagari Gathiya-500g', 80.00, 84.00, 25, NULL, '\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\n\r\nAdd to Cart\r\nGopal\r\nGopal Namkeen Bhavnagari Gathiya 500 g\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n1247\r\n\r\n₹79.00\r\n5% Off\r\nM.R.P: ₹84.00 (Incl. of all taxes)\r\nPluxee\r\nT&C Apply\r\nOffers (21)\r\n\r\nBANK OFFERS\r\nGet 5% Cashback in JioMart Wallet on using Reliance SBI Co-Branded Credit Card\r\n17 Offer/s Available\r\n\r\n\r\nCOUPONS\r\nGet Rs. 75 Off on Rs.399\r\n4 Offer/s Available\r\n\r\nView All\r\nDeliver to\r\n360007 Rajkot\r\n\r\n\r\nIn Stock\r\nQuick Delivery\r\nSold by\r\nReliance Retail\r\nFeatures & Details\r\nAuthentic Gujarati Taste - Traditional Bhavnagari Gathiya recipe for a homely and nostalgic flavor.\r\nCrispy & Flavorful - Light, crunchy texture with balanced spice for an enjoyable snack experience.\r\nMade with Premium Ingredients - Carefully selected gram flour and spices ensure consistent quality.\r\nPerfect Tea-Time Snack - Complements your chai or coffee beautifully.\r\nHygienically Packed - Processed and packed under strict hygiene standards to retain freshness and flavor.\r\nVegetarian Product - Pure vegetarian and suitable for all age groups.\r\nDescription\r\nExperience the rich flavors of Gujarat with Gopal\'s Bhavnagari Gathiya, a classic namkeen snack from the state. Made with precision and care, these crunchy farsan bits are perfect for munching on throughout the day. The authentic recipe and traditional cooking methods ensure that every bite is bursting with flavor. Gopal\'s Bhavnagari Gathiya has a distinct taste and texture that will leave you wanting more. The combination of spices and seasonings creates an addictive flavor profile that will make you go back for seconds, thirds, and more! Whether you\'re enjoying it as a snack on its own or paired with tea or chutney, this namkeen is sure to satisfy your cravings. Gopal\'s commitment to quality and tradition shines through in every pack of Bhavnagari Gathiya. With its perfect balance of spices, crunchiness, and flavor, this namkeen is a must-try for anyone who loves Gujarati cuisine. So go ahead, indulge in the delicious taste of Gujarat with Gopal\'s Bhavnagari Gathiya! So what are you waiting for? Go ahead and buy this product online today!\r\nDisclaimer:\r\nDespite our attempts to provide you with the most accurate information possible, the actual packaging, material, ingredients, and colour of the product may sometimes vary. Please read the label, directions, and warnings carefully before use.\r\n\r\nLess Details\r\nProduct Information\r\nGeneral Information\r\nBrand	Gopal\r\nManufacturer	Gopal Snacks Pvt. Ltd.,\r\nManufacturer Address	\r\nGopal Snacks Pvt. Ltd.,\r\nG-2, Survey No. 435/1A, 432, Pawaddauna Road, NH-6, Village Mouda, Nagpur, 441104  ,\r\nSold By Smart Grocery Store', 1),
(23, 3, 'Parle-g original gluose biscuits', '', 80.00, 90.00, 25, NULL, 'Parle-g original glucose Biscuit 800-g.', 1),
(30, 1, 'Fanta 2.25ltr', 'Fanta 2.25Ltr', 80.00, 100.00, 25, NULL, 'Fanta Orange 2.25Ltr Sold By Smart Grocery', 1),
(31, 1, 'Fanta 750ml', 'Fanta 750Ml', 30.00, 40.00, 23, NULL, 'Fanta Orange 750Ml Sold By Smart Grocery', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `image_id` int NOT NULL,
  `product_id` int NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`image_id`, `product_id`, `image`, `created_at`) VALUES
(1, 16, '1769529049_6978ded90c84b.webp', '2026-01-27 15:50:49'),
(3, 14, '1769530680_6978e53868232.webp', '2026-01-27 16:18:00'),
(4, 13, '1769530701_6978e54d39c17.webp', '2026-01-27 16:18:21'),
(5, 10, '1769530715_6978e55b52951.jpg', '2026-01-27 16:18:35'),
(6, 6, '1769530728_6978e568b9171.webp', '2026-01-27 16:18:48'),
(7, 5, '1769530741_6978e575b6ace.webp', '2026-01-27 16:19:01'),
(8, 4, '1769530757_6978e5850dadb.webp', '2026-01-27 16:19:17'),
(10, 1, '1769530805_6978e5b558012.webp', '2026-01-27 16:20:05'),
(11, 1, '1769616610_697a34e2c224e.webp', '2026-01-28 16:10:10'),
(12, 17, '1771419807_6995b89fb4285.webp', '2026-02-18 13:03:27'),
(13, 18, '1771912313_699d3c796959c.webp', '2026-02-24 05:51:53'),
(14, 19, '1772096774_69a00d061ce80.webp', '2026-02-26 09:06:14'),
(15, 21, '1772101263_69a01e8fb6c42.webp', '2026-02-26 10:21:03'),
(17, 23, '1772709269_69a96595c850d.webp', '2026-03-05 11:14:29'),
(24, 30, '1772855566_69aba10e02641.webp', '2026-03-07 03:52:46'),
(25, 31, '1772859016_69abae8852668.webp', '2026-03-07 04:50:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `phone`, `email`, `password`, `role`, `address`, `city`, `pincode`) VALUES
(1, 'Bhavik', '8975234526', 'bhavik@gmail.com', '$2y$10$WYWKzjMgPrqZfgAEmtdAoOdTem5V0M8XoNY0THRX.ii5tSMzda.MC', 'user', NULL, NULL, NULL),
(2, 'jaydip', '9823467542', 'jaydip@gmail.com', '$2y$10$UHOe/p/oN7Gc2lGk6bbwYOs35Q4TYbgBCeNR.lr/Tj3wnhh4FHzfG', 'user', 'mavdi chokdi, 150-feet ring road, rajkot', 'rajkot', '360005'),
(3, 'jay', '1234567889', 'jay@gmail.com', '$2y$10$euy33MUKamItXLHkxzlvjOjA/ZkuvQY0gHm6SkgUXngZEN3S91lBC', 'user', 'Hanuman Madhi, Raiya Road, Rajkot', 'Rajkot', '360007'),
(4, 'chetan', '9878234569', 'chetan@gmail.com', '$2y$10$Qgm/FsLKpYYjjVQKrzPIl.JrrELzfjkJWJ/bt1jKUDbsoNR8slvIa', 'user', NULL, NULL, NULL),
(5, 'Ashish', '9157230155', 'Ashish@gmail.com', '$2y$10$NoUdHQFAIj1w/wGKVHuH5e9sg9z4JwlXwADUBNs8gB0yHhvfnnBjS', 'user', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `address_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `is_default` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`address_id`, `user_id`, `name`, `phone`, `address`, `city`, `pincode`, `is_default`, `created_at`) VALUES
(1, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot', 'Rajkot', '360007', 0, '2026-01-06 06:03:00'),
(2, 3, 'Ashish Parmar', '9157230156', 'Hanuman Madhi, Raiya Road, Rajkot                                ', 'Rajkot', '360007', 0, '2026-01-06 06:39:43'),
(3, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot', 'Rajkot', '360002', 1, '2026-01-06 11:15:07'),
(6, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot', 'Rajkot', '360002', 0, '2026-01-29 12:37:12'),
(7, 1, 'bhavik', '09876543212', 'k.k.v hall, 150 feet ring road, rajkot', 'Rajkot', '360002', 0, '2026-01-29 12:38:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `fk_orders_users` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_updates`
--
ALTER TABLE `order_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_category` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  MODIFY `delivery_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `order_updates`
--
ALTER TABLE `order_updates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `image_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `address_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_orders_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
