<?php
include_once 'admin_auth.php';
include_once '../includes/db.php';


/* Categories */
$totalcategories = $conn->query("SELECT COUNT(*) AS total FROM categories")->fetch_assoc()['total'] ?? 0;

/* Products */
$totalproducts = $conn->query("SELECT COUNT(*) AS total FROM products")->fetch_assoc()['total'] ?? 0;
/* Recent Orders */
$recentOrders = $conn->query("SELECT order_id, name, total, status, order_date FROM orders ORDER BY order_id DESC LIMIT 5");

// Orders Today
$ordersToday = (int) ($conn->query("SELECT COUNT(*) AS total FROM orders WHERE DATE(order_date)=CURDATE()")->fetch_assoc()['total'] ?? 0);

// Average Order Value
$totalrevenue = $conn->query("SELECT SUM(total) AS revenue FROM orders WHERE status='Delivered'")->fetch_assoc()['revenue'] ?? 0;
$totalorders = $conn->query("SELECT COUNT(*) AS total FROM orders")->fetch_assoc()['total'] ?? 0;
$avgOrderValue = $totalorders ? round($totalrevenue / max(1, $totalorders), 2) : 0;

// Other counts
$pendingorders = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE LOWER(TRIM(status)) = 'pending'")->fetch_assoc()['total'] ?? 0;
$processingorders = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='processing'")->fetch_assoc()['total'] ?? 0;
$deliveredorders = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='Delivered'")->fetch_assoc()['total'] ?? 0;
$cancelledorders = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='Cancelled'")->fetch_assoc()['total'] ?? 0;
$totalcustomer = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role='user'")->fetch_assoc()['total'] ?? 0;
$deliveryboys = $conn->query("SELECT COUNT(*) AS total FROM delivery_boys WHERE status=1")->fetch_assoc()['total'] ?? 0;

// Sales data for last 7 days
/*$revenueRows = $conn->query("
    SELECT DATE(order_date) AS d, SUM(total) AS revenue
    FROM orders
    WHERE status='Delivered'
    AND DATE(order_date) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(order_date)
    ORDER BY d ASC
");*/


/*$labels = [];
$data = [];
$map = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $labels[] = date('d M', strtotime($date));
    $map[$date] = 0;
}
if ($revenueRows) {
    while ($r = $revenueRows->fetch_assoc()) {
        $map[$r['d']] = (float)$r['revenue'];
    }
}
foreach ($labels as $index => $label) {
    $dateKey = date('Y-m-d', strtotime("-" . (6 - $index) . " days"));
    $data[] = $map[$dateKey] ?? 0;
}


$jsonLabels = json_encode($labels);
$jsonData = json_encode($data);
*/
?>
<!--<style>
    /* Chart Card */
    .chart-card {
        width: 100%;
        min-height: 380px;
        padding: 20px;
    }

    /* Chart Container */
    .chart-container {
        position: relative;
        width: 100%;
        height: 320px;
        /* Perfect dashboard height */
    }

    /* Canvas Full Size */
    .chart-container canvas {
        width: 100% !important;
        height: 100% !important;
    }
</style>-->
<main class="dashboard-page" style="padding:18px;">

    <div class="cards">
        <div class="card">
            <h3>Categories</h3>
            <p class="value"><span class="count" data-target="<?php echo $totalcategories; ?>"><?php echo $totalcategories; ?></span></p>
            <small class="muted">Total categories</small>
        </div>
        <div class="card">
            <h3>Products</h3>
            <p class="value"><span class="count" data-target="<?php echo $totalproducts; ?>"><?php echo $totalproducts; ?></span></p>
            <small class="muted">Total products in inventory</small>
        </div>
        <div class="card">
            <h3>Revenue (Delivered)</h3>
            <p class="value">₹<span class="count" data-target="<?php echo (int)$totalrevenue; ?>"><?php echo number_format($totalrevenue, 2); ?></span></p>
            <small class="muted">Total revenue from delivered orders</small>
        </div>
        <div class="card">
            <h3>Orders Today</h3>
            <p class="value"><span class="count" data-target="<?php echo $ordersToday; ?>"><?php echo $ordersToday; ?></span></p>
            <small class="muted">Orders placed today</small>
        </div>
        <div class="card">
            <h3>Total Orders</h3>
            <p class="value"><span class="count" data-target="<?php echo $totalorders; ?>"><?php echo $totalorders; ?></span></p>
            <small class="muted">All orders</small>
        </div>
        <div class="card">
            <h3>Avg Order Value</h3>
            <p class="value">₹<span class="count" data-target="<?php echo (int)$avgOrderValue; ?>"><?php echo number_format($avgOrderValue, 2); ?></span></p>
            <small class="muted">Average order value</small>
        </div>
        <div class="card">
            <h3>Pending Orders</h3>
            <p class="value"><span class="count" data-target="<?php echo $pendingorders; ?>"><?php echo $pendingorders; ?></span></p>
            <small class="muted">Orders awaiting processing</small>
        </div>
        <div class="card">
            <h3>Processing Orders</h3>
            <p class="value"><span class="count" data-target="<?php echo $processingorders; ?>"><?php echo $processingorders; ?></span></p>
            <small class="muted">Orders in process</small>
        </div>
        <div class="card">
            <h3>Delivered Orders</h3>
            <p class="value"><span class="count" data-target="<?php echo $deliveredorders; ?>"><?php echo $deliveredorders; ?></span></p>
            <small class="muted">Delivered orders</small>
        </div>
        <div class="card">
            <h3>Cancelled Orders</h3>
            <p class="value"><span class="count" data-target="<?php echo $cancelledorders; ?>"><?php echo $cancelledorders; ?></span></p>
            <small class="muted">Cancelled orders</small>
        </div>
        <div class="card">
            <h3>Customers</h3>
            <p class="value"><span class="count" data-target="<?php echo $totalcustomer; ?>"><?php echo $totalcustomer; ?></span></p>
            <small class="muted">Registered customers</small>
        </div>
        <div class="card">
            <h3>Delivery Boys</h3>
            <p class="value"><span class="count" data-target="<?php echo $deliveryboys; ?>"><?php echo $deliveryboys; ?></span></p>
            <small class="muted">Avalible Delivery Boys</small>
        </div>
    </div>

  <!--  <div class="cards" style="grid-template-columns:1fr 360px; gap:18px; align-items:start;">
        <div class="card chart-card">
            <h3>Sales — Last 7 days</h3>
            <div class="chart-container">
                <canvas id="salesChart"></canvas>
            </div>
        </div>-->

        <div class="card">
            <h3>Recent Orders</h3>
            <div class="table-section" style="padding:8px; max-height:320px; overflow:auto;">
                <table style="width:100%; border-collapse:collapse;">
                    <tr>
                        <th style="text-align:left;">Order</th>
                        <th style="text-align:right;">Total</th>
                    </tr>
                    <?php if ($recentOrders && $recentOrders->num_rows > 0) { ?>
                        <?php while ($row = $recentOrders->fetch_assoc()) { ?>
                            <tr>
                                <td>#<?= $row['order_id'] ?> — <?= htmlspecialchars($row['name']) ?><br><small class="muted"><?= date('d M', strtotime($row['order_date'])) ?></small></td>
                                <td style="text-align:right;">₹<?= number_format($row['total'], 2) ?></td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="2" style="text-align:center;">No recent orders</td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>
    </div>


<!--<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {

  setTimeout(() => {

    const canvas = document.getElementById('salesChart');
    if (!canvas) return;

    new Chart(canvas, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Revenue (₹)',
                data: revenues,
                fill: true,
                tension: 0.3,
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });

}, 100);


});
</script>-->



</main>