<?php
ob_start(); // Fix buffer
include '../includes/db.php';

 $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']);

if (!isset($_GET['id'])) {
    if($isAjax) { echo json_encode(['success'=>false, 'message'=>'ID Missing']); exit; } 
    else { die("Category Id Missing"); }
}
 $id = (int)$_GET['id'];

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_end_clean(); // Clear buffer
    header('Content-Type: application/json');
    
    $name = trim($_POST['category_name']);
    $slug = trim($_POST['slug']);
    
    if(empty($name) || empty($slug)){
        echo json_encode(['success'=>false, 'message'=>'Name and Slug are required.']);
        exit;
    }

    $uploadDir = "../assets/images/categories/";
    
    $res = $conn->query("SELECT image FROM categories WHERE category_id=$id");
    $current = $res->fetch_assoc();
    $image = $current['image'];

    if (isset($_FILES['category_image']) && $_FILES['category_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'webp', 'png'];
        $ext = strtolower(pathinfo($_FILES['category_image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            if (!empty($image) && file_exists($uploadDir . $image)) @unlink($uploadDir . $image);
            $image = time() . '_' . uniqid() . '.' . $ext;
            move_uploaded_file($_FILES['category_image']['tmp_name'], $uploadDir . $image);
        }
    }

    $stmt = $conn->prepare("UPDATE categories SET category_name=?, slug=?, image=? WHERE category_id=?");
    $stmt->bind_param("sssi", $name, $slug, $image, $id);
    
    if($stmt->execute()){
        echo json_encode(['success'=>true, 'redirect'=>'manage_category.php']);
    } else {
        echo json_encode(['success'=>false, 'message'=>'Database Error: ' . $stmt->error]);
    }
    exit;
}

// Fetch Data
 $result = $conn->query("SELECT * FROM categories WHERE category_id=$id");
if ($result->num_rows == 0) die("Category Not Found");
 $category = $result->fetch_assoc();

if(!$isAjax) include 'admin_header.php';
?>

<div class="category-container">
    <h2>Edit Category</h2>
    <form method="POST" enctype="multipart/form-data" action="edit_category.php?id=<?php echo $id; ?>">
        <label>Name</label>
        <input type="text" name="category_name" value="<?php echo htmlspecialchars($category['category_name']); ?>" required>
        
        <label>Slug</label>
        <input type="text" name="slug" value="<?php echo htmlspecialchars($category['slug']); ?>" required>
        
        <label>Current Image</label>
        <?php if($category['image']): ?>
            <img src="../assets/images/categories/<?php echo $category['image']; ?>" width="100"><br>
        <?php endif; ?>
        
        <label>New Image (Optional)</label>
        <input type="file" name="category_image" accept="image/*">
        
        <button type="submit">Update Category</button>
    </form>
</div>