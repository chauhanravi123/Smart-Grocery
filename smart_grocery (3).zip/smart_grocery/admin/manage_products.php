<?php
include '../includes/db.php';


// --- Handle Delete Operation ---
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete']; // Sanitize ID

    // 1. Delete images from server
    $img_res = $conn->query("SELECT image FROM product_images WHERE product_id=$id");
    while($img_row = $img_res->fetch_assoc()){
        if(!empty($img_row['image']) && file_exists('../assets/images/products/'.$img_row['image'])){
            unlink('../assets/images/products/'.$img_row['image']);
        }
    }

    // 2. Delete product from database (Assuming ON DELETE CASCADE is set for product_images table)
    // If not, you need to run: $conn->query("DELETE FROM product_images WHERE product_id=$id"); first.
    $conn->query("DELETE FROM products WHERE product_id=$id");
    
    // Redirect to remove the ?delete parameter from URL
    header("Location: manage_products.php");
    exit;
}

// --- Fetch Products ---
 $products = $conn->query("
    SELECT p.*, c.category_name, GROUP_CONCAT(pi.image SEPARATOR ',') AS images
    FROM products p
    JOIN categories c ON c.category_id = p.category_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id
    GROUP BY p.product_id
    ORDER BY p.product_id DESC
");
?>

<!-- Link CSS (Assuming admin_header handles main styles, this ensures specific table styles load) -->
<link rel="stylesheet" href="assets/css/admin.css">

<div class="table-section table-products">
  <!-- Header Section matching manage_category.php -->
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:12px;flex-wrap:wrap;">
    <h2 style="margin:0">Manage Products</h2>
    <a class="btn" href="add_products.php">Add Product</a>
  </div>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Category</th>
        <th>Price (₹)</th>
        <th>Stock</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      while($row = $products->fetch_assoc()){ 
          // Handle Image Display
          $firstImage = '';
          if (!empty($row['images'])) {
              $images = explode(',', $row['images']);
              $firstImage = $images[0];
          }
      ?>
      <tr>
        <td><?php echo $row['product_id']; ?></td>
        
        <td>
          <?php if(!empty($firstImage)){ ?>
            <img class="thumb" src="../assets/images/products/<?php echo htmlspecialchars($firstImage); ?>" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
          <?php } else { ?>
            <img class="thumb" src="../assets/images/no-image.png" alt="No Image">
          <?php } ?>
        </td>

        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
        <td><?php echo htmlspecialchars($row['category_name']); ?></td>
        
        <td>₹<?php echo number_format($row['price'], 2); ?></td>
        
        <td><?php echo $row['stock_qty']; ?></td>
        
        <td>
          <?php if($row['status']){ ?>
            <span style="color:green; font-weight:600;">Active</span>
          <?php } else { ?>
            <span style="color:red; font-weight:600;">Inactive</span>
          <?php } ?>
        </td>

        <td class="table-actions">
            <a class="btn btn-edit" href="update_products.php?id=<?php echo $row['product_id']; ?>">Edit</a>
            <a class="btn btn-delete" href="manage_products.php?delete=<?php echo $row['product_id']; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

