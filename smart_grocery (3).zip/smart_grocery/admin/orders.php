<?php
include 'admin_auth.php';
include '../includes/db.php';

/* --- HANDLE FILTERS --- */
 $search = isset($_GET['search']) ? trim($_GET['search']) : '';
 $date = isset($_GET['date']) ? trim($_GET['date']) : '';

// Base Query
 $sql = "SELECT o.*, d.delivery_id, d.name AS delivery_name, d.phone AS delivery_phone 
        FROM orders o 
        LEFT JOIN delivery_boys d ON o.delivery_id = d.delivery_id";

 $conditions = [];
 $params = [];
 $types = '';

// 1. Search Logic (Order ID or Phone)
if (!empty($search)) {
    $conditions[] = "(o.order_id = ? OR o.phone LIKE ?)";
    $types .= 'ss';
    $params[] = $search; 
    $params[] = "%" . $search . "%";
}

// 2. Date Logic
if (!empty($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $conditions[] = "DATE(o.order_date) = ?";
    $types .= 's';
    $params[] = $date;
}

// Build Final Query
if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}
 $sql .= " ORDER BY o.order_id DESC";

// Prepare Statement
 $stmt = $conn->prepare($sql);
if ($stmt) {
    if (!empty($types)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $orders = $stmt->get_result();
} else {
    $orders = $conn->query($sql); 
}
?>

<link rel="stylesheet" href="assets/css/admin.css">

<div class="table-section">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:15px;flex-wrap:wrap;">
        <h2 style="margin:0">All Orders</h2>
        
        <!-- FILTER FORM -->
        <form method="get" class="filter-form" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <input type="text" name="search" placeholder="Order ID or Phone" value="<?= htmlspecialchars($search) ?>" style="padding:8px; border:1px solid #ddd; border-radius:4px;">
            
            <input type="date" name="date" value="<?= htmlspecialchars($date) ?>" style="padding:7px; border:1px solid #ddd; border-radius:4px;">
            
            <button class="btn" type="submit">Filter</button>
            <a class="btn btn-outline" href="orders.php">Reset</a>
        </form>
    </div>

    <table>   
        <thead>
            <tr>
                <th>Id</th>
                <th>Customer</th>
                <th>Phone</th>
                <th>Total</th>
                <th>Address</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if ($orders->num_rows > 0) {
                while ($row = $orders->fetch_assoc()) { 
            ?>
                <tr data-order-id="<?= $row['order_id'] ?>">
                    <td><?= $row['order_id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['phone']) ?></td>
                    <td>₹<?= number_format($row['total'],2) ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td class="delivery-status" data-order-id="<?= $row['order_id'] ?>">
                        <?= htmlspecialchars($row['delivery_status'] ?? 'N/A') ?>
                    </td>
                    <td>
                        <?= !empty($row['order_date']) ? date('d M Y', strtotime($row['order_date'])) : '-' ?>
                    </td>
                    <td class="table-actions">
                        <!-- View Button -->
                        <a class="btn btn-outline" href="order_details.php?id=<?= $row['order_id'] ?>">View</a>
                        
                        <!-- NEW: Bill Button (Opens in new tab for printing) -->
                        <a class="btn" href="bill.php?id=<?= $row['order_id'] ?>" target="_blank" style="background:#333; color:#fff;">Bill</a>
                    </td>
                </tr>
            <?php 
                } 
            } else { 
            ?>
                <tr>
                    <td colspan="8" style="text-align:center; padding:20px;">No orders found matching your criteria.</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
// Long-poll admin order updates
(function(){
    let lastId = 0;
    async function poll(){
        try{
            const res = await fetch('../ajax/get_orders_statuses_admin.php?since='+lastId);
            if(!res.ok) { setTimeout(poll, 4000); return; }

            const j = await res.json();
            if(j && j.success){ 
                if(j.updates && j.updates.length){
                    for(const u of j.updates){
                        const cell = document.querySelector('.delivery-status[data-order-id="'+u.order_id+'"]');
                        if(cell && cell.textContent.trim() !== (u.delivery_status || '').trim()){
                            cell.textContent = u.delivery_status || '';
                            cell.style.transition = 'background-color 0.3s';
                            cell.style.backgroundColor = '#fffbcc';
                            setTimeout(()=> cell.style.backgroundColor = '', 1200);
                        }
                        if(u.id && u.id > lastId) lastId = u.id;
                    }
                }
            }
        }catch(e){ console.error('Polling error:', e); }
        setTimeout(poll, 3000);
    }
    poll();
})();
</script>