document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.getElementById('sidebarToggle');
    const mainContent = document.getElementById('mainContent');

    // 1. Sidebar Toggle
    try { if (localStorage.getItem('admin_sidebar_collapsed') === '1') sidebar.classList.add('collapsed'); } catch (e) { }
    if (toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('admin_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0');
        });
    }

    // 2. Helper: Execute scripts inside fetched HTML
    function runScripts(node) {
        node.querySelectorAll('script').forEach(s => {
            const newScript = document.createElement('script');
            if (s.src) newScript.src = s.src;
            if (s.type) newScript.type = s.type;
            if (!s.src) newScript.textContent = s.textContent;
            document.body.appendChild(newScript).parentNode.removeChild(newScript);
        });
    }

    // 3. Main Page Loader
    async function loadPage(url, push = true) {
        if (!url) return;
        if (mainContent) { mainContent.innerHTML = '<div class="table-section loader"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>'; }

        try {
            const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const html = await res.text();
            
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            
            // Extract content
            const fragment = doc.querySelector('#mainContent')?.innerHTML || doc.querySelector('main')?.innerHTML || doc.body.innerHTML;
            
            if (mainContent) mainContent.innerHTML = fragment || '<p class="muted">No content</p>';
            
            runScripts(doc);
            animateCounts();

            // Update sidebar active state
            document.querySelectorAll('.sidebar nav li').forEach(li => li.classList.remove('active'));
            const path = url.split('/').pop().split('?')[0];
            const link = document.querySelector('.sidebar a.nav-link[data-page="' + path + '"]');
            if (link) link.parentElement.classList.add('active');

            if (push) history.pushState({ url }, '', url);
        } catch (e) {
            if (mainContent) mainContent.innerHTML = '<div class="table-section"><p class="muted">Error loading page</p></div>';
            console.error(e);
        }
    }

    // 4. Sidebar Navigation
    document.querySelectorAll('.sidebar nav a.nav-link').forEach(a => {
        a.removeAttribute('target');
        a.addEventListener('click', function (e) {
            e.preventDefault();
            loadPage(this.getAttribute('href'), true);
        });
    });

    // 5. Handle Generic Form Submissions (Add/Edit)
    if (mainContent) {
        mainContent.addEventListener('submit', async function (e) {
            const form = e.target;
            if (!form) return;

            e.preventDefault(); 

            const formData = new FormData(form);
            const btn = form.querySelector('[type="submit"]');
            const originalText = btn ? btn.textContent : 'Submit';
            
            // --- FIX: CHECK FOR GET METHOD ---
            if (form.method.toUpperCase() === 'GET') {
                // If it's a search/filter form, just load the page with the new URL
                const params = new URLSearchParams(formData).toString();
                const url = form.action.split('?')[0] + '?' + params;
                loadPage(url, true);
                return;
            }

            // --- POST METHOD LOGIC ---
            if (btn) { btn.textContent = 'Processing...'; btn.disabled = true; }

            try {
                const res = await fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });

                const textResponse = await res.text();
                
                try {
                    const json = JSON.parse(textResponse);
                    
                    if (json.success) {
                        // CASE 1: Add/Edit Redirect
                        if (json.redirect) {
                            loadPage(json.redirect, true);
                        } 
                        // CASE 2: Delivery Assignment
                        else if (json.delivery) {
                            if (form.classList.contains('assign-row-form')) {
                                const row = form.closest('tr');
                                const deliveryCell = row.querySelector('.delivery-cell');
                                if (deliveryCell) {
                                    deliveryCell.innerHTML = `${json.delivery.name} <span class="small muted">(${json.delivery.phone})</span>`;
                                }
                                const btn = form.querySelector('button[type="submit"]');
                                if (btn) btn.textContent = 'Reassign';
                            } else {
                                const modal = document.getElementById('adminModal');
                                if (modal) modal.classList.remove('open');
                                loadPage('orders.php', true);
                            }
                        } else {
                            alert('Success!');
                        }
                    } else {
                        alert(json.message || 'An error occurred.');
                        if (btn) { btn.textContent = originalText; btn.disabled = false; }
                    }

                } catch (e) {
                    mainContent.innerHTML = textResponse;
                    runScripts(mainContent);
                }

            } catch (err) {
                console.error(err);
                alert('A network error occurred.');
                if (btn) { btn.textContent = originalText; btn.disabled = false; }
            }
        });

        // 6. Handle Link Clicks inside Main Content
        mainContent.addEventListener('click', function (e) {
            const a = e.target.closest('a');
            if (!a) return;
            
            const href = a.getAttribute('href');
            
            if (!href || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('#') || a.target === '_blank' || a.hasAttribute('data-no-ajax')) return;

            e.preventDefault();
            loadPage(href, true);
        });
    }

    // 7. Browser Back/Forward
    window.addEventListener('popstate', function (e) {
        const url = (e.state && e.state.url) ? e.state.url : location.pathname.split('/').pop();
        loadPage(url, false);
    });

    // 8. Animate Counters
    function animateCounts() {
        document.querySelectorAll('.count').forEach(el => {
            const target = parseFloat(el.getAttribute('data-target')) || 0;
            const duration = 800;
            let startTime = null;
            const step = (timestamp) => {
                if (!startTime) startTime = timestamp;
                const progress = Math.min((timestamp - startTime) / duration, 1);
                el.textContent = Math.round(progress * target).toLocaleString();
                if (progress < 1) requestAnimationFrame(step);
            };
            requestAnimationFrame(step);
        });
    }

    // 9. Search
    const searchInput = document.querySelector('.search input');
    if (searchInput) {
        searchInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                const q = encodeURIComponent(searchInput.value.trim());
                loadPage('orders.php?q=' + q);
            }
        });
    }

    // 10. Initial Load
    const initial = location.pathname.split('/').pop() || 'dashboard.php';
    if (initial === 'dashboard.php' || initial === '') {
        loadPage('dashboard_content.php', false);
    }
});