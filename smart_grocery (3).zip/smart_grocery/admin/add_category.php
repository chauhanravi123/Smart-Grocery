<?php
ob_start(); // Start buffer to prevent header errors
include '../includes/db.php';

// --- HANDLE FORM SUBMISSION (AJAX) ---
// Changed condition to check METHOD instead of button name
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['category_name'])) {
    ob_end_clean(); // Clear buffer
    header('Content-Type: application/json'); 
    
    $name = trim($_POST['category_name']);
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));

    // Check for duplicates
    $stmt = $conn->prepare("SELECT category_id FROM categories WHERE slug=? OR category_name=?");
    $stmt->bind_param("ss", $slug, $name);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Category already exists!']);
        exit;
    }

    // Upload Image
    $image = '';
    if (!empty($_FILES['category_image']['name'])) {
        $uploadDir = "../assets/images/categories/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        
        $image_name = time() . '_' . basename($_FILES['category_image']['name']);
        $target = $uploadDir . $image_name;
        if (move_uploaded_file($_FILES['category_image']['tmp_name'], $target)) {
            $image = $image_name;
        }
    }

    // Insert into DB
    try {
        $insert = $conn->prepare("INSERT INTO categories (category_name, slug, image, status) VALUES (?, ?, ?, 1)");
        $insert->bind_param("sss", $name, $slug, $image);
        
        if ($insert->execute()) {
            echo json_encode(['success' => true, 'redirect' => 'manage_category.php']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error: Could not add category.']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit;
}
?>

<!-- --- HTML FORM --- -->
<div class="category-container">
    <h2>Add New Category</h2>
    <!-- Important: keep the button but PHP no longer depends on its name -->
    <form method="POST" enctype="multipart/form-data" action="add_category.php">
        <label>Category Name</label>
        <input type="text" name="category_name" placeholder="Category Name" required>
        
        <label>Category Image</label>
        <input type="file" name="category_image">
        
        <button type="submit">Add Category</button>
    </form>
</div>