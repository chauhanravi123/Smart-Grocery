<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body{font-family:Arial;background:#f4f4f4;}
        .login-box{
            width:350px;margin:100px auto;
            background:#fff;padding:20px;
            box-shadow:0 0 10px #ccc;
        }
        input{width:100%;padding:10px;margin:10px 0;}
        button{width:100%;padding:10px;background:#28a745;color:#fff;border:none;}
        .error{color:red;text-align:center;}
    </style>
</head>
<body>

<div class="login-box">
    <h2>Admin Login</h2>

    <?php if(isset($_GET['error'])){ ?>
        <p class="error">Invalid Email or Password</p>
    <?php } ?>

    <form method="POST" action="login_process.php">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
