<?php
ob_start(); // Start buffer
include '../includes/db.php';

// --- HANDLE FORM SUBMISSION (AJAX) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['product_name'])) {
    ob_end_clean(); // Clear buffer
    header('Content-Type: application/json');
    
    $name        = trim($_POST['product_name']);
    $price       = (float)$_POST['price'];
    $category_id = (int)$_POST['category_id'];
    $description = trim($_POST['description']);
    $stock       = (int)$_POST['stock'];
    $mrp         = (float)($_POST['mrp'] ?? 0.00);
    $short_desc  = trim($_POST['short_description'] ?? '');

    if (empty($name) || empty($category_id)) {
        echo json_encode(['success' => false, 'message' => 'Name and Category are required.']);
        exit;
    }

    // Insert Product
    $stmt = $conn->prepare("INSERT INTO products (category_id, product_name, price, mrp, stock_qty, description, short_description) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isddiss", $category_id, $name, $price, $mrp, $stock, $description, $short_desc);
    
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Product insert failed: ' . $stmt->error]);
        exit;
    }
    $product_id = $conn->insert_id;

    // Handle Image Uploads
    $uploadDir = "../assets/images/products/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    if (!empty($_FILES['product_images']['name'][0])) {
        foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp) {
            if ($_FILES['product_images']['error'][$key] !== 0) continue;

            $ext = strtolower(pathinfo($_FILES['product_images']['name'][$key], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $img = time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($tmp, $uploadDir . $img);

                $stmt2 = $conn->prepare("INSERT INTO product_images (product_id, image) VALUES (?, ?)");
                $stmt2->bind_param("is", $product_id, $img);
                $stmt2->execute();
            }
        }
    }

    echo json_encode(['success' => true, 'redirect' => 'manage_products.php']);
    exit;
}

// --- PREPARE DATA FOR FORM ---
 $cats = $conn->query("SELECT * FROM categories WHERE status=1");
?>

<!-- --- HTML FORM --- -->
<div class="product-container">
    <h2>Add New Product</h2>
    <form method="POST" enctype="multipart/form-data" action="add_products.php">
        
        <label>Category</label>
        <select name="category_id" required>
            <option value="">Select Category</option>
            <?php while ($cat = $cats->fetch_assoc()) { ?>
                <option value="<?php echo $cat['category_id']; ?>">
                    <?php echo htmlspecialchars($cat['category_name']); ?>
                </option>
            <?php } ?>
        </select>

        <label>Product Name</label>
        <input type="text" name="product_name" required>

        <div style="display:flex; gap:10px;">
            <div style="flex:1">
                <label>Price (₹)</label>
                <input type="number" name="price" step="0.01" required>
            </div>
            <div style="flex:1">
                <label>MRP (₹)</label>
                <input type="number" name="mrp" step="0.01">
            </div>
        </div>

        <label>Short Description</label>
        <input type="text" name="short_description">

        <label>Stock</label>
        <input type="number" name="stock" min="0" required>

        <label>Product Images</label>
        <input type="file" name="product_images[]" multiple accept="image/*">

        <label>Description</label>
        <textarea name="description" rows="4" required></textarea>

        <button type="submit">Add Product</button>
    </form>
</div>