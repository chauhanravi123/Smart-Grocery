<?php
ob_start();
include '../includes/db.php';

 $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']);

if (!isset($_GET['id']) || empty($_GET['id'])) {
  if($isAjax) { echo json_encode(['success'=>false, 'message'=>'Product ID missing']); exit; } 
  else { die("Product ID missing!"); }
}
 $id = (int) $_GET['id'];

 $res = $conn->query("SELECT * FROM products WHERE product_id=$id");
if ($res->num_rows == 0) die("Product not found!");
 $product = $res->fetch_assoc();

 $imagesRes = $conn->query("SELECT * FROM product_images WHERE product_id=$id ORDER BY image_id ASC");
 $images = $imagesRes->fetch_all(MYSQLI_ASSOC);

 $cats = $conn->query("SELECT * FROM categories WHERE status=1");

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  ob_end_clean();
  header('Content-Type: application/json');

  $name  = $_POST['product_name'];
  $price = (float)$_POST['price'];
  $mrp   = (float)($_POST['mrp'] ?? 0.00);
  $short_desc = trim($_POST['short_description'] ?? '');
  $stock = (int)$_POST['stock_qty'];
  $cat   = (int)$_POST['category_id'];
  $desc  = $_POST['description'];

  $stmt = $conn->prepare("UPDATE products SET product_name=?, price=?, mrp=?, short_description=?, stock_qty=?, category_id=?, description=? WHERE product_id=?");
  
  // --- THE FIX IS HERE ---
  // 1. Name (s)
  // 2. Price (d)
  // 3. MRP (d)
  // 4. Short Desc (s)
  // 5. Stock (i)
  // 6. Category ID (i)
  // 7. Description (s)
  // 8. Product ID (i) -> This was missing in your type string
  $stmt->bind_param("sddsiisi", $name, $price, $mrp, $short_desc, $stock, $cat, $desc, $id);
  
  if (!$stmt->execute()) {
     echo json_encode(['success' => false, 'message' => 'Database Error: ' . $stmt->error]);
     exit;
  }

  $uploadDir = "../assets/images/products/";
  if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

  if (!empty($_FILES['product_images']['name'][0])) {
    foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp) {
      if (empty($_FILES['product_images']['name'][$key])) continue;
      $ext = strtolower(pathinfo($_FILES['product_images']['name'][$key], PATHINFO_EXTENSION));
      if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
        $img = time() . '_' . uniqid() . '.' . $ext;
        move_uploaded_file($tmp, $uploadDir . $img);
        $stmt2 = $conn->prepare("INSERT INTO product_images (product_id, image) VALUES (?, ?)");
        $stmt2->bind_param("is", $id, $img);
        $stmt2->execute();
      }
    }
  }

  echo json_encode(['success' => true, 'redirect' => 'manage_products.php']);
  exit;
}
?>
<link rel="stylesheet" href="assets/css/admin.css">
<div class="product-container">
  <h2>Edit Product</h2>
  <form method="POST" enctype="multipart/form-data" action="update_products.php?id=<?php echo $id; ?>">
     <label for="product_name">Product Name</label>
    <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>

    <label for="price">Price (₹)</label>
    <input type="number" id="price" name="price" step="0.01" value="<?php echo $product['price']; ?>" required>

    <label for="mrp">MRP (Actual Price)</label>
    <input type="number" id="mrp" name="mrp" step="0.01" value="<?php echo $product['mrp']; ?>" required>

    <label for="short_description">Short Description (optional)</label>
    <input type="text" id="short_description" name="short_description" value="<?php echo htmlspecialchars($product['short_description']); ?>">

    <label for="stock">Stock</label>
    <input type="number" id="stock" name="stock_qty" value="<?php echo $product['stock_qty']; ?>" required>

    <label for="category_id">Category</label>
    <select id="category_id" name="category_id">
      <?php while ($c = $cats->fetch_assoc()) { ?>
        <option value="<?php echo $c['category_id']; ?>" <?php if ($c['category_id'] == $product['category_id']) echo 'selected'; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
      <?php } ?>
    </select>

    <label for="description">Description</label>
    <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($product['description']); ?></textarea>

    <label>Current Images</label>
    <?php if (!empty($images)) { ?>
      <div style="margin-bottom:10px; display:flex; gap:10px; flex-wrap:wrap;">
        <?php foreach ($images as $img) { ?>
          <div style="position:relative;">
            <img class="thumb" src="../assets/images/products/<?php echo htmlspecialchars($img['image']); ?>" style="width:100px; height:100px; object-fit:cover;">
            <a href="delete_product_image.php?id=<?php echo $img['image_id']; ?>&product_id=<?php echo $id; ?>" style="position:absolute; top:0; right:0; background:red; color:white; padding:2px 6px; cursor:pointer; border-radius:3px;" onclick="return confirm('Delete this image?');">×</a>
          </div>
        <?php } ?>
      </div>
    <?php } ?>

    <label for="product_images">Add New Images (optional)</label>
    <input type="file" id="product_images" name="product_images[]" multiple accept="image/*">

    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
      <button type="submit" class="btn">Update Product</button>
      <a href="manage_products.php" class="btn btn-outline">Back to Products</a>
    </div>
  </form>
</div>