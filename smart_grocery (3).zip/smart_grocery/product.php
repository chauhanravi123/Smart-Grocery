<?php
session_start();
include 'includes/db.php';

/* CART INIT */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* ADD / REMOVE CART */
if (isset($_POST['cart_action'])) {
    $pid = (int)$_POST['product_id'];

    // Fetch current stock for validation
    $stockRes = $conn->query("SELECT stock_qty FROM products WHERE product_id = $pid");
    $stockRow = $stockRes->fetch_assoc();
    $availableStock = $stockRow ? (int)$stockRow['stock_qty'] : 0;
    
    // Get current quantity in cart
    $currentQty = $_SESSION['cart'][$pid] ?? 0;

    if ($_POST['cart_action'] === 'plus') {
        // Constraint 1: Maximum 6 items per product
        // Constraint 2: Cannot exceed available stock
        if ($currentQty < 6 && $currentQty < $availableStock) {
            $_SESSION['cart'][$pid] = $currentQty + 1;
        }
    }

    if ($_POST['cart_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }
}

/* PRODUCT FETCH */
 $id = (int)($_GET['id'] ?? 0);
 $res = $conn->query("SELECT * FROM products WHERE product_id = $id");
 $product = $res->fetch_assoc();

if (!$product) {
    die("Product not found");
}

/* Fetch product images */
 $imagesRes = $conn->query("SELECT image FROM product_images WHERE product_id = $id");
 $images = $imagesRes ? $imagesRes->fetch_all(MYSQLI_ASSOC) : [];

 $qty = $_SESSION['cart'][$id] ?? 0;

/* Calculate discount & savings */
 $mrp = (float)($product['mrp'] ?? 0);
 $price = (float)($product['price'] ?? 0);
 $discount = 0;
 $saveAmount = 0;
if ($mrp > 0 && $mrp > $price) {
    $discount = round((($mrp - $price) / $mrp) * 100);
    $saveAmount = round($mrp - $price, 2);
}

// Determine if user can add more
 $canAddMore = ($qty < 6 && $qty < (int)$product['stock_qty']);
?>
<!DOCTYPE html>
<html>

<head>
    <title><?= htmlspecialchars($product['product_name']); ?> | Smart Grocery</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/product.css">
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <div>
            <a href="index.php" style="margin-left:0;"><b>🛒 SmartGrocery</b></a>
        </div>
        <div>
            <a href="products.php">Products</a>
            <a href="index.php">Home</a>
            <a href="cart.php">
                Cart <span class="cart-count"><?= array_sum($_SESSION['cart'] ?? []); ?></span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user/logout.php">Logout</a>
            <?php } else { ?>
                <a href="user/login.php">Login</a>
            <?php } ?>
        </div>
    </div>

    <div class="container">

        <div class="product-detail">
            <!-- Gallery Section -->
            <div class="gallery-section">
                <?php 
                // Set default image path
                $mainImageSrc = "assets/images/products/no-image.png"; 
                if (!empty($images) && !empty($images[0]['image'])) {
                    $mainImageSrc = "assets/images/products/" . htmlspecialchars($images[0]['image']);
                }
                ?>
                <img id="mainImage" 
                     src="<?= $mainImageSrc ?>" 
                     alt="<?= htmlspecialchars($product['product_name']); ?>"
                     class="main-image">

                <?php if (!empty($images)): ?>
                    <div class="gallery-thumbnails">
                        <?php foreach ($images as $idx => $img) { ?>
                            <img src="assets/images/products/<?= htmlspecialchars($img['image']); ?>" 
                                 alt="Product image <?= $idx + 1 ?>"
                                 class="<?= $idx === 0 ? 'active' : '' ?>"
                                 onclick="document.getElementById('mainImage').src='assets/images/products/<?= htmlspecialchars($img['image']); ?>'; document.querySelectorAll('.gallery-thumbnails img').forEach(e => e.classList.remove('active')); this.classList.add('active');">
                        <?php } ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Product Info Section -->
            <div class="product-info">
                <h1><?= htmlspecialchars($product['product_name']); ?></h1>

                <div class="product-rating">
                    Sold by <strong>Smart Grocery</strong> ✓
                </div>

                <!-- Pricing -->
                <div class="pricing">
                    <div class="price-row">
                        <span class="price">₹<?= number_format($price, 2) ?></span>
                        <?php if ($discount > 0): ?>
                            <span class="discount-badge">-<?= $discount ?>%</span>
                        <?php endif; ?>
                    </div>

                    <?php if ($mrp > 0 && $mrp > $price): ?>
                        <div class="price-row">
                            <span class="price-label">MRP:</span>
                            <span class="mrp">₹<?= number_format($mrp, 2) ?></span>
                        </div>
                        <div class="savings">
                            You save ₹<?= number_format($saveAmount, 2) ?> (<?= $discount ?>% off)
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Stock Status -->
                <?php if ($product['stock_qty'] > 0): ?>
                    <div class="stock-status in-stock">
                        <span class="stock-indicator"></span>
                        In Stock (<?= (int)$product['stock_qty'] ?> available)
                    </div>
                <?php else: ?>
                    <div class="stock-status out-stock">
                        <span class="stock-indicator"></span>
                        Out of Stock
                    </div>
                <?php endif; ?>

                <!-- Short Description -->
                <?php if (!empty($product['short_description'])): ?>
                    <div class="short-description">
                        <?= htmlspecialchars($product['short_description']); ?>
                    </div>
                <?php endif; ?>

                <!-- Cart Controls -->
                <?php if ($product['stock_qty'] > 0): ?>
                    <form method="post" style="margin:0;">
                        <div class="cart-controls">
                            <div class="qty-input">
                                <button type="submit" name="cart_action" value="minus" <?= $qty <= 0 ? 'disabled' : '' ?>>−</button>
                                <span><?= $qty ?></span>
                                <!-- Disable plus button if limit reached -->
                                <button type="submit" name="cart_action" value="plus" <?= !$canAddMore ? 'disabled' : '' ?>>+</button>
                            </div>
                            <input type="hidden" name="product_id" value="<?= $product['product_id']; ?>">
                        </div>
                        
                        <?php if (!$canAddMore && $qty > 0): ?>
                            <div class="limit-msg">
                                Max limit reached (6 items or out of stock).
                            </div>
                        <?php endif; ?>
                    </form>
                <?php else: ?>
                    <button class="add-cart-btn" disabled>Out of Stock</button>
                <?php endif; ?>

                <!-- Full Description -->
                <div class="full-description">
                    <h3>Product Details</h3>
                    <?= nl2br(htmlspecialchars($product['description'])); ?>
                </div>

                <a href="products.php" class="back-link">← Back to Products</a>
            </div>
        </div>

    </div>

</body>
</html>