-- Create inventory_log table for tracking stock changes
-- Migration: 20260130_create_inventory_log.sql

CREATE TABLE IF NOT EXISTS `inventory_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `old_stock` int NOT NULL,
  `new_stock` int NOT NULL,
  `change_type` enum('manual','bulk','sale','return','adjustment') NOT NULL DEFAULT 'manual',
  `reason` varchar(255) DEFAULT NULL,
  `notes` text,
  `changed_by` varchar(100) DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `product_id` (`product_id`),
  KEY `changed_at` (`changed_at`),
  CONSTRAINT `inventory_log_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Add some indexes for better performance
CREATE INDEX idx_inventory_log_product_date ON inventory_log(product_id, changed_at);
CREATE INDEX idx_inventory_log_change_type ON inventory_log(change_type);