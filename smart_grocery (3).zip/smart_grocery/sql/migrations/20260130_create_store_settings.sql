-- Create store_settings table
-- Migration: 20260130_create_store_settings.sql

CREATE TABLE IF NOT EXISTS `store_settings` (
  `id` int NOT NULL DEFAULT '1',
  `store_name` varchar(255) NOT NULL DEFAULT 'Smart Grocery',
  `store_email` varchar(255) NOT NULL,
  `store_phone` varchar(20) NOT NULL,
  `store_address` text NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'INR',
  `tax_rate` decimal(5,2) NOT NULL DEFAULT '5.00',
  `delivery_charge` decimal(10,2) NOT NULL DEFAULT '50.00',
  `free_delivery_threshold` decimal(10,2) NOT NULL DEFAULT '500.00',
  `business_hours` varchar(255) DEFAULT 'Mon-Sat: 9AM-9PM, Sun: 10AM-6PM',
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `allow_registration` tinyint(1) NOT NULL DEFAULT '1',
  `email_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `sms_notifications` tinyint(1) NOT NULL DEFAULT '0',
  `push_notifications` tinyint(1) NOT NULL DEFAULT '0',
  `order_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `low_stock_alerts` tinyint(1) NOT NULL DEFAULT '1',
  `payment_methods` json DEFAULT NULL,
  `shipping_zones` text,
  `facebook_url` varchar(500) DEFAULT NULL,
  `twitter_url` varchar(500) DEFAULT NULL,
  `instagram_url` varchar(500) DEFAULT NULL,
  `youtube_url` varchar(500) DEFAULT NULL,
  `linkedin_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert default settings
INSERT INTO `store_settings` (`id`, `store_name`, `store_email`, `store_phone`, `store_address`, `currency`, `tax_rate`, `delivery_charge`, `free_delivery_threshold`, `business_hours`, `maintenance_mode`, `allow_registration`, `email_notifications`, `sms_notifications`, `push_notifications`, `order_notifications`, `low_stock_alerts`, `payment_methods`, `shipping_zones`, `facebook_url`, `twitter_url`, `instagram_url`, `youtube_url`, `linkedin_url`)
VALUES (1, 'Smart Grocery', 'admin@smartgrocery.com', '+91-9876543210', '123 Main Street, City, State 12345', 'INR', 5.00, 50.00, 500.00, 'Mon-Sat: 9AM-9PM, Sun: 10AM-6PM', 0, 1, 1, 0, 0, 1, 1, '["Cash on Delivery", "Credit Card", "UPI"]', 'Local: ₹50\nCity: ₹100\nState: ₹200', '', '', '', '', '')
ON DUPLICATE KEY UPDATE `id` = `id`;