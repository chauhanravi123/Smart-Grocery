<?php
session_start();                // ✅ MUST BE FIRST
include 'includes/db.php';

/* CART INIT */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* ADD / REMOVE CART */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_action'])) {

    $pid = (int)$_POST['product_id'];
    $max_limit = 6; // Set your limit here
    $error_message = '';

    if ($_POST['cart_action'] === 'plus') {
        $current_qty = $_SESSION['cart'][$pid] ?? 0;

        if ($current_qty < $max_limit) {
            $_SESSION['cart'][$pid] = $current_qty + 1;
        } else {
            $error_message = "Maximum limit of $max_limit reached for this item.";
        }
    }

    if ($_POST['cart_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }

    // If the request is AJAX, return JSON
    $cartCount = array_sum($_SESSION['cart'] ?? []);
    $qty = $_SESSION['cart'][$pid] ?? 0;

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => ($error_message === ''),
            'qty' => $qty,
            'cartCount' => $cartCount,
            'message' => $error_message
        ]);
        exit;
    }
}

/* 🔹 SEARCH & CATEGORY FILTER */
 $search = $_GET['search'] ?? '';
 $cat = $_GET['category'] ?? '';

 $where = "WHERE 1";
if ($search !== '') {
    $search_safe = $conn->real_escape_string($search);
    $where .= " AND product_name LIKE '%$search_safe%'";
}
if ($cat !== '') {
    $cat_safe = (int)$cat;
    $where .= " AND category_id = $cat_safe";
}

/* 🔹 FETCH PRODUCTS */
 $products = $conn->query("SELECT p.*, GROUP_CONCAT(pi.image SEPARATOR ',') AS images FROM products p LEFT JOIN product_images pi ON p.product_id = pi.product_id $where GROUP BY p.product_id");

/* 🔹 FETCH CATEGORIES */
 $categories = $conn->query("SELECT * FROM categories");

/*cart count*/
 $cartCount = array_sum($_SESSION['cart'] ?? []);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products | Smart Grocery</title>
    <link rel="stylesheet" href="./assets/css/products.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

</head>

<body>
    <!-- 🔹 NAVBAR -->
    <div class="navbar">
        <a href="index.php" class="logo">🛒 SmartGrocery</a>
        <div class="nav-links">
            <a href="products.php">Menu</a>
            <a href="index.php">Home</a>
            <a href="cart.php" style="position:relative;">
                Cart <span class="cart-badge" id="cart-count"><?= $cartCount ?></span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user/logout.php">Logout</a>
            <?php } else { ?>
                <a href="user/login.php">Login</a>
            <?php } ?>
        </div>
    </div>

    <div class="container">
        <!-- 🔹 SEARCH + FILTER -->
        <form method="get" class="filter-section">
            <input type="text" name="search" placeholder="Search for groceries, fruits, snacks..." value="<?= htmlspecialchars($search) ?>">
            <select name="category">
                <option value="">All Categories</option>
                <?php while ($c = $categories->fetch_assoc()) { ?>
                    <option value="<?= $c['category_id']; ?>" <?= $cat == $c['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['category_name']); ?>
                    </option>
                <?php } ?>
            </select>
            <button class="btn-search">Search</button>
        </form>

        <!-- 🔹 PRODUCT GRID -->
        <div class="products">
            <?php if ($products && $products->num_rows > 0) {
                while ($p = $products->fetch_assoc()) {
                    $qty = $_SESSION['cart'][$p['product_id']] ?? 0;

                    // Per-product pricing and discount
                    $mrp = (float)($p['mrp'] ?? 0);
                    $price = (float)($p['price'] ?? 0);
                    $discount = 0;
                    if ($mrp > 0 && $mrp > $price) {
                        $discount = (int) round((($mrp - $price) / $mrp) * 100);
                    }

                    // Get first image from product_images
                    $firstImage = 'no-image.png';
                    if (!empty($p['images'])) {
                        $images = explode(',', $p['images']);
                        $firstImage = $images[0];
                    }
            ?>
                    <div class="card">
                        <div class="card-image-wrapper">
                            <?php if ($discount > 0): ?>
                                <div class="discount-badge"><?= $discount ?>% OFF</div>
                            <?php endif; ?>
                            <img src="assets/images/products/<?= htmlspecialchars($firstImage); ?>" alt="<?= htmlspecialchars($p['product_name']); ?>" onerror="this.src='assets/images/no-image.png'">
                        </div>
                        
                        <div class="card-content">
                            <a href="product.php?id=<?= $p['product_id']; ?>" class="card-title">
                                <?= htmlspecialchars($p['product_name']); ?>
                            </a>
                            
                            <?php if (!empty($p['short_description'])): ?>
                                <div class="short-desc"><?= htmlspecialchars($p['short_description']) ?></div>
                            <?php endif; ?>

                            <div class="stock-status <?= $p['stock_qty'] > 0 ? 'in-stock' : 'out-stock' ?>">
                                <span class="stock-dot"></span> 
                                <?= $p['stock_qty'] > 0 ? 'In Stock' : 'Out of Stock' ?>
                            </div>

                            <div class="price-block">
                                <span class="price">₹<?= number_format($price, 2) ?></span>
                                <?php if ($discount > 0): ?>
                                    <span class="mrp">₹<?= number_format($mrp, 2) ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($discount > 0): 
                                $saveAmount = round($mrp - $price, 2);
                                echo "<div class='savings-text'>Save ₹" . number_format($saveAmount, 2) . "</div>"; 
                            endif; ?>

                            <div class="cart-actions">
                                <?php if ($p['stock_qty'] > 0) { ?>
                                    <?php if ($qty > 0) { ?>
                                        <!-- Quantity Control (Visible if qty > 0) -->
                                        <div class="qty-control">
                                            <button type="button" class="qty-btn" onclick="updateCart(<?= $p['product_id'] ?>, 'minus')">−</button>
                                            <span class="qty-display" id="qty-<?= $p['product_id'] ?>"><?= $qty ?></span>
                                            <button type="button" class="qty-btn" onclick="updateCart(<?= $p['product_id'] ?>, 'plus', <?= $p['stock_qty'] ?>)">+</button>
                                        </div>
                                    <?php } else { ?>
                                        <!-- Add Button (Visible if qty = 0) -->
                                        <button type="button" class="btn-add" onclick="updateCart(<?= $p['product_id'] ?>, 'plus', <?= $p['stock_qty'] ?>)">
                                            ADD
                                        </button>
                                    <?php } ?>
                                <?php } else { ?>
                                    <button class="btn-add" disabled>Out of Stock</button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php }
            } else { ?>
                <div class="no-products">
                    <h3>No products found</h3>
                    <p>Try adjusting your search or filter to find what you're looking for.</p>
                </div>
            <?php } ?>
        </div>
    </div>

<script>
    function updateCart(productId, action, stockQty = 0) {
        const qtyEl = document.getElementById('qty-' + productId);
        // If qtyEl is null, it means the item is currently in "ADD" state (qty 0)
        const currentQty = qtyEl ? parseInt(qtyEl.textContent) : 0;

        if (action === 'plus') {
            const allowed = Math.min(6, stockQty);
            if (currentQty >= allowed) {
                alert("Only " + allowed + " items allowed.");
                return;
            }
        }

        fetch('products.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `product_id=${productId}&cart_action=${action}`
            })
            .then(response => response.json())
            .then(data => {
                if (data && data.success) {
                    // Update Cart Count in Navbar
                    const cartEl = document.getElementById('cart-count');
                    if (cartEl) cartEl.textContent = data.cartCount;

                    // Find the parent card actions div
                    const card = document.querySelector(`#qty-${productId}`) ? 
                                 document.querySelector(`#qty-${productId}`).closest('.cart-actions') : 
                                 document.querySelector(`button[onclick*="${productId}"]`).parentElement;
                    
                    if (data.qty > 0) {
                        // If we just added the first item, we need to replace the button with the controls
                        // Since this is a simple implementation, we just reload to switch UI from Button to Counter safely
                        // For a smoother UX without reload, we would need more complex DOM manipulation here
                        if(!qtyEl || data.qty === 1) {
                           location.reload(); 
                        } else {
                           qtyEl.textContent = data.qty;
                        }
                    } else {
                        // Quantity is 0, reload to show "ADD" button again
                        location.reload();
                    }
                } else if (data.message) {
                    alert(data.message);
                }
            })
            .catch(() => location.reload());
    }
</script>

</body>
</html>