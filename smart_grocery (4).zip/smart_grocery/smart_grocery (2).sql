-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 20, 2026 at 05:44 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'jay', 'jay@gmail.com', 'Jay@123');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `slug`, `image`, `status`, `created_at`) VALUES
(1, 'Indian Sweets', 'indian-sweets', '1773921059_indian-sweets.jpg', 1, '2026-03-19 11:50:59'),
(2, 'Chips & Namkeens', 'chips-namkeens', '1773921091_chips-namkeens.jpg', 1, '2026-03-19 11:51:31'),
(3, 'Chocolates & Candies', 'chocolates-candies', '1773921113_chocolates-candies.jpg', 1, '2026-03-19 11:51:53'),
(4, 'Dals & Pulses', 'dals-pulses', '1773921158_dals-pulses-20250617.webp', 1, '2026-03-19 11:52:38'),
(5, 'Fresh Fruits & Vegetables', 'fresh-fruits-vegetables', '1773921286_close-up-fruits_1048944-22503900.avif', 1, '2026-03-19 11:54:46'),
(6, 'Atta, Flours & Sooji', 'atta-flours-sooji', '1773921334_atta-flours-sooji-20240621.webp', 1, '2026-03-19 11:55:34');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'jaydip', 'jaydip@gmail.com', 'delivery related', 'i order with smart_grocery when i get my items', '2025-12-29 05:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boys`
--

CREATE TABLE `delivery_boys` (
  `delivery_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery_boys`
--

INSERT INTO `delivery_boys` (`delivery_id`, `name`, `phone`, `email`, `password`, `status`, `created_at`) VALUES
(1, 'Ravi Kanzariya', '9724682789', 'Ravi@gmail.com', '$2y$10$m04X0df4bfJJQ91wYggjhO9yEdT/UWFu5FH8kibzW.m22bwCmsHj6', 1, '2026-01-07 11:42:31'),
(2, 'Divyang', '9824323465', 'divyang@gmail.com', '$2y$10$Ah08DWkobgBpj0WHZlaNFeysXkClvekc9stYzaN6ORRe1aZHKlysi', 1, '2026-01-07 12:27:32');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `total` decimal(65,2) DEFAULT NULL,
  `collected_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `collected_at` datetime DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','processing','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `address_id` int DEFAULT NULL,
  `delivery_id` int DEFAULT NULL,
  `delivery_status` enum('Pending','Assigned','Out for Pickup','Out for Delivery','Delivered','Undelivered') DEFAULT 'Pending',
  `delivery_otp` varchar(6) DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `delivery_charge` decimal(10,2) DEFAULT '0.00',
  `savings` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `name`, `phone`, `address`, `total`, `collected_amount`, `collected_at`, `payment_method`, `order_date`, `status`, `address_id`, `delivery_id`, `delivery_status`, `delivery_otp`, `delivered_at`, `delivery_charge`, `savings`) VALUES
(1, 1, 'bhavik', '09876543212', 'k.k.v hall, 150 feet ring road, rajkot, Rajkot - 360002', 252.00, 252.00, '2026-03-19 21:31:33', '0', '2026-03-19 15:02:08', 'pending', NULL, 1, 'Delivered', NULL, '2026-03-19 21:31:33', 0.00, 0.00),
(2, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot, Rajkot - 360002', 229.00, 229.00, '2026-03-19 21:49:43', '0', '2026-03-19 15:02:37', 'pending', NULL, 2, 'Delivered', NULL, '2026-03-19 21:49:43', 0.00, 0.00),
(3, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 193.00, 193.00, '2026-03-19 21:35:57', '0', '2026-03-19 15:03:50', 'pending', NULL, 1, 'Delivered', NULL, '2026-03-19 21:35:57', 0.00, 0.00),
(4, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 450.00, 0.00, NULL, NULL, '2026-03-19 15:04:19', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(5, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 72.00, 0.00, NULL, 'Cash', '2026-03-19 15:04:50', 'pending', NULL, 1, 'Undelivered', NULL, NULL, 0.00, 0.00),
(6, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 410.00, 410.00, '2026-03-19 21:50:22', '0', '2026-03-19 15:05:50', 'pending', NULL, 2, 'Delivered', NULL, '2026-03-19 21:50:22', 0.00, 0.00),
(7, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 140.00, 140.00, '2026-03-19 21:41:04', '0', '2026-03-19 15:06:12', 'pending', NULL, 1, 'Delivered', NULL, '2026-03-19 21:41:04', 0.00, 0.00),
(8, 4, 'Chetan Kanzariya', '9924841307', 'racecourse road,jilla panchayat chowk, rajkot,360005, Rajkot - 360005', 240.00, 0.00, NULL, 'Cash', '2026-03-19 15:20:24', 'pending', NULL, 2, 'Undelivered', NULL, NULL, 0.00, 0.00),
(9, 4, 'Chetan Kanzariya', '9924841307', 'racecourse road,jilla panchayat chowk, rajkot,360005, Rajkot - 360005', 80.00, 0.00, NULL, 'Cash', '2026-03-19 15:20:39', 'pending', NULL, 1, 'Out for Delivery', NULL, NULL, 0.00, 0.00),
(10, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 400.00, 0.00, NULL, NULL, '2026-03-19 16:43:39', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(11, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1160.00, 0.00, NULL, NULL, '2026-03-19 16:56:19', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(12, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:11:33', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(13, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:17:57', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(14, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:19:57', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(15, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:21:33', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(16, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:21:36', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(17, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:22:21', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(18, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:23:09', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(19, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:23:57', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(20, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:25:33', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(21, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 1615.00, 0.00, NULL, NULL, '2026-03-19 17:26:22', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(22, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot, Rajkot - 360002', 570.00, 0.00, NULL, NULL, '2026-03-19 17:30:40', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(23, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot, Rajkot - 360002', 570.00, 0.00, NULL, NULL, '2026-03-19 17:33:31', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(24, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot, Rajkot - 360002', 570.00, 0.00, NULL, NULL, '2026-03-19 17:34:02', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(25, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot, Rajkot - 360002', 570.00, 0.00, NULL, NULL, '2026-03-19 17:34:38', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(26, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 375.00, 0.00, NULL, NULL, '2026-03-20 04:29:03', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(27, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 68.00, 0.00, NULL, NULL, '2026-03-20 04:38:12', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(28, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 110.00, 0.00, NULL, NULL, '2026-03-20 04:52:33', 'pending', NULL, NULL, 'Pending', NULL, NULL, 0.00, 0.00),
(29, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 48.00, 0.00, NULL, NULL, '2026-03-20 05:11:54', 'pending', NULL, NULL, 'Pending', NULL, NULL, 30.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `image`, `price`) VALUES
(1, 1, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(2, 1, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(4, 2, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(5, 2, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(8, 3, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(9, 4, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(10, 6, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(11, 8, 1, 113, '1766033094_694386c65fc7f.webp', 110.00),
(12, 8, 6, 5, '1766288712_69476d489e474.webp', 40.00),
(13, 9, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(14, 10, 2, 11, '1766056873_6943e3a9cf140.webp', 78.00),
(15, 10, 3, 1, '1766057140_6943e4b4e6bc3.webp', 78.00),
(16, 10, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(17, 10, 7, 4, '1766288857_69476dd90acd6.webp', 40.00),
(19, 12, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(20, 13, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(23, 15, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(24, 15, 6, 2, '1766288712_69476d489e474.webp', 40.00),
(25, 16, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(26, 17, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(27, 17, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(28, 17, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(29, 18, 6, 1, '1768109318_products1766288712_69476d489e474.webp', 40.00),
(30, 18, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(31, 19, 6, 1, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(32, 19, 3, 2, '1766057140_6943e4b4e6bc3.webp', 78.00),
(33, 19, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(34, 19, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(35, 20, 10, 2, '', 45.00),
(36, 21, 6, 2, '1769493812_products1766288712_69476d489e474.webp', 45.00),
(37, 21, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(38, 21, 14, 1, '1769528114_balaji-simply-salted-potato-wafers-135-g-product-images-o490025528-p490025528-0-202411131812.webp', 38.00),
(39, 21, 13, 1, '', 42.00),
(40, 21, 10, 2, '', 80.00),
(41, 21, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(42, 21, 16, 1, '', 249.00),
(44, 23, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(45, 23, 13, 1, '', 42.00),
(47, 24, 3, 1, '1766057140_6943e4b4e6bc3.webp', 78.00),
(48, 24, 10, 1, '', 45.00),
(49, 24, 13, 1, '', 42.00),
(50, 32, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(51, 33, 16, 1, '', 249.00),
(52, 34, 3, 1, '1769530775_6978e597bba20.webp', 78.00),
(53, 35, 10, 1, '1769530715_6978e55b52951.jpg', 45.00),
(55, 36, 14, 1, '1769530680_6978e53868232.webp', 38.00),
(56, 36, 3, 1, '1769530775_6978e597bba20.webp', 78.00),
(58, 38, 3, 3, '1769530775_6978e597bba20.webp', 78.00),
(59, 39, 3, 20, '1769530775_6978e597bba20.webp', 78.00),
(62, 41, 3, 5, '1769530775_6978e597bba20.webp', 78.00),
(63, 41, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(64, 41, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(65, 41, 16, 6, '1769529049_6978ded90c84b.webp', 249.00),
(66, 42, 1, 1, '1769530805_6978e5b558012.webp', 115.00),
(67, 42, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(68, 42, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(70, 42, 10, 1, '1769530715_6978e55b52951.jpg', 45.00),
(71, 42, 16, 1, '1769529049_6978ded90c84b.webp', 249.00),
(72, 43, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(73, 43, 13, 1, '1769530701_6978e54d39c17.webp', 42.00),
(74, 43, 16, 1, '1769529049_6978ded90c84b.webp', 249.00),
(75, 49, 16, 6, '', 249.00),
(77, 49, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(79, 50, 13, 1, '', 42.00),
(82, 52, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(83, 53, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(84, 74, 16, 5, '1769529049_6978ded90c84b.webp', 249.00),
(85, 74, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(86, 74, 3, 6, '1769530775_6978e597bba20.webp', 83.00),
(87, 74, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(89, 74, 6, 6, '1769530728_6978e568b9171.webp', 40.00),
(91, 76, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(92, 78, 14, 6, '1769530680_6978e53868232.webp', 38.00),
(93, 78, 5, 6, '1769530741_6978e575b6ace.webp', 40.00),
(94, 79, 3, 2, '1769530775_6978e597bba20.webp', 83.00),
(95, 80, 14, 1, '1769530680_6978e53868232.webp', 38.00),
(97, 81, 5, 1, '1769530741_6978e575b6ace.webp', 40.00),
(98, 81, 3, 1, '1769530775_6978e597bba20.webp', 83.00),
(99, 82, 1, 6, '1766033094_694386c65fc7f.webp', 115.00),
(100, 82, 3, 4, '1766057140_6943e4b4e6bc3.webp', 83.00),
(102, 83, 5, 14, '1766288607_69476cdfd88b6.webp', 40.00),
(104, 84, 5, 11, '1766288607_69476cdfd88b6.webp', 40.00),
(107, 86, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(108, 86, 13, 6, '', 42.00),
(109, 86, 1, 6, '1766033094_694386c65fc7f.webp', 115.00),
(111, 87, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(112, 88, 6, 3, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(113, 89, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(114, 90, 3, 1, '1766057140_6943e4b4e6bc3.webp', 83.00),
(115, 90, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(116, 90, 16, 3, '', 249.00),
(117, 91, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(118, 91, 3, 1, '1766057140_6943e4b4e6bc3.webp', 83.00),
(119, 91, 16, 6, '', 249.00),
(121, 93, 5, 6, '1766288607_69476cdfd88b6.webp', 40.00),
(123, 94, 16, 3, '', 249.00),
(124, 95, 1, 1, '1766033094_694386c65fc7f.webp', 115.00),
(125, 95, 6, 2, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(126, 1, 2, 1, '', 50.00),
(127, 1, 3, 1, '', 42.00),
(128, 1, 8, 2, '', 80.00),
(129, 2, 3, 2, '', 42.00),
(130, 2, 6, 1, '', 45.00),
(131, 2, 11, 1, '', 100.00),
(132, 3, 3, 2, '', 42.00),
(133, 3, 11, 1, '', 100.00),
(135, 4, 1, 1, '', 250.00),
(136, 4, 9, 2, '', 60.00),
(137, 4, 10, 1, '', 80.00),
(138, 5, 12, 1, '', 30.00),
(139, 5, 3, 1, '', 42.00),
(140, 6, 4, 2, '', 80.00),
(141, 6, 7, 1, '', 150.00),
(142, 6, 11, 1, '', 100.00),
(143, 7, 2, 1, '', 50.00),
(144, 7, 6, 2, '', 45.00),
(145, 8, 12, 2, '', 30.00),
(146, 8, 11, 1, '', 100.00),
(147, 8, 8, 1, '', 80.00),
(148, 9, 4, 1, '', 80.00),
(149, 10, 2, 2, '', 50.00),
(150, 10, 3, 1, '', 42.00),
(151, 10, 4, 1, '', 80.00),
(152, 10, 10, 2, '', 80.00),
(154, 11, 3, 5, '', 42.00),
(155, 11, 4, 5, '', 80.00),
(156, 11, 8, 5, '', 80.00),
(157, 11, 12, 5, '', 30.00),
(158, 21, 7, 6, '', 150.00),
(159, 21, 8, 5, '', 80.00),
(160, 21, 9, 1, '', 60.00),
(161, 21, 12, 1, '', 30.00),
(162, 21, 11, 1, '', 100.00),
(163, 25, 3, 6, '', 42.00),
(164, 25, 4, 3, '', 80.00),
(165, 25, 5, 2, '', 9.00),
(166, 25, 9, 1, '', 60.00),
(167, 26, 5, 5, '', 9.00),
(168, 26, 2, 6, '', 50.00),
(169, 26, 12, 1, '', 30.00),
(170, 27, 5, 2, '', 9.00),
(171, 27, 2, 1, '', 50.00),
(172, 28, 4, 1, '', 80.00),
(173, 29, 5, 2, '', 9.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_updates`
--

CREATE TABLE `order_updates` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `delivery_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collected_amount` decimal(10,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_updates`
--

INSERT INTO `order_updates` (`id`, `order_id`, `delivery_status`, `payment_method`, `collected_amount`, `created_at`) VALUES
(1, 17, 'Out for Pickup', 'Cash', 190.00, '2026-01-11 10:51:59'),
(2, 18, 'Assigned', 'Cash', 80.00, '2026-01-27 22:02:31'),
(3, 18, 'Delivered', 'Cash', 80.00, '2026-01-27 22:02:51'),
(4, 19, 'Delivered', 'Cash', 346.00, '2026-01-27 22:03:31'),
(5, 20, 'Out for Pickup', 'Cash', 90.00, '2026-01-28 22:01:48'),
(6, 20, 'Delivered', 'Cash', 90.00, '2026-01-28 22:02:08'),
(7, 34, 'Out for Delivery', 'UPI', 78.00, '2026-01-29 18:15:54'),
(8, 34, 'Delivered', 'Cash', 78.00, '2026-01-29 18:16:38'),
(9, 33, 'Delivered', 'Cash', 0.00, '2026-01-29 18:21:05'),
(10, 49, 'Delivered', 'Cash', 1788.00, '2026-02-15 08:49:23'),
(11, 50, 'Delivered', 'Cash', 51.00, '2026-02-15 08:49:37'),
(12, 51, 'Undelivered', 'Cash', 9.00, '2026-02-15 08:49:50'),
(13, 52, 'Delivered', 'Cash', 294.00, '2026-02-18 20:49:16'),
(14, 54, 'Delivered', 'Cash', 744.00, '2026-02-18 20:49:33'),
(15, 91, 'Delivered', 'Cash', 0.00, '2026-02-18 20:49:49'),
(16, 89, 'Delivered', 'Cash', 40.00, '2026-02-18 20:50:08'),
(17, 87, 'Delivered', 'Cash', 249.00, '2026-02-18 20:50:22'),
(18, 85, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:50:42'),
(19, 83, 'Delivered', 'Cash', 560.00, '2026-02-18 20:53:30'),
(20, 81, 'Delivered', 'Cash', 132.00, '2026-02-18 20:53:49'),
(21, 80, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:54:13'),
(22, 78, 'Delivered', 'Cash', 0.00, '2026-02-18 20:54:58'),
(23, 57, 'Delivered', 'Cash', 40.00, '2026-02-18 20:55:26'),
(24, 69, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:55:42'),
(25, 74, 'Delivered', 'Cash', 2229.00, '2026-02-18 20:56:01'),
(26, 73, 'Delivered', 'Cash', 0.00, '2026-02-18 20:56:17'),
(27, 3, 'Undelivered', 'Cash', 0.00, '2026-02-18 20:56:41'),
(28, 6, 'Delivered', 'Cash', 0.00, '2026-02-18 20:56:56'),
(29, 10, 'Delivered', 'Cash', 1136.00, '2026-02-18 20:57:14'),
(30, 72, 'Undelivered', 'UPI', 0.00, '2026-02-18 20:57:31'),
(31, 70, 'Undelivered', 'Prepaid', 0.00, '2026-02-18 20:57:47'),
(32, 8, 'Undelivered', 'Prepaid', 0.00, '2026-02-18 20:58:28'),
(33, 2, 'Delivered', 'Cash', 0.00, '2026-02-18 20:59:04'),
(34, 4, 'Undelivered', 'Cash', 40.00, '2026-03-09 10:46:12'),
(35, 5, 'Undelivered', 'Cash', 0.00, '2026-03-09 10:47:04'),
(36, 94, 'Out for Pickup', 'Cash', 783.00, '2026-03-09 10:47:56'),
(37, 94, 'Delivered', 'Cash', 783.00, '2026-03-09 10:49:11'),
(38, 1, 'Delivered', 'Cash', 252.00, '2026-03-19 21:31:33'),
(39, 3, 'Delivered', 'Cash', 193.00, '2026-03-19 21:35:57'),
(40, 5, 'Undelivered', 'Cash', 0.00, '2026-03-19 21:38:40'),
(41, 7, 'Delivered', 'Cash', 140.00, '2026-03-19 21:41:04'),
(42, 9, 'Out for Delivery', 'Cash', 80.00, '2026-03-19 21:43:28'),
(43, 2, 'Delivered', 'Cash', 229.00, '2026-03-19 21:49:43'),
(44, 6, 'Delivered', 'Cash', 410.00, '2026-03-19 21:50:22'),
(45, 8, 'Undelivered', 'Cash', 240.00, '2026-03-19 21:51:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `mrp` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock_qty` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `status` tinyint DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `product_name`, `short_description`, `price`, `mrp`, `stock_qty`, `image`, `description`, `status`) VALUES
(1, 1, 'Haldiram Mini Kaju Katli 250gm', 'Haldiram Mini Kaju Katli 250gm', 250.00, 300.00, 24, NULL, 'Brand	HALDIRAM\r\nManufacturer	HARRSHIV HEALTHY FOODS & MORE PVT. LTD.\r\nManufacturer Address	\r\nHARRSHIV HEALTHY FOODS & MORE PVT. LTD.\r\nKh. No. 98/1 Ka, 98/2 Ka, 100/1 To 100/5, Vill. Dhargaon, Tah. Kamptee, Dist. Nagpur, Maharashtra, India - 441104\r\n\r\nManufacturer Email	customercare@haldirams.com\r\nManufacturer Website	https://www.haldirams.com/\r\nSold By	Smart Grocery Store\r\nSmart Grocery Customer Care Phone	1800 890 1222\r\nIncluded Components	Mini-Kaju-Katli\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	HARRSHIV HEALTHY FOODS & MORE PVT. LTD.\r\nManufacturer E-mail	customercare@haldirams.com\r\nManufacturer Contact Number	9209109999\r\nManufacturer Address	Kh. No. 98/1 Ka, 98/2 Ka, 100/1 To 100/5, Vill. Dhargaon, Tah. Kamptee, Dist. Nagpur, Maharashtra, India - 441104\r\nProduct Details\r\nNet Quantity	250 g\r\nUsage Details\r\nProduct Type	Tinned & Packed Sweets\r\nProduct Specifications\r\nProduct Type	Tinned & Packed Sweets\r\nItem Dimensions\r\nNet Weight	250 g\r\nNet Quantity	250 g', 1),
(2, 1, 'Snactac Celebrations Soan Papdi, Cardamom & Dryfruit 200 g', 'Snactac Celebrations Soan Papdi, Cardamom & Dryfruit 200 g', 50.00, 80.00, 14, NULL, 'Brand	Snactac\r\nManufacturer	NAVHARI FOOD PRODUCTS PVT LTD\r\nManufacturer Address	\r\nNAVHARI FOOD PRODUCTS PVT LTD\r\nNAVHARI FOOD PRODUCTS PVT. LTD.  F-210,BICHHWAL INDUSTIRAL AREA, BIKANER, 334006, Rajasthan India - 334006\r\n\r\nManufacturer Email	bcsons@gmail.com\r\nManufacturer Website	www.bhikharamchandmal.in\r\nSold By Smart Grocery Customer Care Phone	1800 890 1222\r\nIncluded Components	Soan Papdi 200 g\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	NAVHARI FOOD PRODUCTS PVT LTD\r\nManufacturer E-mail	bcsons@gmail.com\r\nManufacturer Contact Number	1512225232\r\nManufacturer Address	NAVHARI FOOD PRODUCTS PVT. LTD.  F-210,BICHHWAL INDUSTIRAL AREA, BIKANER, 334006, Rajasthan India - 334006\r\nProduct Details\r\nNet Quantity	200 g\r\nUsage Details\r\nProduct Type	Tinned & Packed Sweets\r\nProduct Specifications\r\nProduct Type	Tinned & Packed Sweets\r\nItem Dimensions\r\nHeight	45 mm\r\nLength	145 mm\r\nWidth	110 mm\r\nNet Quantity	200 g', 1),
(3, 2, 'Balaji wafers Farali Chevdo 235 g', 'Balaji wafers Farali Chevdo 235 g', 42.00, 45.00, 32, NULL, 'Brand	Balaji wafers\r\nManufacturer	Balaji Wefers Pvt. Ltd.\r\nManufacturer Address	\r\nBalaji Wafers Pvt Ltd\r\nKalawad Road Near Iocl Petrol Pump Vajdi, Ta, Lodhika, Gujarat 360021\r\n\r\nManufacturer Email	contact@balajiwafers.com\r\nManufacturer Website	https://www.balajiwafers.com\r\nSold By	Smart Grocery  Customer Care Phone	1800 890 1222\r\nIncluded Components	Balaji wafers Farali Chevdo 235 g\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Balaji Wefers Pvt. Ltd.\r\nManufacturer E-mail	contact@balajiwafers.com\r\nManufacturer Contact Number	(0281) 2783755\r\nManufacturer Address	Kalawad Road Near Iocl Petrol Pump Vajdi, Ta, Lodhika, Gujarat 360021\r\nProduct Specifications\r\nProduct Type	Others\r\nHow To Use	Available on the image\r\nStorage Category	Normal storage\r\nStorage Temperature Limit (in Degree Celsius)	Normal Warehouse Temperature\r\nIngredients	Available on the Image\r\nNutrient Content	Available on the image\r\nFSSAI Number	10012021000039\r\nAdditives	Available on the image\r\nDietary Preference	NA\r\nAllergens Included	Available on the Image\r\nNet Quantity	235 g\r\nNutrition	Available on the image', 1),
(4, 2, 'Gopal Bhavnagari Gathiya-500g', 'Balaji wafers Farali Chevdo 235 g', 80.00, 84.00, 37, NULL, 'General Information\r\nBrand	Gopal\r\nManufacturer	Gopal Snacks Pvt. Ltd.,\r\nManufacturer Address	\r\nGopal Snacks Pvt. Ltd.,\r\nG-2, Survey No. 435/1A, 432, Pawaddauna Road, NH-6, Village Mouda, Nagpur, 441104\r\n\r\nSold By	Smart Grocery Customer Care Phone	1800 890 1222\r\nIncluded Components	Bhavnagari Gathiya 500 g\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Gopal Snacks Pvt. Ltd.,\r\nManufacturer Address	G-2, Survey No. 435/1A, 432, Pawaddauna Road, NH-6, Village Mouda, Nagpur, 441104\r\nProduct Specifications\r\nProduct Type	Savoury Snacks\r\nHow To Use	Available on the Image\r\nStorage Category	Normal storage\r\nStorage Temperature Limit (in Degree Celsius)	Normal Warehouse Temperature\r\nIngredients	Available on the Image\r\nNutrient Content	Available on the Image\r\nAdditives	Available on the Image\r\nDietary Preference	Available on the Image\r\nAllergens Included	Available on the Image\r\nHazardous Material	No\r\nNet Quantity	500 g\r\nProduct Type	Namkeen & Savoury Snacks\r\nItem Dimensions\r\nHeight	217 mm\r\nLength	60 mm\r\nWidth	190 mm\r\nNet Quantity	500 g', 1),
(5, 3, 'nestle-classic-choclate-15g', 'nestle-classic-choclate-15g', 9.00, 10.00, 36, NULL, 'General Information\r\nBrand	Nestle\r\nManufacturer	Nestle India Ltd.\r\nManufacturer Address	\r\nNestle India Ltd.\r\n100/101, World Trade Centre, Barakhamba Lane, At: Plot No. 294-297, Usgao, Ponda - 403406 (Goa)\r\n\r\nManufacturer Email	wecare@in.nestle.com\r\nManufacturer Website	www.nestle.in\r\nSold By Smart Grocery Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Nestle India Ltd.\r\nManufacturer E-mail	wecare@in.nestle.com\r\nManufacturer Contact Number	18001031947\r\nManufacturer Address	100/101, World Trade Centre, Barakhamba Lane, At: Plot No. 294-297, Usgao, Ponda - 403406 (Goa)\r\nProduct Details\r\nNet Quantity	15 g\r\nUsage Details\r\nProduct Type	Other Chocolates\r\nProduct Specifications\r\nProduct Type	Chocolates\r\nItem Dimensions\r\nHeight	38 mm\r\nLength	90 mm\r\nWidth	6 mm\r\nNet Quantity	15 g', 1),
(6, 3, 'Cadbury Dairy Milk Fruit & Nut Chocolate Bar 36 g', 'Cadbury Dairy Milk Fruit & Nut Chocolate Bar 36 g', 45.00, 50.00, 46, NULL, 'General Information\r\nBrand	Cadbury\r\nManufacturer	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	\r\nMondelez India Foods Pvt. Ltd\r\nMondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\n\r\nSold By	Smart Grocery Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	Mondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\nProduct Details\r\nNet Quantity	80 g\r\nUsage Details\r\nProduct Type	Other Chocolates\r\nProduct Specifications\r\nProduct Type	Chocolates\r\nItem Dimensions\r\nHeight	96 mm\r\nLength	47 mm\r\nWidth	10 mm\r\nNet Quantity	36 g', 1),
(7, 4, 'Good Life Tur Dal 1 kg', 'Good Life Tur Dal 1 kg', 150.00, 200.00, 43, NULL, 'Net Quantity	1 N\r\nUsage Details\r\nProduct Type	Plain Toor Dal\r\nProduct Specifications\r\nSold By Smart Grocery \r\nProduct Type	Toor Dal\r\nItem Dimensions\r\nHeight	1 mm\r\nLength	1 mm\r\nWidth	1 mm\r\nNet Quantity	1 N', 1),
(8, 4, 'Good Life Kabuli Chana 500 g', 'Good Life Kabuli Chana 500 g', 80.00, 120.00, 37, NULL, 'Brand	Good Life\r\nManufacturer	Private Label\r\nManufacturer Address	\r\nReliance Retail Ltd.\r\n5R Value Creations At: Gate No. 5, 103-106, Gidc, Naroda, Ahmedabad 382330 Gujarat.\r\n\r\nSold By	Smart Grocery Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Private Label\r\nManufacturer Address	5R Value Creations At: Gate No. 5, 103-106, Gidc, Naroda, Ahmedabad 382330 Gujarat.\r\nProduct Details\r\nNet Quantity	500 g\r\nUsage Details\r\nProduct Type	Kabuli Chana\r\nProduct Specifications\r\nProduct Type	Kabuli Chana\r\nItem Dimensions\r\nHeight	180 mm\r\nLength	140 mm\r\nWidth	35 mm\r\nNet Quantity	500 g', 1),
(9, 5, 'Grapes Sonaka Pack (Approx 450 g - 600 g)', 'Grapes Sonaka Pack (Approx 450 g - 600 g)', 60.00, 75.00, 21, NULL, 'Product Details\r\nNet Quantity	Approx 450 g - 600 g\r\nUsage Details\r\nProduct Type	Grapes\r\nProduct Specifications\r\nProduct Type	Grapes\r\nItem Dimensions\r\nHeight	1 mm\r\nLength	1 mm\r\nWidth	1 mm\r\nNet Quantity	450 g \r\nSold By Smart Grocery', 1),
(10, 5, 'Pineapple Queen 1 pc (Approx 700 g - 1200 g)', 'Pineapple Queen 1 pc (Approx 700 g - 1200 g)', 80.00, 100.00, 21, NULL, 'General Information\r\nBrand	Private Label\r\nManufacturer	Private Label\r\nManufacturer Address	\r\nPrivate Label\r\nFresh Produce\r\n\r\nSold By	Smart Grocery Customer Care Phone	1800 890 1222\r\nIncluded Components	1 pc Pineapple\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Private Label\r\nManufacturer Address	Fresh Produce\r\nProduct Details\r\nNet Quantity	1 pc\r\nUsage Details\r\nProduct Type	Pineapple\r\nProduct Specifications\r\nProduct Type	Citrus Fruits\r\nItem Dimensions\r\nHeight	1 mm\r\nLength	1 mm\r\nWidth	1 mm\r\nNet Quantity	1 Pieces', 1),
(11, 6, 'Fortune Besan 1kg', 'Fortune Besan 1kg', 100.00, 120.00, 45, NULL, 'General Information\r\nBrand	Fortune\r\nManufacturer	Adani Wilmar Ltd.\r\nManufacturer Address	\r\nAdani Wilmar Ltd.\r\nFortune House 2, Nr Navrangpura Rly Crossing, Ahmedabad 380 009, Gujarat, India\r\n\r\nManufacturer Email	care@adaniwilmar.in\r\nManufacturer Website	www.adaniwilmar.com\r\nSold By Smart Grocery Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Adani Wilmar Ltd.\r\nManufacturer E-mail	care@adaniwilmar.in\r\nManufacturer Contact Number	18005729999\r\nManufacturer Address	Fortune House 2, Nr Navrangpura Rly Crossing, Ahmedabad 380 009, Gujarat, India\r\nProduct Details\r\nNet Quantity	1 kg\r\nProduct Specifications\r\nProduct Type	Besan\r\nItem Dimensions\r\nHeight	270 mm\r\nLength	50 mm\r\nWidth	150 mm\r\nNet Quantity	1 kg', 1),
(12, 6, 'Uttam sooji 500g', 'Uttam Sooji 500g', 30.00, 33.00, 41, NULL, 'General Information\r\nBrand	Uttam\r\nManufacturer	Shree Bhagwati Flour & Foods\r\nManufacturer Address	\r\nShree Bhagwati Flour & Foods\r\nSurvey No.430, Sarkhej - Bavla Highway, Changodar (Moraiya), Ahmedabad - 382213 (India)\r\n\r\nSold By	Smart Grocery Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Shree Bhagwati Flour & Foods\r\nManufacturer Contact Number	1204525000\r\nManufacturer Address	Survey No.430, Sarkhej - Bavla Highway, Changodar (Moraiya), Ahmedabad - 382213 (India)\r\nProduct Details\r\nNet Quantity	500 g\r\nProduct Specifications\r\nProduct Type	Rawa/Sooji\r\nItem Dimensions\r\nHeight	200 mm\r\nLength	150 mm\r\nWidth	40 mm\r\nNet Quantity	500 g', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `image_id` int NOT NULL,
  `product_id` int NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`image_id`, `product_id`, `image`, `created_at`) VALUES
(1, 1, '1773922248_69bbe7c8c8008.webp', '2026-03-19 12:10:48'),
(2, 2, '1773922423_69bbe87787523.webp', '2026-03-19 12:13:43'),
(3, 3, '1773922618_69bbe93a9dec8.webp', '2026-03-19 12:16:58'),
(4, 4, '1773922730_69bbe9aa1d9c0.webp', '2026-03-19 12:18:50'),
(5, 5, '1773922901_69bbea55bdab3.webp', '2026-03-19 12:21:41'),
(6, 6, '1773923123_69bbeb335871c.jpg', '2026-03-19 12:25:23'),
(7, 7, '1773923303_69bbebe747226.webp', '2026-03-19 12:28:23'),
(8, 8, '1773923478_69bbec96c8436.webp', '2026-03-19 12:31:18'),
(9, 9, '1773923642_69bbed3aaab79.webp', '2026-03-19 12:34:02'),
(10, 10, '1773923761_69bbedb1d2182.webp', '2026-03-19 12:36:01'),
(11, 11, '1773923936_69bbee6025a65.webp', '2026-03-19 12:38:56'),
(12, 12, '1773924058_69bbeeda5a80a.webp', '2026-03-19 12:40:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `phone`, `email`, `password`, `role`, `address`, `city`, `pincode`) VALUES
(1, 'Bhavik', '8975234526', 'bhavik@gmail.com', '$2y$10$WYWKzjMgPrqZfgAEmtdAoOdTem5V0M8XoNY0THRX.ii5tSMzda.MC', 'user', NULL, NULL, NULL),
(2, 'jaydip', '9823467542', 'jaydip@gmail.com', '$2y$10$UHOe/p/oN7Gc2lGk6bbwYOs35Q4TYbgBCeNR.lr/Tj3wnhh4FHzfG', 'user', 'mavdi chokdi, 150-feet ring road, rajkot', 'rajkot', '360005'),
(3, 'jay', '1234567889', 'jay@gmail.com', '$2y$10$euy33MUKamItXLHkxzlvjOjA/ZkuvQY0gHm6SkgUXngZEN3S91lBC', 'user', 'Hanuman Madhi, Raiya Road, Rajkot', 'Rajkot', '360007'),
(4, 'chetan', '9878234569', 'chetan@gmail.com', '$2y$10$Qgm/FsLKpYYjjVQKrzPIl.JrrELzfjkJWJ/bt1jKUDbsoNR8slvIa', 'user', NULL, NULL, NULL),
(5, 'Ashish', '9157230155', 'Ashish@gmail.com', '$2y$10$NoUdHQFAIj1w/wGKVHuH5e9sg9z4JwlXwADUBNs8gB0yHhvfnnBjS', 'user', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `address_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `is_default` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`address_id`, `user_id`, `name`, `phone`, `address`, `city`, `pincode`, `is_default`, `created_at`) VALUES
(1, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot', 'Rajkot', '360007', 0, '2026-01-06 06:03:00'),
(2, 3, 'Ashish Parmar', '9157230156', 'Hanuman Madhi, Raiya Road, Rajkot                                ', 'Rajkot', '360007', 0, '2026-01-06 06:39:43'),
(3, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot', 'Rajkot', '360002', 1, '2026-01-06 11:15:07'),
(6, 1, 'bhavik', '09876543212', 'Astron chowk,rajkot', 'Rajkot', '360002', 0, '2026-01-29 12:37:12'),
(7, 1, 'bhavik', '09876543212', 'k.k.v hall, 150 feet ring road, rajkot', 'Rajkot', '360002', 0, '2026-01-29 12:38:00'),
(9, 4, 'Chetan Kanzariya', '9924841307', 'racecourse road,jilla panchayat chowk, rajkot,360005', 'Rajkot', '360005', 0, '2026-03-19 15:20:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `fk_orders_users` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_updates`
--
ALTER TABLE `order_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_category` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  MODIFY `delivery_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;

--
-- AUTO_INCREMENT for table `order_updates`
--
ALTER TABLE `order_updates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `image_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `address_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_orders_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
