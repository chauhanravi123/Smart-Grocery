<?php
include 'admin_auth.php';
include '../includes/db.php';

/* ================= FILTER INPUT ================= */
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : '';

/* ================= REVENUE QUERY ================= */
$revenue_sql = "SELECT SUM(total) AS total_revenue 
                FROM orders 
                WHERE delivery_status = 'Delivered'";

$rev_params = [];
$rev_types = "";

// Date filter for revenue
if (!empty($start_date) && !empty($end_date)) {
    $revenue_sql .= " AND DATE(order_date) BETWEEN ? AND ?";
    $rev_types .= "ss";
    $rev_params[] = $start_date;
    $rev_params[] = $end_date;
}

$rev_stmt = $conn->prepare($revenue_sql);

if ($rev_stmt) {
    if (!empty($rev_types)) {
        $rev_stmt->bind_param($rev_types, ...$rev_params);
    }
    $rev_stmt->execute();
    $rev_result = $rev_stmt->get_result()->fetch_assoc();
    $totalRevenue = $rev_result['total_revenue'] ?? 0;
} else {
    $totalRevenue = 0;
}

/* ================= ORDERS QUERY ================= */
$sql = "SELECT o.*, d.delivery_id, d.name AS delivery_name, d.phone AS delivery_phone 
        FROM orders o 
        LEFT JOIN delivery_boys d ON o.delivery_id = d.delivery_id";

$conditions = [];
$params = [];
$types = "";

// Only Delivered Orders
$conditions[] = "o.delivery_status = 'Delivered'";

// Search (Order ID or Phone)
if (!empty($search)) {
    $conditions[] = "(o.order_id = ? OR o.phone LIKE ?)";
    $types .= "ss";
    $params[] = $search;
    $params[] = "%" . $search . "%";
}

// Date range filter
if (!empty($start_date) && !empty($end_date)) {
    $conditions[] = "DATE(o.order_date) BETWEEN ? AND ?";
    $types .= "ss";
    $params[] = $start_date;
    $params[] = $end_date;
}

// Final query build
if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY o.order_id DESC";

// Execute query
$stmt = $conn->prepare($sql);

if ($stmt) {
    if (!empty($types)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $orders = $stmt->get_result();
} else {
    $orders = $conn->query($sql);
}
?>

<link rel="stylesheet" href="assets/css/admin.css">

<div class="table-section">

    <!-- ================= HEADER ================= -->
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:15px;flex-wrap:wrap;">
        <h2 style="margin:0">Delivered Orders Report</h2>

        <!-- FILTER FORM -->
        <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;">
            <input type="text" name="search" placeholder="Order ID or Phone"
                value="<?= htmlspecialchars($search) ?>">

            <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>">
            <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">

            <button class="btn" type="submit">Filter</button>
            <a class="btn btn-outline" href="orders.php">Reset</a>
        </form>
    </div>

    <!-- ================= REVENUE CARD ================= -->
    <div style="background:#28a745;color:#fff;padding:15px;border-radius:8px;margin-bottom:15px;">
        <h3 style="margin:0;">
            Total Revenue (Delivered Orders): ₹<?= number_format($totalRevenue,2) ?>
        </h3>
    </div>

    <!-- ================= TABLE ================= -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Phone</th>
                <th>Total</th>
                <th>Address</th>
                <th>Status</th>
                <th>Date</th>
                <th>Delivery Boy</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

        <?php if ($orders->num_rows > 0): ?>
            <?php while ($row = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['order_id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['phone']) ?></td>
                    <td>₹<?= number_format($row['total'], 2) ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td><?= htmlspecialchars($row['delivery_status']) ?></td>
                    <td><?= date('d M Y', strtotime($row['order_date'])) ?></td>
                    <td><?= htmlspecialchars($row['delivery_name'] ?? '-') ?></td>
                    <td>
                        <a class="btn btn-outline" href="order_details.php?id=<?= $row['order_id'] ?>">View</a>
                        <a class="btn" href="bill.php?id=<?= $row['order_id'] ?>" target="_blank">Bill</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="9" style="text-align:center;">No delivered orders found.</td>
            </tr>
        <?php endif; ?>

        </tbody>
    </table>
</div>