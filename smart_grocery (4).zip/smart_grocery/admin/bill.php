<?php
include 'admin_auth.php'; // Ensures admin is logged in
include '../includes/db.php';

// Get Order ID
$order_id = (int)($_GET['id'] ?? 0);
if ($order_id <= 0) die("Invalid Order ID.");

// Fetch Order Details
$stmt = $conn->prepare("SELECT o.*, u.name AS user_name, o.delivery_charge AS user_delivery_charge, u.phone AS user_phone FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.order_id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) die("Order not found.");

// Fetch Items with MRP for savings calculation
$items = $conn->query("
    SELECT 
        oi.product_id,
        p.product_name,
        p.mrp,
        SUM(oi.quantity) AS quantity,
        MAX(oi.price) AS selling_price,
        SUM(oi.quantity * oi.price) AS total
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    WHERE oi.order_id = $order_id
    GROUP BY oi.product_id, p.product_name, p.mrp
");

// Calculate Totals
$total_items = 0;
$total_qty = 0;
$total_mrp = 0;
$total_savings = 0;
$grand_total = 0;

$items_list = [];
while ($row = $items->fetch_assoc()) {
    $items_list[] = $row;
    $qty = (int)$row['quantity'];
    $price = (float)$row['selling_price'];
    $mrp = (float)($row['mrp'] ?? $price);

    $total_items++;
    $total_qty += $qty;
    $total_mrp += ($mrp * $qty);
    $grand_total += ($price * $qty);
}
$subtotal = $grand_total; // rename meaning
$delivery_charge = (float)($order['delivery_charge'] ?? 0);
$final_total = $subtotal + $delivery_charge;
$total_savings = $total_mrp - $grand_total;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= $order_id ?></title>

    <style>
        /* --- BASE & NAVBAR STYLES (Added directly to fix display issues) --- */
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Navbar Styles */
        .navbar {
            background: #0d6efd;
            color: #fff;
            padding: 14px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
            font-size: 15px;
            transition: opacity 0.2s;
        }

        .navbar a:hover {
            opacity: 0.8;
        }

        .navbar .logo {
            font-size: 18px;
            font-weight: bold;
        }

        /* --- BILL SPECIFIC STYLES --- */
        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .bill-paper {
            max-width: 800px;
            margin: 30px auto;
            background: #fff;
            padding: 40px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            border-top: 5px solid #0d6efd;
        }

        .bill-header {
            display: flex;
            justify-content: space-between;
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .brand h2 {
            margin: 0;
            color: #0d6efd;
        }

        .brand p {
            margin: 5px 0 0;
            color: #666;
            font-size: 13px;
        }

        .invoice-meta {
            text-align: right;
        }

        .invoice-meta h3 {
            margin: 0;
            color: #333;
        }

        .invoice-meta p {
            margin: 3px 0;
            font-size: 13px;
            color: #666;
        }

        .customer-box {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .info-col h4 {
            margin: 0 0 8px;
            font-size: 12px;
            text-transform: uppercase;
            color: #888;
        }

        .info-col p {
            margin: 0;
            font-size: 14px;
            font-weight: 500;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th {
            text-align: left;
            padding: 12px;
            background: #f1f1f1;
            border-bottom: 2px solid #ddd;
            font-size: 13px;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }

        .text-right {
            text-align: right;
        }

        .totals-wrapper {
            width: 300px;
            margin-left: auto;
        }

        .calc-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            font-size: 14px;
        }

        .calc-row.savings {
            color: #28a745;
            font-weight: 600;
        }

        .calc-row.grand-total {
            border-top: 2px solid #333;
            margin-top: 10px;
            padding-top: 15px;
            font-size: 20px;
            font-weight: 700;
        }

        .footer-note {
            text-align: center;
            margin-top: 50px;
            font-size: 12px;
            color: #999;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }

        .actions-bar {
            text-align: center;
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 24px;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            border: none;
            font-size: 14px;
        }

        .btn-print {
            background: #0d6efd;
            color: #fff;
        }

        .btn-back {
            background: #6c757d;
            color: #fff;
            margin-left: 10px;
        }

        /* PRINT STYLES */
        @media print {

            .navbar,
            .actions-bar,
            .btn-back {
                display: none !important;
            }

            body {
                background: #fff;
            }

            .dashboard-container {
                padding: 0;
            }

            .bill-paper {
                box-shadow: none;
                border: 1px solid #ccc;
                margin: 0;
                width: 100%;
                max-width: 100%;
            }
        }
    </style>
</head>

<body>

    <!-- Navbar Section -->
    <div class="navbar">
        <div class="logo">
            <a href="index.php" style="margin-left:0;"><b>🛒 SmartGrocery Admin</b></a>
        </div>
        <div>
            <a href="orders.php">Orders</a>
            <!-- <a href="products.php">Products</a> -->
            <a href="admin_logout.php">Logout</a>
        </div>
    </div>

    <div class="dashboard-container">

        <div class="bill-paper">
            <!-- Bill Header -->
            <div class="bill-header">
                <div class="brand">
                    <h2>Smart Grocery</h2>
                    <p>123 Market Street, City</p>
                    <p>GSTIN: 29AAAAA0000A1Z5</p>
                </div>
                <div class="invoice-meta">
                    <h3>TAX INVOICE</h3>
                    <p><strong>Bill No:</strong> #<?= $order_id ?></p>
                    <p><strong>Date:</strong> <?= date('d M Y', strtotime($order['order_date'])) ?></p>
                    <p><strong>Time:</strong> <?= date('h:i A', strtotime($order['order_date'])) ?></p>
                </div>
            </div>

            <!-- Customer Info -->
            <div class="customer-box">
                <div class="info-col">
                    <h4>Billed To</h4>
                    <p><?= htmlspecialchars($order['user_name'] ?? $order['name']) ?></p>
                    <p><?= htmlspecialchars($order['user_phone'] ?? $order['phone']) ?></p>
                </div>
                <div class="info-col" style="text-align: right;">
                    <h4>Shipping Address</h4>
                    <p><?= htmlspecialchars($order['address']) ?></p>
                </div>
            </div>

            <!-- Items Table -->
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Item Name</th>
                        <th class="text-right">MRP</th>
                        <th class="text-right">Price</th>
                        <th class="text-right">Qty</th>
                        <th class="text-right">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;
                    foreach ($items_list as $item):
                        $lineTotal = $item['total'];
                    ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td class="text-right">₹<?= number_format($item['mrp'], 2) ?></td>
                            <td class="text-right">₹<?= number_format($item['selling_price'], 2) ?></td>
                            <td class="text-right"><?= $item['quantity'] ?></td>
                            <td class="text-right">₹<?= number_format($lineTotal, 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Totals -->
            <div class="totals-wrapper">

                <div class="calc-row">
                    <span>Total Items:</span>
                    <span><?= $total_qty ?></span>
                </div>

                <div class="calc-row">
                    <span>Sub Total:</span>
                    <span>₹<?= number_format($subtotal, 2) ?></span>
                </div>

                <?php if ($total_savings > 0): ?>
                    <div class="calc-row savings">
                        <span>Total Savings:</span>
                        <span>- ₹<?= number_format($total_savings, 2) ?></span>
                    </div>
                <?php endif; ?>

                <div class="calc-row">
                    <span>Delivery Charge:</span>
                    <span>
                        <?= $delivery_charge > 0 ? "₹" . number_format($delivery_charge, 2) : "FREE" ?>
                    </span>
                </div>

                <div class="calc-row grand-total">
                    <span>Grand Total:</span>
                    <span>₹<?= number_format($final_total, 2) ?></span>
                </div>

            </div>

            <div class="footer-note">
                <p>Thank you for shopping with Smart Grocery!</p>
            </div>

            <!-- Action Buttons -->
            <div class="actions-bar no-print">
                <button onclick="window.print()" class="btn btn-print">🖨️ Print Invoice</button>
                <a href="orders.php" class="btn btn-back">← Back to Orders</a>
            </div>

        </div>
    </div>

</body>

</html>