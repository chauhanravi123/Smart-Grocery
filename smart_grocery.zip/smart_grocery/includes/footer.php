<footer class="footer">
    <div class="footer-container">

        <!-- Column 1 -->
        <div class="footer-box">
            <h4>Smart Grocery</h4>
            <p>Your daily grocery needs delivered fresh and fast.</p>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>

        <!-- Column 2 -->
        <div class="footer-box">
            <h4>Company</h4>
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Our Stores</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </div>

        <!-- Column 3 -->
        <div class="footer-box">
            <h4>Help & Support</h4>
            <ul>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Shipping Policy</a></li>
                <li><a href="#">Return Policy</a></li>
                <li><a href="#">Cancellation</a></li>
            </ul>
        </div>

        <!-- Column 4 -->
        <div class="footer-box">
            <h4>Categories</h4>
            <ul>
                <li><a href="#">Fruits & Vegetables</a></li>
                <li><a href="#">Dairy & Bakery</a></li>
                <li><a href="#">Staples</a></li>
                <li><a href="#">Snacks & Beverages</a></li>
            </ul>
        </div>

    </div>

    <!-- Bottom Footer -->
    <div class="footer-bottom">
        <p>© <?php echo date("Y"); ?> Smart Grocery Store. All Rights Reserved.</p>
    </div>
</footer>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
