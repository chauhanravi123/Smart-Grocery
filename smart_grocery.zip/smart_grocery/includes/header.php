<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$cartCount = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
?>

<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/footer.css">
<header class="navbar">
    <div class="nav-container">

        <div class="logo">
            <a href="index.php">🛒 Smart Grocery</a>
        </div>

        <!--  <form class="nav-search">
            <input type="text" placeholder="Search products">
            <button>🔍</button>
        </form> -->

        <nav class="nav-links" id="navLinks">
            <a href="../index.php">Home</a>
            <a href="../category.php">Categories</a>
            <a href="#">Offers</a>
            <a href="../contact.php">Contact</a>
            <a href="../products.php">Products</a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user/logout.php">Logout</a>
            <?php } else { ?>
                <a href="user/login.php">Login</a>
            <?php } ?>
            <a href="user/profile.php">My Profile</a>


        </nav>

        <div class="nav-icons">
            <a href="cart.php">
                🛒 <span class="cart-count"><?= $cartCount ?></span>
            </a>
            <span class="menu-toggle" onclick="toggleMenu()">☰</span>
        </div>


    </div>
</header>
<script>
function toggleMenu(){
    document.getElementById("navLinks").classList.toggle("show");
}
</script>
