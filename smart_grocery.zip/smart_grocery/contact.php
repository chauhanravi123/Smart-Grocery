<?php
include 'includes/db.php';
include 'includes/header.php';

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if ($name && $email && $subject && $message) {

        $stmt = $conn->prepare(
            "INSERT INTO contactus (name, email, subject, message) 
             VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param("ssss", $name, $email, $subject, $message);

        if ($stmt->execute()) {
            $success = "Thank you! We will contact you soon.";
        } else {
            $error = "Something went wrong. Try again!";
        }

    } else {
        $error = "All fields are required!";
    }
}
?>
<link rel="stylesheet" href="assets/css/contact.css">
<link rel="stylesheet" href="assets/css/style.css">
<div class="contact-container">

    <h2>Contact Us</h2>

    <?php if($success): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <?php if($error): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <input type="text" name="subject" placeholder="Subject" required>
        <textarea name="message" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
    </form>

</div>

<?php include 'includes/footer.php'; ?>
