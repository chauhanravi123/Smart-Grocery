-- Migration: add payment_method to orders
-- Run this once (e.g. in MySQL client or phpMyAdmin)

ALTER TABLE `orders`
  ADD COLUMN `payment_method` VARCHAR(50) NULL AFTER `collected_at`;
