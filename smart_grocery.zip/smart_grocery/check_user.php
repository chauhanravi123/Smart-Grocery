<?php
include 'includes/db.php';
session_start();
$response = ['phone' => false, 'email' => false];
if (!empty($_POST['phone']) || !empty($_POST['email'])) {
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';

    $check = $conn->prepare("SELECT phone, email FROM users WHERE phone=? OR email=?");
    $check->bind_param("ss", $phone, $email);
    $check->execute();
    $result = $check->get_result();

    while ($row = $result->fetch_assoc()) {
        if ($row['phone'] === $phone) {
            $response['phone'] = true;
        }
        if ($row['email'] === $email) {
            $response['email'] = true;
        }
    }
}
echo json_encode($response);
