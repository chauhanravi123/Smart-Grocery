<?php
include 'includes/db.php';
include 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/style.css">
<link rel="stylesheet" href="assets/css/category.css">
<!-- Offer Slider Start -->
<div class="offer-slider">
    <div class="slides active">
        <img src="assets/images/offer3.jpg" alt="Offer 1">
        <div class="caption">
            <h2>Fresh Fruits & Vegetables</h2>
            <p>Get up to 20% off on all fresh produce!</p>
        </div>
    </div>
    <div class="slides">
        <img src="assets/images/offer1.jpg" alt="Offer 2">
        <div class="caption">
            <h2>Dairy Products Sale</h2>
            <p>Buy 1 Get 1 Free on selected dairy items!</p>
        </div>
    </div>
    <div class="slides">
        <img src="assets/images/offer2.jpg" alt="Offer 3">
        <div class="caption">
            <h2>Snacks & Beverages</h2>
            <p>Flat 15% off on all snacks and beverages!</p>
        </div>
    </div>
</div>
<!-- Offer Slider End -->

<h3 style="text-align:center; margin-top:20px;">Welcome to Smart Grocery</h3>
<div class="category-grid">
<?php
$cat_res = $conn->query("SELECT * FROM categories WHERE status=1");
while($cat = $cat_res->fetch_assoc()){ ?>
    <div class="category-card">
        <a href="category.php?slug=<?php echo $cat['slug']; ?>">
            <div class="category-img">
                <img src="assets/images/categories/<?php echo $cat['image']; ?>" 
                     alt="<?php echo $cat['category_name']; ?>">
            </div>
            <h4><?php echo $cat['category_name']; ?></h4>
        </a>
    </div>
<?php } ?>
</div>

<script>
let slideIndex = 0;
const slides = document.querySelectorAll('.slides');

function showSlides() {
    slides.forEach(slide => slide.classList.remove('active'));
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1; }
    slides[slideIndex - 1].classList.add('active');
    setTimeout(showSlides, 5000); // change slide every 3 sec
}

showSlides();
</script>
<script>
function toggleMenu(){
    const nav = document.getElementById("navLinks");
    nav.style.display = nav.style.display === "flex" ? "none" : "flex";
}
</script>



<?php include 'includes/footer.php'; ?>