<?php
include 'includes/db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name  = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // 🔒 CHECK DUPLICATE FIRST
    $check = $conn->prepare("SELECT user_id FROM users WHERE phone=? OR email=?");
    $check->bind_param("ss", $phone, $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "<script>alert('Phone or Email already registered');</script>";
        exit;
    }

    // ✅ INSERT ONLY IF NOT EXISTS
    $sql = "INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $phone, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!');
              window.location.href='user/login.php';</script>";
    } else {
        echo "<script>alert('Registration failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="assets/register.css">
</head>

<body>
    <div class="register-container">
        <h2>User Registration</h2>

        <form action="register.php" method="POST" onsubmit="return validateForm()">

            <label>Name</label>
            <input type="text" id="name" name="name">

            <label>Phone</label>
            <input type="text" id="phone" name="phone" onkeyup="checkUser()">
            <span id="phoneMsg"></span>

            <label>Email</label>
            <input type="email" id="email" name="email" onkeyup="checkUser()">
            <span id="emailMsg"></span>

            <label>Password</label>
            <input type="password" id="password" name="password">


            <button type="submit">Register</button>

            <div class="login-link">
                Already have an account? <a href="user/login.php">Login</a>
            </div>
        </form>
    </div>

    <script>
        function validateForm() {
            var name = document.getElementById('name').value;
            let phone = document.getElementById('phone').value;
            let email = document.getElementById('email').value;
            let password = document.getElementById('password').value;

            //mobile number validation
            let phonePattern = /^[0-9]{10}$/;
            if (!phonePattern.test(phone)) {
                alert("Please enter a valid 10-digit phone number.");
                return false;
            }
            //email validation
            let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            //password validation
            let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;
            if (!passwordPattern.test(password)) {
                alert("Password must be 8+ chars with uppercase, lowercase, number & special character");
                return false;
            }

            if (name === "" || phone === "" || email === "" || password === "") {
                alert("All fields must be filled out");
                return false;
            }
            return true;
        }

        function checkUser() {
            let phone = document.getElementById('phone').value;
            let email = document.getElementById('email').value;

            if (phone !== "" || email !== "") {
                let xhr = new XMLHttpRequest();
                xhr.open("POST", "check_user.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                xhr.onload = function() {
                    let response = JSON.parse(this.responseText);
                    document.getElementById("phoneMsg").innerHTML = response.phone ? "❌ Phone already registered" : "✅ Phone available";
                    document.getElementById("emailMsg").innerHTML = response.email ? "❌ Email already registered" : "✅ Email available";
                };

                xhr.send("phone=" + phone + "&email=" + email);
            }
        }
    </script>
</body>

</html>