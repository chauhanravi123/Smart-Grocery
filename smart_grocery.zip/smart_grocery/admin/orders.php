<?php
include 'admin_auth.php';
include '../includes/db.php';

/* Fetch all orders including delivery boy info */
$orders = $conn->query("SELECT o.*, d.delivery_id, d.name AS delivery_name, d.phone AS delivery_phone FROM orders o LEFT JOIN delivery_boys d ON o.delivery_id = d.delivery_id ORDER BY o.order_id DESC");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management</title>
    <link rel="stylesheet" href="assets/css/admin.css">
</head>

<body>
    <div class="table-section">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px;">
        <h2 style="margin:0">All Orders</h2>
        <div>
          <a class="btn" href="orders.php">Refresh</a>
        </div>
      </div>
      <table>   
        <tr>
            <th>Id</th>
            <th>Customer</th>
            <th>Phone</th>
            <th>Total</th>
            <th>Address</th>
          <!--    <th>Delivery</th>
            <th>Order Status</th>-->
            <th>Delivery Status</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $orders->fetch_assoc()) { ?>
            <tr data-order-id="<?= $row['order_id'] ?>">
                <td><?= $row['order_id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td>₹<?= number_format($row['total'],2) ?></td>
                <td><?= htmlspecialchars($row['address']) ?></td>
              <!--  <td><?= !empty($row['delivery_name']) ? htmlspecialchars($row['delivery_name']).' <span class="small muted">('.htmlspecialchars($row['delivery_phone']).')</span>' : '<em class="muted">Unassigned</em>' ?></td>-->

           <!--     <td>
                    <form method="post" action="update_order.php">
                        <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                        <select name="status" onchange="this.form.submit()">
                            <?php
                            $statuses = ['pending', 'processing', 'delivered', 'cancelled'];
                            foreach ($statuses as $status) {
                                $selected = ($row['status'] == $status) ? 'selected' : '';
                            ?>
                                <option value="<?= $status ?>" <?= $selected ?>>
                                    <?= ucfirst($status) ?>
                                </option>
                            <?php } ?>
                        </select>
                    </form>
                </td> -->
                <td class="delivery-status" data-order-id="<?= $row['order_id'] ?>"><?= htmlspecialchars($row['delivery_status'] ?? '') ?></td>
                <td>
                    <?= !empty($row['order_date'])
                        ? date('d M Y', strtotime($row['order_date']))
                        : '-' ?>
                </td>

                <td class="table-actions">
                    <a class="btn btn-outline" href="order_details.php?id=<?= $row['order_id'] ?>">View</a>
                  <!--  <a class="btn btn-edit" href="assign_delivery.php?order_id=<?= $row['order_id'] ?>"><?= !empty($row['delivery_name']) ? 'Reassign' : 'Assign' ?></a>-->
                </td>
            </tr>
        <?php } ?>
    </table>

    <script>
    // Long-poll admin order updates
    (function(){
        let lastId = 0;
        async function poll(){
            try{
                const res = await fetch('../ajax/get_orders_statuses_admin.php?since='+lastId);
                const j = await res.json();
                if(!j.success){ setTimeout(poll,2000); return; }
                if(j.updates && j.updates.length){
                    for(const u of j.updates){
                        const cell = document.querySelector('.delivery-status[data-order-id="'+u.order_id+'"]');
                        if(cell && cell.textContent.trim() !== (u.delivery_status || '').trim()){
                            cell.textContent = u.delivery_status || '';
                            cell.style.transition = 'background-color 0.3s';
                            cell.style.backgroundColor = '#fffbcc';
                            setTimeout(()=> cell.style.backgroundColor = '', 1200);
                        }
                        if(u.id && u.id > lastId) lastId = u.id;
                    }
                }
            }catch(e){ console.error(e); }
            // immediately start next long-poll
            poll();
        }
        poll();
    })();
    </script>
</body>

</html>