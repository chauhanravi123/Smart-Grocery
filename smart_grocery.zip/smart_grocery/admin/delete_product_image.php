<?php
include '../includes/db.php';

if (!isset($_GET['id']) || !isset($_GET['product_id'])) {
    die("Missing parameters!");
}

$image_id = (int)$_GET['id'];
$product_id = (int)$_GET['product_id'];

/* GET IMAGE INFO */
$res = $conn->query("SELECT image FROM product_images WHERE image_id=$image_id AND product_id=$product_id");
if ($res->num_rows == 0) {
    die("Image not found!");
}

$image = $res->fetch_assoc();
$imagePath = "../assets/images/products/" . $image['image'];

/* DELETE FILE */
if (file_exists($imagePath)) {
    unlink($imagePath);
}

/* DELETE FROM DATABASE */
$conn->query("DELETE FROM product_images WHERE image_id=$image_id");

header("Location: update_products.php?id=$product_id");
exit;
