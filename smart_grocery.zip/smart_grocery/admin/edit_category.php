<?php
include '../includes/db.php';
include 'admin_header.php';


if (!isset($_GET['id'])) {
    die("Category Id Missing");
}
$id = (int)$_GET['id'];

// Fetch existing category data

$result = $conn->query("SELECT * FROM categories WHERE category_id=$id");
if ($result->num_rows == 0) {
    die("Category Not Found");
}
$category = $result->fetch_assoc();

//Upadte Category
if (isset($_POST['update_category'])) {
    $name = trim($_POST['category_name']);
    $slug = trim($_POST['slug']);

    // Handle Image Upload
    $uploadDir =   "../assets/images/categories/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $image = $category['image'];
    if (isset($_FILES['category_image']) && $_FILES['category_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'webp', 'png'];
        $ext = strtolower(pathinfo($_FILES['category_image']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) {
            die("Invalid Image Type");
        }
        //delete old image
        $oldImagePath = $uploadDir . $image;

        if (!empty($image) && file_exists($oldImagePath)) {
            @unlink($oldImagePath); // suppress Windows warning
        }

        $image = time() . '_' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['category_image']['tmp_name'], $uploadDir . $image);
    }
    $sql = "UPDATE categories 
        SET category_name='$name', slug='$slug', image='$image' 
        WHERE category_id=$id";

    if ($conn->query($sql)) {
        echo "<p style='color:green'>Category Updated Successfully</p>";
    } else {
        echo "<p style='color:red'>Error: Could not update category</p>";
    }
}
?>

<h2>Edit Category</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="text" name="category_name" value="<?php echo htmlspecialchars($category['category_name']); ?>" required><br><br>
    <input type="text" name="slug" value="<?php echo htmlspecialchars($category['slug']); ?>" required><br><br>
    <input type="file" name="category_image" accept="image/*"><br><br>
    <?php if ($category['image']) { ?>
        <img src="../assets/images/categories/<?php echo $category['image']; ?>" width="100"><br><br>
    <?php } ?>
    <button type="submit" name="update_category">Update Category</button>
</form>
<?php include 'admin_footer.php'; ?>