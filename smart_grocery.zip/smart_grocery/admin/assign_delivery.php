<?php
include '../includes/db.php';

// Support both GET and POST order_id
$order_id = isset($_REQUEST['order_id']) ? (int)$_REQUEST['order_id'] : 0;

// Fetch active delivery boys (prepared statement)
$boys_stmt = $conn->prepare("SELECT delivery_id, name, phone FROM delivery_boys WHERE status=1 ORDER BY name ASC");
$boys_stmt->execute();
$boys_result = $boys_stmt->get_result();

// load delivery boys into PHP array for reuse
$delivery_boys = [];
while($bb = $boys_result->fetch_assoc()) $delivery_boys[] = $bb;

// Helper to detect AJAX requests
function is_ajax(){
    return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $delivery_id = isset($_POST['delivery_id']) ? (int)$_POST['delivery_id'] : 0;

    if($delivery_id <= 0 || $order_id <= 0){
        if(is_ajax()){ 

            http_response_code(400);
            header('Content-Type: application/json');
            echo json_encode(['success'=>false, 'message'=>'Invalid data']);
        }else{
            header('Location: orders.php');
        }
        exit;
    }

    // Update order using prepared statement
    $update = $conn->prepare("UPDATE orders SET delivery_id = ?, delivery_status = 'Assigned' WHERE order_id = ?");
    $update->bind_param('ii', $delivery_id, $order_id);
    $ok = $update->execute();

    if(is_ajax()){
        if($ok){
            // fetch delivery info to return
            $d = $conn->prepare("SELECT name, phone FROM delivery_boys WHERE delivery_id = ? LIMIT 1");
            $d->bind_param('i', $delivery_id);
            $d->execute();
            $res = $d->get_result()->fetch_assoc();
            header('Content-Type: application/json');
            echo json_encode(['success'=>true, 'message'=>'Assigned successfully', 'delivery'=>$res]);
        }else{
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['success'=>false, 'message'=>'Failed to assign']);
        }
        exit;
    }else{
        // non-AJAX fallback
        header('Location: orders.php');
        exit;
    }
}
?>

<?php
// If called without order_id, render the full assignments table with optional date filter
if(!$order_id){
    $filter_date = isset($_GET['date']) ? trim($_GET['date']) : '';

    // Validate date (YYYY-MM-DD)
    if($filter_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $filter_date)){
        $filter_date = '';
    }

    // delivery boys already loaded into $delivery_boys above

    // prepare orders query (filtered by date if provided)
    $base_sql = "SELECT o.order_id, o.name, o.phone, o.total, o.address, o.status, o.order_date, o.delivery_id, d.name AS delivery_name, d.phone AS delivery_phone FROM orders o LEFT JOIN delivery_boys d ON o.delivery_id = d.delivery_id";
    if($filter_date){
        $stmt = $conn->prepare($base_sql . " WHERE DATE(o.order_date) = ? ORDER BY o.order_id DESC");
        $stmt->bind_param('s', $filter_date);
    }else{
        $stmt = $conn->prepare($base_sql . " ORDER BY o.order_id DESC");
    }
    $stmt->execute();
    $orders = $stmt->get_result();
    ?>

    <h3>Assign Delivery Boys</h3>
    <form method="get" class="filter-form" style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
        <label>Date: <input type="date" name="date" value="<?= htmlspecialchars($filter_date) ?>"></label>
        <button class="btn" type="submit">Filter</button>
        <a class="btn btn-outline" href="assign_delivery.php">Clear</a>
    </form>

    <div class="table-section">
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Total</th>
                    <th>Address</th>
                    <th>Delivery</th>
                    <th>Order Status</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $orders->fetch_assoc()){ ?>
                    <tr>
                        <td><?= $row['order_id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td>₹<?= number_format($row['total'],2) ?></td>
                        <td><?= htmlspecialchars($row['address']) ?></td>
                        <td class="delivery-cell"><?= !empty($row['delivery_name']) ? htmlspecialchars($row['delivery_name']).' <span class="small muted">('.htmlspecialchars($row['delivery_phone']).')</span>' : '<em class="muted">Unassigned</em>' ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= !empty($row['order_date']) ? date('d M Y', strtotime($row['order_date'])) : '-' ?></td>
                        <td>
                            <form class="assign-row-form" method="post" action="assign_delivery.php?order_id=<?= $row['order_id'] ?>">
                                <input type="hidden" name="order_id" value="<?= $row['order_id'] ?>">
                                <select name="delivery_id" required style="margin-bottom:6px">
                                    <option value="0">-- Select Delivery Boy --</option>
                                    <?php foreach($delivery_boys as $b){ $sel = ($row['delivery_id'] == $b['delivery_id']) ? 'selected' : ''; ?>
                                        <option value="<?= $b['delivery_id'] ?>" <?= $sel ?>><?= htmlspecialchars($b['name']) ?> (<?= htmlspecialchars($b['phone']) ?>)</option>
                                    <?php } ?>
                                </select>
                                <div style="display:flex;gap:6px">
                                    <button type="submit" class="btn btn-edit"><?= !empty($row['delivery_name']) ? 'Reassign' : 'Assign' ?></button>
                                    <a class="btn btn-outline" href="order_details.php?id=<?= $row['order_id'] ?>">View</a>
                                </div>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <?php
    exit;
}

// If order_id is present, render modal fragment (used by the modal loader)
?>
<div class="assign-modal">
    <h3>Assign Delivery Boy</h3>
    <form method="post" id="assignForm" action="assign_delivery.php?order_id=<?= $order_id ?>">
        <input type="hidden" name="order_id" value="<?= $order_id ?>">
        <label>Select Delivery Boy</label>
        <select name="delivery_id" required>
            <?php foreach($delivery_boys as $b){ ?>
                <option value="<?= $b['delivery_id']; ?>"><?= htmlspecialchars($b['name']) ?> (<?= htmlspecialchars($b['phone']) ?>)</option>
            <?php } ?>
        </select>

        <div style="margin-top:12px;display:flex;gap:8px">
            <button type="submit" name="assign" class="btn">Assign</button>
            <button type="button" class="btn btn-outline" onclick="document.getElementById('adminModal').classList.remove('open')">Cancel</button>
        </div>
    </form>
</div>
