<?php
include '../includes/db.php';

/* CHECK ID */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Product ID missing!");
}
$id = (int) $_GET['id'];

/* FETCH PRODUCT */
$res = $conn->query("SELECT * FROM products WHERE product_id=$id");
if ($res->num_rows == 0) {
    die("Product not found!");
}
$product = $res->fetch_assoc();

/* FETCH PRODUCT IMAGES */
$imagesRes = $conn->query("SELECT * FROM product_images WHERE product_id=$id ORDER BY image_id ASC");
$images = $imagesRes->fetch_all(MYSQLI_ASSOC);

/* FETCH CATEGORIES */
$cats = $conn->query("SELECT * FROM categories WHERE status=1");

/* UPDATE PRODUCT */
if(isset($_POST['update_product'])){

    $name  = $_POST['product_name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $cat   = $_POST['category_id'];
    $desc  = $_POST['description'];

    /* UPDATE PRODUCT INFO */
    $stmt = $conn->prepare("UPDATE products SET product_name=?, price=?, stock=?, category_id=?, description=? WHERE product_id=?");
    $stmt->bind_param("sddssi", $name, $price, $stock, $cat, $desc, $id);
    $stmt->execute();

    /* HANDLE NEW IMAGES */
    $uploadDir = "../assets/images/products/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (!empty($_FILES['product_images']['name'][0])) {
        foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp) {
            if (empty($_FILES['product_images']['name'][$key])) continue;

            $ext = strtolower(pathinfo($_FILES['product_images']['name'][$key], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $img = time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($tmp, $uploadDir . $img);

                /* INSERT INTO product_images TABLE */
                $stmt2 = $conn->prepare("INSERT INTO product_images (product_id, image) VALUES (?, ?)");
                $stmt2->bind_param("is", $id, $img);
                $stmt2->execute();
            }
        }
    }

    header("Location: manage_products.php?updated=1");
    exit;
}
?>
<link rel="stylesheet" href="assets/css/admin.css">
<div class="product-container">
  <h2>Edit Product</h2>
  <form method="POST" enctype="multipart/form-data">

    <label for="product_name">Product Name</label>
    <input type="text" id="product_name" name="product_name" class="" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>

    <label for="price">Price (₹)</label>
    <input type="number" id="price" name="price" step="0.01" value="<?php echo $product['price']; ?>" required>

    <label for="stock">Stock</label>
    <input type="number" id="stock" name="stock" value="<?php echo $product['stock']; ?>" required>

    <label for="category_id">Category</label>
    <select id="category_id" name="category_id">
        <?php while($c = $cats->fetch_assoc()){ ?>
            <option value="<?php echo $c['category_id']; ?>" <?php if($c['category_id']==$product['category_id']) echo 'selected'; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
        <?php } ?>
    </select>

    <label for="description">Description</label>
    <textarea id="description" name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>

    <label>Current Images</label>
    <?php if(!empty($images)){ ?>
      <div style="margin-bottom:10px; display:flex; gap:10px; flex-wrap:wrap;">
        <?php foreach($images as $img){ ?>
          <div style="position:relative;">
            <img class="thumb" src="../assets/images/products/<?php echo htmlspecialchars($img['image']); ?>" alt="Product Image" style="width:100px; height:100px; object-fit:cover;">
            <a href="delete_product_image.php?id=<?php echo $img['image_id']; ?>&product_id=<?php echo $id; ?>" style="position:absolute; top:0; right:0; background:red; color:white; padding:2px 6px; cursor:pointer; border-radius:3px;" onclick="return confirm('Delete this image?');">×</a>
          </div>
        <?php } ?>
      </div>
    <?php } else { ?>
      <div class="muted small" style="margin-bottom:10px;">No images</div>
    <?php } ?>

    <label for="product_images">Add New Images (optional)</label>
    <input type="file" id="product_images" name="product_images[]" multiple accept="image/*">

    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
      <button type="submit" name="update_product" class="btn">Update Product</button>
      <a href="manage_products.php" class="btn btn-outline">Back to Products</a>
    </div>

  </form>
</div>

<script>
// When loaded via AJAX, ensure links inside mainContent load via AJAX too (delegation handled globally); just initialize any small behaviors.
</script>