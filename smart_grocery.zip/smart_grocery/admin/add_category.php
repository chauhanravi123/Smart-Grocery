<?php
include 'admin_header.php';
include '../includes/db.php';

if(isset($_POST['add_category'])) {
    $name = $_POST['category_name'];
    $slug= strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/','-', $name)));

    // Handle image upload
    $uploadDir = "../assets/images/categories/";

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$image = '';
if (!empty($_FILES['category_image']['name'])) {
    $image_name = time() . '_' . basename($_FILES['category_image']['name']);
    $target = $uploadDir . $image_name;

    if (move_uploaded_file($_FILES['category_image']['tmp_name'], $target)) {
        $image = $image_name;
    } else {
        die("Image upload failed!");
    }
}


    // Insert into database
    $sql = "INSERT INTO categories (category_name, slug, image,status) VALUES ('$name', '$slug', '$image',1)";
    if($conn->query($sql)){
        echo "<p class='success-msg'>Category added successfully!</p>";
    } else {
        echo "<p class='error-msg'>Error: Category already exists</p>";
}
?>
<?php } ?>
<link rel="stylesheet" href="assets/css/admin.css">
<div class="category-container"><link rel="stylesheet" href="assets/css/admin.css">
<div class="category-container">

<h2>Add New Category</h2>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="category_name" placeholder="Category Name" required>

    <input type="file" name="category_image" accept="image/*">

    <button type="submit" name="add_category">Add Category</button>
</form>

</div>

<?php include 'admin_footer.php'; ?>