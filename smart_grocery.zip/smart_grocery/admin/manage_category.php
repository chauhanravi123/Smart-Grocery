<?php
include '../includes/db.php';
include 'admin_header.php';

if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    // Delete image from server
    $img_res= $conn->query("SELECT image FROM categories WHERE category_id=$id");
    $img_row= $img_res->fetch_assoc();
    if($img_row['image'] && file_exists('../assets/images/categories/'.$img_row['image'])){
        unlink('../assets/images/categories/'.$img_row['image']);
    }

    // Delete category from database
    $conn->query("DELETE FROM categories WHERE category_id=$id");
}
$result= $conn->query("SELECT * FROM categories ORDER BY category_id DESC");
?>
<link rel="stylesheet" href="assets/css/admin.css">
<div class="table-section table-categories">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:12px;flex-wrap:wrap;">
    <h2 style="margin:0">Manage Categories</h2>
    <a class="btn" href="add_category.php">Add Category</a>
  </div>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Slug</th>
        <th>Image</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
   <?php while($row= $result->fetch_assoc()){ ?>
    <tr>
        <td><?php echo $row['category_id']; ?></td>
        <td><?php echo htmlspecialchars($row['category_name']);?></td>
        <td><?php echo htmlspecialchars($row['slug']);?></td>
        <td><?php if(!empty($row['image'])){?>
        <img class="thumb" src="../assets/images/categories/<?php echo $row['image']; ?>" alt="<?php echo htmlspecialchars($row['category_name']); ?>">
        <?php } ?>
        </td>
        <td class="table-actions">
            <a class="btn btn-edit" href="edit_category.php?id=<?php echo $row['category_id']; ?>">Edit</a>
            <a class="btn btn-delete" href="manage_category.php?delete=<?php echo $row['category_id']; ?>" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
        </td>

    </tr>
<?php } ?>
    </tbody>
  </table>
</div>
<?php include 'admin_footer.php'; ?>