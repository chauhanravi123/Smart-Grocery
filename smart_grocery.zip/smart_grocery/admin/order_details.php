<?php
session_start();
include '../includes/db.php';

$user_id = $_SESSION['user_id'];

$order_id = isset($_GET['oid']) ? (int)$_GET['oid'] : 0;

$order = $conn->query("SELECT * FROM orders WHERE order_id=$order_id")->fetch_assoc();

// Get address from user_addresses table
$address_id = $order['address_id'] ?? 0;

$address = null;
if ($address_id > 0) {
    $stmt = $conn->prepare("
        SELECT name, phone, address, city, pincode
        FROM user_addresses
        WHERE address_id = ?
    ");
    $stmt->bind_param("i", $address_id);
    $stmt->execute();
    $address = $stmt->get_result()->fetch_assoc();
}

if (!$order) {
    die("Order not found.");
}

$items = $conn->query("
    SELECT 
        oi.quantity,
        oi.price,
        p.product_name,
        GROUP_CONCAT(pi.image SEPARATOR ',') AS images
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id
    WHERE oi.order_id=$order_id
    GROUP BY oi.order_id, oi.product_id, oi.quantity, oi.price, p.product_name
");
?>
<?php include '../includes/header.php'; ?>
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/footer.css">
<h2>Order #<?= $order_id ?></h2>

<p>
<b>Name:</b> <?= $order['name'] ?><br>
<b>Phone:</b> <?= $order['phone'] ?><br>
<!-- <b>Address:</b> <?= $order['address'] ?><br> -->
<b>Status:</b> <?= !empty($order['status']) ? ucfirst($order['status']) : 'Pending' ?>
</p>


<table border="1" cellpadding="8" width="100%">
<tr>
    <th>Product</th>
    <th>Image</th>
    <th>Qty</th>
    <th>Price</th>
</tr>

<?php while($row = $items->fetch_assoc()){ 
    // Get first image from product_images
    $firstImage = 'no-image.png';
    if (!empty($row['images'])) {
        $images = explode(',', $row['images']);
        $firstImage = $images[0];
    }
?>
<tr>
    <td><?= $row['product_name'] ?></td>
    <td>
        <img src="../assets/images/products/<?= htmlspecialchars($firstImage) ?>" width="50" alt="Product" onerror="this.src='../assets/images/no-image.png'">
    </td>
    <td><?= $row['quantity'] ?></td>
    <td>₹<?= $row['price'] * $row['quantity'] ?></td>
</tr>
<?php } ?>
</table>

<?php include '../includes/footer.php';?>