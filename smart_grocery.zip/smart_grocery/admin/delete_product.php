<?php
include '../includes/db.php';

if(!isset($_GET['id'])){
    die("Product ID missing");
}

$id = (int)$_GET['id'];

/* Delete image first */
$res = $conn->query("SELECT image FROM products WHERE product_id=$id");
$p = $res->fetch_assoc();

if($p && file_exists("../uploads/".$p['image'])){
    unlink("../uploads/".$p['image']);
}

/* Delete product */
$conn->query("DELETE FROM products WHERE product_id=$id");

header("Location: products.php?deleted=1");
?>