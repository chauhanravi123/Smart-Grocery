<?php
include '../includes/db.php';

$products = $conn->query("
    SELECT p.*, c.category_name, GROUP_CONCAT(pi.image SEPARATOR ',') AS images
    FROM products p
    JOIN categories c ON c.category_id = p.category_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id
    GROUP BY p.product_id
    ORDER BY p.product_id DESC
");
?>
<table border="1" width="100%" cellpadding="8">
<thead>
<tr>
    <th>#</th>
    <th>Image</th>
    <th>Name</th>
    <th>Category</th>
    <th>Price (₹)</th>
    <th>Stock</th>
    <th>Status</th>
    <th>Action</th>
</tr>
</thead>

<tbody>
<?php $i=1; while($row = $products->fetch_assoc()){ 
    $firstImage = '';
    if (!empty($row['images'])) {
        $images = explode(',', $row['images']);
        $firstImage = $images[0];
    }
?>
<tr>
    <td><?= $i++; ?></td>

    <td>
        <img src="../assets/images/products/<?= htmlspecialchars($firstImage ?: 'no-image.png'); ?>" width="50" alt="Product Image" onerror="this.src='../assets/images/no-image.png'">
    </td>

    <td><?= $row['product_name']; ?></td>

    <td><?= $row['category_name']; ?></td>

    <td>₹<?= $row['price']; ?></td>

    <td><?= $row['stock']; ?></td>

    <td>
        <?= $row['status'] ? 'Active' : 'Inactive'; ?>
    </td>

    <td>
        <a href="update_products.php?id=<?= $row['product_id']; ?>" 
           class="btn btn-warning btn-sm">Edit</a>

        <a href="delete_product.php?id=<?= $row['product_id']; ?>" 
           onclick="return confirm('Are you sure want to Delete?')"
           class="btn btn-danger btn-sm">Delete</a>
    </td>
</tr>
<?php } ?>
</tbody>
</table>
