<?php
include 'auth.php';
include '../includes/db.php';
include 'includes/nav.php';

$did = (int)$_SESSION['delivery_id'];

$col = $conn->query("SELECT SUM(collected_amount) AS sum_collected FROM orders WHERE delivery_id = $did")->fetch_assoc();

$orders = $conn->query("
    SELECT order_id, total, delivery_status, COALESCE(collected_amount,0) AS collected_amount, collected_at, payment_method
    FROM orders
    WHERE delivery_id=$did
    ORDER BY order_id DESC
");

?>

<h2>📦 My Orders</h2>
<p>💰 Total Collected: <b>₹<?= number_format($col['sum_collected'] ?? 0,2) ?></b></p>

<?php while($o = $orders->fetch_assoc()){ ?>
<div style="border:1px solid #ddd; padding:12px; margin-bottom:10px;">
    <b>Order #<?= $o['order_id']; ?></b><br>
    Amount: ₹<?= $o['total']; ?><br>
    Status: <b><?= $o['delivery_status']; ?></b><br>
    Collected: <?= $o['collected_amount'] > 0 ? '₹'.number_format($o['collected_amount'],2). ' on '. ($o['collected_at'] ? date('d M Y H:i', strtotime($o['collected_at'])) : '') : '<em>No</em>' ?><br>

    <a href="order_view.php?id=<?= $o['order_id']; ?>">
        View Details →
    </a>
</div>
<?php } ?>
