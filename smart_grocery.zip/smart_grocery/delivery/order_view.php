<?php
include 'auth.php';
include '../includes/db.php';
include 'includes/nav.php';

$order_id = (int)$_GET['id'];

/* Fetch order + customer (SAFE) */
$order = $conn->query("
    SELECT 
        o.order_id,
        o.delivery_status,
        o.user_id,
        o.total,
        COALESCE(o.collected_amount,0) AS collected_amount,
        o.collected_at,
        o.payment_method,
        u.name AS customer_name,
        u.phone,
        u.address
    FROM orders o
    LEFT JOIN users u ON u.user_id = o.user_id
    WHERE o.order_id = $order_id
")->fetch_assoc();

/* If order not found */
if (!$order) {
    echo "<h3>Order not found</h3>";
    exit;
}

/* Fetch items */
$items = $conn->query("
    SELECT p.product_name, oi.quantity, oi.price
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    WHERE oi.order_id = $order_id
");

/* Calculate total */
$total = 0;
?>

<h3>Order #<?= $order_id; ?></h3>

<p>
<b><?= $order['customer_name'] ?? 'Guest Customer'; ?></b><br>
📞 <?= $order['phone'] ?? 'N/A'; ?><br>
📍 <?= $order['address'] ?? 'Address not available'; ?>
</p>

<h4>Items</h4>
<?php while($i = $items->fetch_assoc()){ 
    $total += $i['quantity'] * $i['price'];
?>
- <?= $i['product_name']; ?> × <?= $i['quantity']; ?><br>
<?php } ?>

<p><b>Total:</b> ₹<?= $total; ?></p>

<p><b>Collected:</b> <?= $order['collected_amount'] > 0 ? '₹'.number_format($order['collected_amount'],2).' on '.date('d M Y H:i', strtotime($order['collected_at'])) : '<em>Not collected</em>' ?></p>

<p><b>Payment Method:</b> <?= !empty($order['payment_method']) ? htmlspecialchars($order['payment_method']) : '<em>Not set</em>' ?></p>

<a href="update_status.php?id=<?= $order_id; ?>">
    Update Delivery Status →
</a>
