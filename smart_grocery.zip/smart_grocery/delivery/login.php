<?php
session_start();
include '../includes/db.php';

$error = "";

if (isset($_POST['login'])) {

    $email = trim($_POST['email']);
    $password = $_POST['password']; // ✅ plain password

    // 1️⃣ Fetch by email only
    $stmt = $conn->prepare(
        "SELECT * FROM delivery_boys WHERE email=? AND status=1"
    );
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {

        $boy = $result->fetch_assoc();

        // 2️⃣ Verify password
        $stored = $boy['password'];
        if (password_verify($password, $stored)) {

            $_SESSION['delivery_id']   = $boy['delivery_id'];
            $_SESSION['delivery_name'] = $boy['name'];

            header("Location: dashboard.php");
            exit;

        } else {
            // Fallback checks for legacy password storage
            // 1) Plaintext stored (not recommended)
            if ($stored === $password) {
                // upgrade to password_hash
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upd = $conn->prepare("UPDATE delivery_boys SET password=? WHERE delivery_id=?");
                $upd->bind_param("si", $newHash, $boy['delivery_id']);
                $upd->execute();

                $_SESSION['delivery_id']   = $boy['delivery_id'];
                $_SESSION['delivery_name'] = $boy['name'];
                header("Location: dashboard.php");
                exit;
            }

            // 2) MD5 legacy
            if (md5($password) === $stored) {
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upd = $conn->prepare("UPDATE delivery_boys SET password=? WHERE delivery_id=?");
                $upd->bind_param("si", $newHash, $boy['delivery_id']);
                $upd->execute();

                $_SESSION['delivery_id']   = $boy['delivery_id'];
                $_SESSION['delivery_name'] = $boy['name'];
                header("Location: dashboard.php");
                exit;
            }

            $error = "Invalid Password!";
        }

    } else {
        $error = "Delivery Boy Not Found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delivery Boy Login</title>
    <link rel="stylesheet" href="assets/css/delivery.css">
    <style>
        .login-box{
            width:360px;
            margin:80px auto;
            background:#fff;
            padding:25px;
            box-shadow:0 0 10px rgba(0,0,0,0.1);
            border-radius:6px;
        }
        h2{
            text-align:center;
            margin-bottom:20px;
        }
        input{
            width:100%;
            padding:10px;
            margin:10px 0;
            border:1px solid #ccc;
            border-radius:4px;
        }
        button{
            width:100%;
            padding:10px;
            background:#28a745;
            border:none;
            color:#fff;
            font-size:16px;
            cursor:pointer;
            border-radius:4px;
        }
        button:hover{
            background:#218838;
        }
        .error{
            color:red;
            text-align:center;
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>🚴 Delivery Boy Login</h2>

    <?php if($error){ ?>
        <p class="error"><?= $error; ?></p>
    <?php } ?>

    <form method="post">
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="password" name="password" placeholder="Password" required>
        <button name="login">Login</button>
    </form>
</div>

</body>
</html>
