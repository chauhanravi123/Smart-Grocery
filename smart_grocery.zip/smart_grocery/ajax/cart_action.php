<?php
session_start();
header('Content-Type: application/json');

include __DIR__ . '/../includes/db.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $pid = (int)($_POST['product_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($pid <= 0) {
        echo json_encode(['success'=>false,'message'=>'Invalid product']); exit;
    }

    if ($action === 'plus') {
        $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + 1;
    } elseif ($action === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    } elseif ($action === 'set') {
        $qty = max(0, (int)$_POST['qty']);
        if ($qty <= 0) {
            unset($_SESSION['cart'][$pid]);
        } else {
            $_SESSION['cart'][$pid] = $qty;
        }
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][$pid]);
    } else {
        echo json_encode(['success'=>false,'message'=>'Unknown action']); exit;
    }

    // compute item subtotal and cart subtotal
    $cartCount = array_sum($_SESSION['cart'] ?? []);
    $item_qty = $_SESSION['cart'][$pid] ?? 0;
    $item_sub = 0;
    $subtotal = 0;

    if (!empty($_SESSION['cart'])) {
        $ids = implode(',', array_keys($_SESSION['cart']));
        $res = $conn->query("SELECT product_id, price FROM products WHERE product_id IN ($ids)");
        while ($r = $res->fetch_assoc()) {
            $qty = $_SESSION['cart'][$r['product_id']];
            $line = $r['price'] * $qty;
            $subtotal += $line;
            if ($r['product_id']==$pid) $item_sub = $r['price'] * $item_qty;
        }
    }

    echo json_encode([
        'success'=>true,
        'item_qty'=>$item_qty,
        'item_sub'=>$item_sub,
        'subtotal'=>$subtotal,
        'cartCount'=>$cartCount
    ]);
}
