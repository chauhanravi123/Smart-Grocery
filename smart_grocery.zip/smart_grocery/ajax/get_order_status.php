<?php
header('Content-Type: application/json');
include '../includes/db.php';
session_start();

// If admin wants all orders, require admin session
if (isset($_GET['admin']) && isset($_SESSION['admin_id'])) {
    $rows = [];
    $res = $conn->query("SELECT order_id, delivery_status, payment_method, COALESCE(collected_amount,0) AS collected_amount FROM orders ORDER BY order_id DESC");
    while($r = $res->fetch_assoc()) $rows[] = $r;
    echo json_encode(['success'=>true,'orders'=>$rows]);
    exit;
}

// For logged-in user: return single order OR all user's orders when all=1
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success'=>false,'error'=>'Not authenticated']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];

$since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
if (isset($_GET['all']) && $_GET['all']) {
    if ($since > 0) {
        // long-poll up to 20s for updates for this user
        $start = time();
        while (time() - $start < 20) {
            $stmt = $conn->prepare("SELECT u.id, u.order_id, u.delivery_status, u.payment_method, u.collected_amount, u.created_at FROM order_updates u JOIN orders o ON o.order_id = u.order_id WHERE o.user_id = ? AND u.id > ? ORDER BY u.id ASC");
            $stmt->bind_param('ii', $user_id, $since);
            $stmt->execute();
            $res = $stmt->get_result();
            $rows = $res->fetch_all(MYSQLI_ASSOC);
            if (count($rows) > 0) {
                echo json_encode(['success'=>true,'updates'=>$rows]);
                exit;
            }
            sleep(1);
        }
        echo json_encode(['success'=>true,'updates'=>[]]);
        exit;
    }

    $stmt = $conn->prepare("SELECT order_id, delivery_status, payment_method, COALESCE(collected_amount,0) AS collected_amount FROM orders WHERE user_id = ? ORDER BY order_id DESC");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $rows = [];
    while($r = $res->fetch_assoc()) $rows[] = $r;
    echo json_encode(['success'=>true,'orders'=>$rows]);
    exit;
}

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) {
    echo json_encode(['success'=>false,'error'=>'Missing order_id']);
    exit;
}

// support since param for single-order long-poll
if ($since > 0) {
    $start = time();
    while (time() - $start < 20) {
        $stmt = $conn->prepare("SELECT id, order_id, delivery_status, payment_method, collected_amount, created_at FROM order_updates WHERE order_id = ? AND id > ? ORDER BY id ASC");
        $stmt->bind_param('ii', $order_id, $since);
        $stmt->execute();
        $res = $stmt->get_result();
        $rows = $res->fetch_all(MYSQLI_ASSOC);
        if (count($rows) > 0) {
            echo json_encode(['success'=>true,'updates'=>$rows]);
            exit;
        }
        sleep(1);
    }
    echo json_encode(['success'=>true,'updates'=>[]]);
    exit;
}

$stmt = $conn->prepare("SELECT order_id, delivery_status, payment_method, COALESCE(collected_amount,0) AS collected_amount FROM orders WHERE order_id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param('ii', $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
if (!$order) {
    echo json_encode(['success'=>false,'error'=>'Order not found']);
    exit;
}

echo json_encode(['success'=>true,'order'=>$order]);
