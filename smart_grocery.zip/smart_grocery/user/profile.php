<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

/* ADD ADDRESS */
if (isset($_POST['add_address'])) {

    $addr_name    = trim($_POST['addr_name']);
    $addr_phone   = trim($_POST['addr_phone']);
    $addr_address = trim($_POST['addr_address']);
    $addr_city    = trim($_POST['addr_city']);
    $addr_pincode = trim($_POST['addr_pincode']);

    $stmt = $conn->prepare("
        INSERT INTO user_addresses 
        (user_id, name, phone, address, city, pincode)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "isssss",
        $user_id,
        $addr_name,
        $addr_phone,
        $addr_address,
        $addr_city,
        $addr_pincode
    );
    $stmt->execute();

    header("Location: profile.php?addr=added");
    exit;
}


// Handle delete address
if (isset($_POST['delete_address'])) {
    $aid = (int)$_POST['address_id'];
    $stmtDel = $conn->prepare("DELETE FROM user_addresses WHERE address_id = ? AND user_id = ?");
    $stmtDel->bind_param("ii", $aid, $user_id);
    $stmtDel->execute();
    header("Location: profile.php?addr=deleted");
    exit;
}

// Handle update address
if (isset($_POST['update_address'])) {
    $addr_id = (int)$_POST['address_id'];
    $addr_name = trim($_POST['addr_name']);
    $addr_phone = trim($_POST['addr_phone']);
    $addr_address = trim($_POST['addr_address']);
    $addr_city = trim($_POST['addr_city']);
    $addr_pincode = trim($_POST['addr_pincode']);

    $stmtUp = $conn->prepare("UPDATE user_addresses SET name=?, phone=?, address=?, city=?, pincode=? WHERE address_id=? AND user_id=?");
    $stmtUp->bind_param("sssssii", $addr_name, $addr_phone, $addr_address, $addr_city, $addr_pincode, $addr_id, $user_id);
    $stmtUp->execute();

    header("Location: profile.php?addr=updated");
    exit;
}

// Fetch addresses
$addresses = $conn->query("
    SELECT address_id, name, phone, address, city, pincode, is_default
    FROM user_addresses
    WHERE user_id = $user_id
    ORDER BY is_default DESC, address_id DESC
");

// Load address for editing if requested
$editAddress = null;
if (isset($_GET['edit_addr'])) {
    $editId = (int)$_GET['edit_addr'];
    $stmtE = $conn->prepare("SELECT address_id, name, phone, address, city, pincode FROM user_addresses WHERE address_id = ? AND user_id = ?");
    $stmtE->bind_param("ii", $editId, $user_id);
    $stmtE->execute();
    $editAddress = $stmtE->get_result()->fetch_assoc();
    if (!$editAddress) {
        header("Location: profile.php");
        exit;
    }
}

/* Fetch user details */
$stmt = $conn->prepare("SELECT name, email, phone, address, city, pincode FROM users WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

/* Update profile */
if (isset($_POST['update_profile'])) {

    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $pincode = trim($_POST['pincode']);

    $update = $conn->prepare("
        UPDATE users SET 
        name=?, phone=?, address=?, city=?, pincode=?
        WHERE user_id=?
    ");
    $update->bind_param("sssssi", $name, $phone, $address, $city, $pincode, $user_id);
    $update->execute();

    header("Location: profile.php?success=1");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>My Profile | Smart Grocery</title>
    <link rel="stylesheet" href="../assets/css/profile.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
</head>

<body>

    <?php include '../includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row">

            <!-- Profile Card -->
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body text-center">
                        <h4 class="mt-3"><?php echo htmlspecialchars($user['name']); ?></h4>
                        <p class="text-muted"><?php echo $user['email']; ?></p>
                        <a href="my_orders.php" class="btn btn-outline-success btn-sm">My Orders</a>
                    </div>
                </div>
            </div>
            <?php if (isset($_GET['addr'])) {
                if ($_GET['addr'] === 'added') { echo '<div class="alert alert-success">Address added.</div>'; }
                if ($_GET['addr'] === 'deleted') { echo '<div class="alert alert-warning">Address deleted.</div>'; }
                if ($_GET['addr'] === 'updated') { echo '<div class="alert alert-success">Address updated.</div>'; }
            } ?>
            <hr>
            <?php if (!empty($editAddress)) { ?>
                <h4>Edit Address</h4>

                <form method="post">
                    <input type="hidden" name="address_id" value="<?= (int)($editAddress['address_id'] ?? 0) ?>">
                    <input type="text" name="addr_name" class="form-control mb-2" placeholder="Full Name" required value="<?= htmlspecialchars($editAddress['name'] ?? '') ?>">
                    <input type="text" name="addr_phone" class="form-control mb-2" placeholder="Phone" required value="<?= htmlspecialchars($editAddress['phone'] ?? '') ?>">
                    <textarea name="addr_address" class="form-control mb-2" placeholder="Address" required><?= htmlspecialchars($editAddress['address'] ?? '') ?></textarea>
                    <input type="text" name="addr_city" class="form-control mb-2" placeholder="City" required value="<?= htmlspecialchars($editAddress['city'] ?? '') ?>">
                    <input type="text" name="addr_pincode" class="form-control mb-2" placeholder="Pincode" required value="<?= htmlspecialchars($editAddress['pincode'] ?? '') ?>">

                    <button class="btn btn-primary" name="update_address">Update Address</button>
                    <a href="profile.php" class="btn btn-secondary">Cancel</a>
                </form>
            <?php } else { ?>
                <h4>Add New Address</h4>

                <form method="post">
                    <input type="text" name="addr_name" class="form-control mb-2" placeholder="Full Name" required>
                    <input type="text" name="addr_phone" class="form-control mb-2" placeholder="Phone" required>
                    <textarea name="addr_address" class="form-control mb-2" placeholder="Address" required></textarea>
                    <input type="text" name="addr_city" class="form-control mb-2" placeholder="City" required>
                    <input type="text" name="addr_pincode" class="form-control mb-2" placeholder="Pincode" required>

                    <button class="btn btn-primary" name="add_address">Save Address</button>
                </form>
            <?php } ?>

            <!-- Profile Form -->
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-success text-white">
                        My Profile
                    </div>

                    <div class="card-body">

                        <?php if (isset($_GET['success'])) { ?>
                            <div class="alert alert-success">Profile updated successfully</div>
                        <?php } ?>

                        <form method="post">

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>Full Name</label>
                                    <input type="text" name="name"
                                        value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>"
                                        class="form-control" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Phone</label>
                                    <input type="text" name="phone"
                                        value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                        class="form-control">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label>Email (Read Only)</label>
                                <input type="email" value="<?php echo $user['email']; ?>" class="form-control" readonly>
                            </div>

                            <div class="mb-3">
                                <label>Address</label>

                                <textarea name="address" class="form-control"><?php
                                                                                echo htmlspecialchars($user['address'] ?? ''); ?>
                                </textarea>

                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label>City</label>

                                    <input type="text" name="city"
                                        value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>"
                                        class="form-control">
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label>Pincode</label>
                                    <input type="text" name="pincode"
                                        value="<?php echo htmlspecialchars($user['pincode'] ?? ''); ?>"
                                        class="form-control">
                                </div>
                            </div>

                            <button type="submit" name="update_profile" class="btn btn-success">
                                Update Profile
                            </button>

                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <hr>
    <h4>Saved Addresses</h4>

    <?php if ($addresses->num_rows > 0) { ?>
        <?php while ($a = $addresses->fetch_assoc()) { ?>
            <div class="border p-2 mb-2 addr-row">
                <div class="addr-details">
                    <strong><?= htmlspecialchars($a['name'] ?? '') ?></strong><br>
                    <?= htmlspecialchars($a['address'] ?? '') ?>,
                    <?= htmlspecialchars($a['city'] ?? '') ?> - <?= htmlspecialchars($a['pincode'] ?? '') ?><br>
                    Phone: <?= htmlspecialchars($a['phone'] ?? '') ?>
                </div>
                <div class="addr-actions">
                    <a class="btn btn-sm btn-edit" href="profile.php?edit_addr=<?= $a['address_id'] ?>">Edit</a>
                    <form method="post" style="display:inline" onsubmit="return confirm('Delete this address?');">
                        <input type="hidden" name="address_id" value="<?= $a['address_id'] ?>">
                        <button type="submit" name="delete_address" class="btn btn-sm btn-delete">Delete</button>
                    </form>
                </div>
            </div>
        <?php } ?>
    <?php } else { ?>
        <p>No address added yet.</p>
    <?php } ?>

    <?php include '../includes/footer.php'; ?>
</body>

</html>