<?php
$cartCount = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
?>
<?php
include '../includes/db.php';
include 'user_auth.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = (int)$_SESSION['user_id'];

$orders = $conn->query(
    "SELECT * FROM orders 
     WHERE user_id = $user_id 
     ORDER BY order_id DESC"
);

?>

<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/footer.css">
<h2 style="text-align:center;">My Orders</h2>
    <header class="navbar">
        <div class="nav-container">
            <div class="logo">
                <a href="../index.php">🛒 Smart Grocery</a>
            </div>
            <nav class="nav-links" id="NavLinks">
                <a href="../index.php">Home</a>
                <a href="../products.php">Products</a>
                <a href="my_orders.php">My Orders</a>
                <a href="../contact.php">Contact</a>
                
            </nav>
             <div class="nav-icons">
            <a href="../cart.php">
                🛒 <span class="cart-count"><?= $cartCount ?></span>
            </a>
            <span class="menu-toggle" onclick="toggleMenu()">☰</span>
        </div>
        </div>
</header>
<table width="100%" border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>Order ID</th>
        <th>Total Amount</th>
        <th>Status</th>
        <th>Delivery Status</th>
        <th>Date</th>
        <th>Action</th>
    </tr>

<?php
if ($orders->num_rows > 0) {
    while ($row = $orders->fetch_assoc()) {
?>
    <tr data-order-id="<?= $row['order_id']; ?>" align="center">
        <td><?= $row['order_id']; ?></td>
        <td>₹<?= $row['total']; ?></td>
        <td><?= $row['status']; ?></td>
        <td class="delivery-status" data-order-id="<?= $row['order_id']; ?>"><?= htmlspecialchars($row['delivery_status'] ?? '') ?></td>
  <td><?= date('d M Y H:i:s', strtotime($row['order_date'])); ?></td>
        <td>
            <a href="../admin/order_details.php?oid=<?= $row['order_id']; ?>">
                View
            </a>
        </td>
    </tr>
<?php
    }
} else {
    echo "<tr><td colspan='5' align='center'>No orders found</td></tr>";
}
?>

</table>

<script>
function toggleMenu(){
    document.getElementById("navLinks").classList.toggle("show");
}

// Long-poll user's orders delivery status
(function(){
    let lastId = 0;
    async function poll(){
        try{
            const res = await fetch('../ajax/get_order_status.php?all=1&since='+lastId);
            const j = await res.json();
            if(!j.success){ setTimeout(poll,2000); return; }
            if(j.updates && j.updates.length){
                for(const u of j.updates){
                    const cell = document.querySelector('.delivery-status[data-order-id="'+u.order_id+'"]');
                    if(cell && cell.textContent.trim() !== (u.delivery_status || '').trim()){
                        cell.textContent = u.delivery_status || '';
                        cell.style.transition = 'background-color 0.3s';
                        cell.style.backgroundColor = '#ddffdd';
                        setTimeout(()=> cell.style.backgroundColor = '', 1200);
                    }
                    if(u.id && u.id > lastId) lastId = u.id;
                }
            }
        }catch(e){ console.error(e); }
        // immediately start next long-poll
        poll();
    }
    poll();
})();
</script>
<?php include '../includes/footer.php'; ?>
