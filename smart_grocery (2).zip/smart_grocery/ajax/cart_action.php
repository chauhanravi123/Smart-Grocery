<?php
session_start();
header('Content-Type: application/json');

include __DIR__ . '/../includes/db.php';

define('ITEM_MAX_LIMIT', 6);

/* ---------------------------
   VALIDATE REQUEST
---------------------------- */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success'=>false,'message'=>'Invalid request']);
    exit;
}

$pid = (int)($_POST['product_id'] ?? 0);
$action = $_POST['action'] ?? '';

if ($pid <= 0 || !in_array($action, ['plus', 'minus'])) {
    echo json_encode(['success'=>false,'message'=>'Invalid product or action']);
    exit;
}

/* ---------------------------
   FETCH PRODUCT INFO
---------------------------- */
$res = $conn->query("SELECT price, stock_qty FROM products WHERE product_id = $pid");
$product = $res->fetch_assoc();
if (!$product) {
    echo json_encode(['success'=>false,'message'=>'Product not found']);
    exit;
}

$stock = (int)$product['stock_qty'];
$price = (float)$product['price'];
$maxAllowed = min(ITEM_MAX_LIMIT, $stock);

$currentQty = $_SESSION['cart'][$pid] ?? 0;

/* ---------------------------
   APPLY ACTION WITH LIMITS
---------------------------- */
if ($action === 'plus') {
    if ($currentQty >= $maxAllowed) {
        echo json_encode([
            'success'=>false,
            'message'=> $stock < ITEM_MAX_LIMIT
                ? "Only $stock items left in stock."
                : "Maximum limit of ".ITEM_MAX_LIMIT." per item reached."
        ]);
        exit;
    }
    $_SESSION['cart'][$pid] = $currentQty + 1;

} elseif ($action === 'minus') {
    if ($currentQty > 1) {
        $_SESSION['cart'][$pid] = $currentQty - 1;
    } else {
        unset($_SESSION['cart'][$pid]);
    }
}

/* ---------------------------
   RECALCULATE TOTALS
---------------------------- */
$subtotal = 0;
$total_saving = 0;
$item_sub = 0;

foreach ($_SESSION['cart'] as $id => $qty) {

    $r = $conn->query("SELECT price, mrp FROM products WHERE product_id = $id")->fetch_assoc();

    if (!$r) continue;

    $price = (float)$r['price'];
    $mrp   = isset($r['mrp']) ? (float)$r['mrp'] : $price;

    $line = $price * $qty;
    $saving = ($mrp - $price) * $qty;

    $subtotal += $line;
    $total_saving += $saving;

    if ($id == $pid) {
        $item_sub = $line;
    }
}

$delivery = ($subtotal > 0 && $subtotal < 99) ? 30 : 0;
$grand_total = $subtotal + $delivery;

echo json_encode([
    'success'=>true,
    'item_qty'=>$_SESSION['cart'][$pid] ?? 0,
    'item_sub'=>number_format($item_sub,2),
    'subtotal'=>number_format($subtotal,2),
    'total_saving'=>number_format($total_saving,2),
    'delivery'=>$delivery > 0 ? "₹$delivery" : "FREE",
    'grand_total'=>number_format($grand_total,2),
    'cartCount'=>array_sum($_SESSION['cart']),
]);

