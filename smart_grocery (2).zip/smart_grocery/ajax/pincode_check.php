<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../includes/db.php';

$pincode = trim($_GET['pincode'] ?? $_POST['pincode'] ?? '');
if (!preg_match('/^[1-9][0-9]{5}$/', $pincode)) {
    echo json_encode(['serviceable' => false, 'message' => 'Enter valid 6-digit pincode']);
    exit;
}

// Default: serviceable if format is valid. If there is a table delivery_pincodes, use it.
$serviceable = true;
$check = $conn->query("SHOW TABLES LIKE 'delivery_pincodes'");
if ($check && $check->num_rows > 0) {
    $q = $conn->real_escape_string($pincode);
    $res = $conn->query("SELECT 1 FROM delivery_pincodes WHERE pincode = '$q' LIMIT 1");
    if (!$res || $res->num_rows == 0) $serviceable = false;
}

echo json_encode([
    'serviceable' => $serviceable,
    'pincode' => $pincode,
    'message' => $serviceable ? 'Delivery available' : 'Delivery not available to this pincode'
]);
