<?php
header('Content-Type: application/json');
include '../includes/db.php';
session_start();
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success'=>false,'error'=>'Not authenticated']);
    exit;
}

$since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
if ($since > 0) {
    // long-poll up to 20 seconds
    $start = time();
    while (time() - $start < 20) {
        $stmt = $conn->prepare("SELECT id, order_id, delivery_status, payment_method, collected_amount, created_at FROM order_updates WHERE id > ? ORDER BY id ASC");
        $stmt->bind_param('i', $since);
        $stmt->execute();
        $res = $stmt->get_result();
        $rows = $res->fetch_all(MYSQLI_ASSOC);
        if (count($rows) > 0) {
            echo json_encode(['success'=>true,'updates'=>$rows]);
            exit;
        }
        sleep(1);
    }
    echo json_encode(['success'=>true,'updates'=>[]]);
    exit;
}

// fallback: return recent updates (last 100)
$res = $conn->query("SELECT id, order_id, delivery_status, payment_method, collected_amount, created_at FROM order_updates ORDER BY id DESC LIMIT 100");
$rows = [];
while($r = $res->fetch_assoc()) $rows[] = $r;
$rows = array_reverse($rows);
echo json_encode(['success'=>true,'updates'=>$rows]);
