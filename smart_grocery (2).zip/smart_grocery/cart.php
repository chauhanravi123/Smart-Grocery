<?php
include 'user_auth.php';
include 'includes/db.php';

// ensure we use an integer user id from session
$user_id = (int)($_SESSION['user_id'] ?? 0);

/* INIT CART */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* UPDATE CART QTY */
if (isset($_POST['qty_action'])) {

    $pid = (int)$_POST['product_id'];

    if ($_POST['qty_action'] === 'plus') {
        $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + 1;
    }

    if ($_POST['qty_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }
}

/* PLACE ORDER */
if (isset($_POST['action']) && $_POST['action'] === 'order') {

    if (empty($_SESSION['cart'])) {
        $_SESSION['error'] = "Your cart is empty. Please add items before placing order.";
    } else {

        $name_in    = trim($_POST['name'] ?? '');
        $phone_in   = trim($_POST['phone'] ?? '');
        $address_id = (int)($_POST['address_id'] ?? 0);

        if ($address_id <= 0) {
            $_SESSION['error'] = 'Please select a delivery address.';
        } else {

            $addrRes = $conn->query("SELECT name, phone, address, city, pincode FROM user_addresses WHERE address_id = $address_id AND user_id = $user_id LIMIT 1");
            if (!$addrRes || $addrRes->num_rows === 0) {
                $_SESSION['error'] = 'Selected address is invalid.';
            } else {

                $addr = $addrRes->fetch_assoc();
                $name    = $name_in !== '' ? $conn->real_escape_string($name_in) : $conn->real_escape_string($addr['name']);
                $phone   = $phone_in !== '' ? $conn->real_escape_string($phone_in) : $conn->real_escape_string($addr['phone']);
                $address = $conn->real_escape_string($addr['address'] . ', ' . $addr['city'] . ' - ' . $addr['pincode']);

                $total = 0;
                $insufficientStock = [];

                // 1️⃣ Check stock & calculate total
                foreach ($_SESSION['cart'] as $pid => $qty) {
                    $p = $conn->query("SELECT price, stock_qty FROM products WHERE product_id=$pid")->fetch_assoc();
                    if (!$p) continue;

                    if ($qty > $p['stock_qty']) {
                        $insufficientStock[] = "Product ID $pid has only {$p['stock_qty']} items left";
                    }
                    $total += $p['price'] * $qty;
                }

                if (!empty($insufficientStock)) {
                    $_SESSION['error'] = implode('<br>', $insufficientStock);
                } else {
                    // 2️⃣ Insert order
                    $conn->query("INSERT INTO orders (user_id, name, phone, address, total) VALUES ('$user_id', '$name', '$phone', '$address', '$total')");
                    if ($conn->affected_rows > 0) {
                        $order_id = $conn->insert_id;

                        // 3️⃣ Insert order items & reduce stock
                        foreach ($_SESSION['cart'] as $pid => $qty) {
                            $product = $conn->query("SELECT price, image, stock_qty FROM products WHERE product_id=$pid")->fetch_assoc();
                            $price = (float)$product['price'];
                            $image = $conn->real_escape_string($product['image'] ?? '');

                            // Insert order item
                            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, image, price) VALUES ($order_id, $pid, $qty, '$image', $price)");

                            // Reduce stock
                            $newStock = max(0, $product['stock_qty'] - $qty);
                            $conn->query("UPDATE products SET stock_qty=$newStock WHERE product_id=$pid");
                        }

                        $_SESSION['success']  = true;
                        $_SESSION['order_id'] = $order_id;

                        // Clear cart
                        unset($_SESSION['cart']);
                    } else {
                        $_SESSION['error'] = 'Could not place order, please try again.';
                    }
                }
            }
        }
    }
}


if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $result = $conn->query("SELECT p.*, GROUP_CONCAT(pi.image SEPARATOR ',') AS images FROM products p LEFT JOIN product_images pi ON p.product_id = pi.product_id WHERE p.product_id IN ($ids) GROUP BY p.product_id");
}


$total = 0;
$total_saving = 0;
$delivery_charge = 0;
$grand_total = 0;
$cart_products = [];

if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $res = $conn->query("SELECT p.*, GROUP_CONCAT(pi.image SEPARATOR ',') AS images 
                         FROM products p 
                         LEFT JOIN product_images pi ON p.product_id = pi.product_id 
                         WHERE p.product_id IN ($ids) 
                         GROUP BY p.product_id");

    if ($res && $res->num_rows > 0) {
        while ($row = $res->fetch_assoc()) {
            $qty = $_SESSION['cart'][$row['product_id']];
            $unitPrice = (float)$row['price'];
            $mrp = isset($row['mrp']) ? (float)$row['mrp'] : $unitPrice;
            $sub = $unitPrice * $qty;
            $saving = ($mrp - $unitPrice) * $qty;

            $total += $sub;
            $total_saving += $saving;

            // store for HTML display
            $cart_products[] = [
                'data' => $row,
                'qty' => $qty,
                'sub' => $sub,
                'unitPrice' => $unitPrice
            ];
        }

        $delivery_charge = $total < 99 ? 30 : 0;
        $grand_total = $total + $delivery_charge;
    }
}



// Make sure we have a valid numeric user id
$user_id = (int)($user_id ?? 0);

// Fetch addresses for the current user only using a prepared statement
$stmt = $conn->prepare("
    SELECT address_id, name, phone, address, city, pincode, is_default
    FROM user_addresses
    WHERE user_id = ?
    ORDER BY is_default DESC, address_id DESC
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$addresses = $stmt->get_result();

$hasAddresses = ($user_id > 0 && $addresses && $addresses->num_rows > 0);


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Cart</title>
    <link rel="stylesheet" href="assets/css/cart.css">
</head>

<body>
    <nav class="navbar">
        <div class="nav-left">
            <a href="index.php" class="logo">🛒 SmartGrocery</a>
        </div>

        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="products.php">Menu</a></li>
            <li><a href="../user/my_orders.php">Orders</a></li>
            <li>
                <a href="cart.php" class="cart-link">
                    🛒 Cart
                    <span class="cart-count">
                        <?= array_sum($_SESSION['cart'] ?? []); ?>
                    </span>
                </a>
            </li>
            <li><a href="user/logout.php" class="logout">Logout</a></li>
        </ul>
    </nav>
    <?php if (!empty($_SESSION['success'])) { ?>

        <h2 style="color:green;">🎉 Order Placed Successfully!</h2>
        <p><b>Your Order ID:</b> <?= $_SESSION['order_id']; ?></p>

        <?php unset($_SESSION['success'], $_SESSION['order_id']); ?>

    <?php } ?>
    <?php if (!empty($_SESSION['error'])) { ?>
        <p style="color:red;"><b><?= $_SESSION['error']; ?></b></p>
        <?php unset($_SESSION['error']); ?>
    <?php } ?>

    <?php if (empty($_SESSION['cart'])) { ?>

        <p style="margin: 30px 20px; font-size: 1.1rem; color: #666;">Your cart is empty. <a href="products.php">Continue shopping →</a></p>

    <?php } elseif ($result && $result->num_rows > 0) { ?>

        <div class="cart-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Image</th>
                        <th>Unit Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_products as $item):
                        $row = $item['data'];
                        $qty = $item['qty'];
                        $unitPrice = $item['unitPrice'];
                        $sub = $item['sub'];

                        $firstImage = 'no-image.png';
                        if (!empty($row['images'])) {
                            $images = explode(',', $row['images']);
                            $firstImage = $images[0];
                        }
                    ?>
                        <tr data-product-id="<?= $row['product_id']; ?>">
                            <td data-label="Product">
                                <a href="product.php?id=<?= $row['product_id']; ?>" style="text-decoration:none; color:#0d6efd;">
                                    <?= htmlspecialchars($row['product_name']); ?>
                                </a>
                            </td>
                            <td data-label="Image">
                                <img src="assets/images/products/<?= htmlspecialchars($firstImage); ?>" width="60" height="60" style="object-fit:cover; border-radius:6px;" loading="lazy" alt="<?= htmlspecialchars($row['product_name']); ?>" onerror="this.src='assets/images/no-image.png'">
                            </td>
                            <td data-label="Unit Price">
                                <strong>₹<span class="item-price"><?= number_format($unitPrice, 2) ?></span></strong>
                            </td>
                            <td data-label="Quantity">
                                <div class="qty-controls">
                                    <button class="qty-btn" data-action="minus" aria-label="Decrease quantity">−</button>
                                    <span class="item-qty"><?= $qty ?></span>
                                    <button class="qty-btn" data-action="plus" aria-label="Increase quantity">+</button>
                                </div>
                            </td>
                            <td data-label="Subtotal">
                                <strong>₹<span class="item-sub"><?= number_format($sub, 2) ?></span></strong>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                </tbody>
                <tfoot>
                    <tr class="total-row">
                        <td colspan="4" style="text-align:right;"><strong>Subtotal:</strong></td>
                        <td><strong>₹<span id="cart-subtotal"><?= number_format($total, 2) ?></span></strong></td>
                    </tr>
                      <tr class="total-row">
                        <td colspan="4" style="text-align:right;"><strong>Total Savings:</strong></td>
                         <td><strong>₹<span id="total-saving"><?= number_format($total_saving, 2) ?></span></strong></td>
                      </tr> 
                      <tr class="total-row">
                        <td colspan="4" style="text-align:right;"><strong>Delivery Charge:</strong></td>
                        <td><strong><span id="delivery-charge"><?= $delivery_charge > 0 ? "₹$delivery_charge" : "FREE" ?></span></strong></td>
                    </tr>
                    <tr class="total-row grand-total">
                        <td colspan="4" style="text-align:right;"><strong>Grand Total:</strong></td>
                        <td><strong>₹<span id="grand-total"><?= number_format($grand_total, 2) ?></span></strong></td>
                    </tr>
                </tfoot>

            </table>
        </div>

        <div class="cart-bottom-summary" role="region" aria-label="Cart summary">
            <div class="delivery-check">
                <label for="pincode">Check delivery by pincode</label>
                <input type="text" id="pincode" maxlength="6" placeholder="e.g., 560001">
                <button id="check-pincode">Check</button>
                <div id="pincode-result" aria-live="polite" class="muted"></div>
            </div>
            <div class="checkout-actions">
                <button id="checkout-scroll" <?= empty($_SESSION['cart']) ? 'disabled' : '' ?>>Review & Place Order</button>
                <button id="continue-btn" type="button" onclick="location.href='products.php'">Continue Shopping</button>
            </div>
        </div>

    <?php } ?>

    <h2>Checkout</h2>

    <form id="checkout-form" method="post" onsubmit="return validateForm()">
        <input type="hidden" name="action" value="order">
        <h4>Select Delivery Address</h4>

        <?php if ($hasAddresses) {
            // Load all addresses into an array so we can decide which one should be checked
            $addrList = $addresses->fetch_all(MYSQLI_ASSOC);
            $defaultFound = false;
            foreach ($addrList as $idx => $a) {
                $aid = (int)$a['address_id'];
                $checked = '';
                if (!empty($a['is_default'])) {
                    $checked = 'checked';
                    $defaultFound = true;
                }
                // if no default at all, check the first address
                if (!$defaultFound && $idx === 0) {
                    $checked = 'checked';
                }
        ?>
                <div class="form-check border p-2 mb-2">
                    <input id="addr-<?= $aid ?>" class="form-check-input"
                        type="radio"
                        name="address_id"
                        value="<?= $aid ?>"
                        data-name="<?= htmlspecialchars($a['name'], ENT_QUOTES) ?>"
                        data-phone="<?= htmlspecialchars($a['phone'], ENT_QUOTES) ?>"
                        data-address="<?= htmlspecialchars($a['address'] . ', ' . $a['city'] . ' - ' . $a['pincode'], ENT_QUOTES) ?>"
                        <?= $checked ?>
                        required>

                    <label class="form-check-label" for="addr-<?= $aid ?>">
                        <strong><?= htmlspecialchars($a['name']) ?></strong><br>
                        <?= htmlspecialchars($a['address']) ?>,
                        <?= htmlspecialchars($a['city']) ?> - <?= htmlspecialchars($a['pincode']) ?><br>
                        Phone: <?= htmlspecialchars($a['phone']) ?>
                    </label>
                </div>
            <?php }
        } else { ?>
            <p style="color: #d00;">You have no saved delivery addresses. <a href="user/address.php">Add an address</a></p>
        <?php } ?>

        <button <?= (empty($_SESSION['cart']) || !$hasAddresses) ? 'disabled' : '' ?>>
            Place Order
        </button>

    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            function qsa(sel, el = document) {
                return Array.from(el.querySelectorAll(sel));
            }

            // Quantity buttons - event delegation on the table
            const table = document.querySelector('table');
            if (table) {
                table.addEventListener('click', async function(e) {
                    let btn = e.target.closest('.qty-btn');
                    if (!btn) return;
                    e.preventDefault();
                    let row = btn.closest('tr[data-product-id]');
                    let pid = row.getAttribute('data-product-id');
                    let action = btn.getAttribute('data-action');

                    // optimistic update
                    let qtyEl = row.querySelector('.item-qty');
                    let oldQty = parseInt(qtyEl.textContent, 10);
                    let newQty = action === 'plus' ? oldQty + 1 : Math.max(0, oldQty - 1);
                    qtyEl.textContent = newQty;

                    // disable buttons while in flight
                    let btns = row.querySelectorAll('.qty-btn');
                    btns.forEach(b => b.disabled = true);

                    try {
                        let form = new FormData();
                        form.append('product_id', pid);
                        form.append('action', action);
                        let res = await fetch('ajax/cart_action.php', {
                            method: 'POST',
                            body: form
                        });
                        let data = await res.json();
                        if (!data.success) throw new Error(data.message || 'Failed');
                        // update UI from response
                        row.querySelector('.item-qty').textContent = data.item_qty;
                        row.querySelector('.item-sub').textContent = data.item_sub;
                        document.getElementById('cart-subtotal').textContent = data.subtotal;
                        document.getElementById('total-saving').textContent = data.total_saving;
                        document.getElementById('delivery-charge').textContent = data.delivery;
                        document.getElementById('grand-total').textContent = data.grand_total;

                        qsa('.cart-count').forEach(el => el.textContent = data.cartCount);
                        // if qty is zero, remove row
                        if (data.item_qty == 0) {
                            row.remove();
                        }
                    } catch (err) {
                        alert('Could not update cart: ' + err.message);
                        // rollback
                        qtyEl.textContent = oldQty;
                    } finally {
                        btns.forEach(b => b.disabled = false);
                    }
                });
            }

            // pincode check
            const chk = document.getElementById('check-pincode');
            if (chk) chk.addEventListener('click', async function() {
                let p = document.getElementById('pincode').value.trim();
                let resEl = document.getElementById('pincode-result');
                resEl.textContent = 'Checking…';
                try {
                    let r = await fetch('ajax/pincode_check.php?pincode=' + encodeURIComponent(p));
                    let j = await r.json();
                    resEl.textContent = j.message || (j.serviceable ? 'Delivery available' : 'Not available');
                    resEl.style.color = j.serviceable ? 'green' : 'red';
                } catch (e) {
                    resEl.textContent = 'Error checking pincode';
                    resEl.style.color = 'red';
                }
            });

            // scroll to checkout
            const checkoutBtn = document.getElementById('checkout-scroll');
            if (checkoutBtn) checkoutBtn.addEventListener('click', function() {
                document.getElementById('name').focus();
                window.scrollTo({
                    top: document.getElementById('checkout-form').offsetTop - 20,
                    behavior: 'smooth'
                });
            });

            // Prefill name/phone from selected saved address if user hasn't entered them
            qsa('input[name="address_id"]').forEach(r => {
                r.addEventListener('change', function() {
                    if (!r.checked) return;
                    let dn = r.getAttribute('data-name') || '';
                    let dp = r.getAttribute('data-phone') || '';
                    let nameEl = document.getElementById('name');
                    let phoneEl = document.getElementById('phone');
                    if (nameEl && nameEl.value.trim() === '') nameEl.value = dn;
                    if (phoneEl && phoneEl.value.trim() === '') phoneEl.value = dp;
                });
            });

        }); // DOMContentLoaded

        function validateForm() {
            let phone = document.getElementById('phone').value.trim();
            let name = document.getElementById('name').value.trim();
            let addrSelected = document.querySelector('input[name="address_id"]:checked');
            if (!addrSelected) {
                alert("Please select a delivery address");
                return false;
            }
            // phone is optional (we'll use saved address phone if empty) but if provided must be valid
            if (phone !== '' && !/^[0-9]{10}$/.test(phone)) {
                alert("Enter valid 10 digit phone");
                return false;
            }
            return true;
        }
    </script>

</body>

</html>