<?php
session_start(); // ✅ REQUIRED

if (!isset($_SESSION['delivery_id'])) {
    header("Location: login.php");
    exit;
}
