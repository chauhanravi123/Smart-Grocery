<?php
// delivery/includes/nav.php
if (session_status() === PHP_SESSION_NONE) session_start();
$name = isset($_SESSION['delivery_name']) ? htmlspecialchars($_SESSION['delivery_name']) : '';
?>
<link rel="stylesheet" href="assets/css/delivery.css">
<nav class="delivery-nav">
    <div class="nav-inner">
        <div class="brand"><a href="dashboard.php">Smart Grocery <span class="muted">Delivery</span></a></div>
        <button class="nav-toggle" aria-expanded="false" aria-label="Toggle navigation">☰</button>
        <ul class="nav-links">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="orders.php">My Orders</a></li>
            <li><a href="order_view.php?id=">Order View</a></li>
            <li class="user">Logged in: <strong><?= $name ?></strong></li>
            <li class="logout"><a href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>
<script>
// simple toggle
document.addEventListener('click', function(e){
    if(e.target && e.target.matches('.nav-toggle')){
        const btn = e.target;
        const ul = btn.nextElementSibling.nextElementSibling || btn.nextElementSibling;
        const expanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', (!expanded).toString());
        if(ul) ul.classList.toggle('open');
    }
});
</script>