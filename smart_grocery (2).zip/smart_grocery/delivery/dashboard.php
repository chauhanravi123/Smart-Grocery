
<?php
include 'auth.php';              // session + login check
include '../includes/db.php';
include 'includes/nav.php';

$did = (int)$_SESSION['delivery_id']; // ✅ force integer

$stats = $conn->query("
    SELECT
      SUM(CASE WHEN delivery_status='Assigned' THEN 1 ELSE 0 END) AS assigned,
      SUM(CASE WHEN delivery_status='Out for Delivery' THEN 1 ELSE 0 END) AS onway,
      SUM(CASE WHEN delivery_status='Delivered' THEN 1 ELSE 0 END) AS delivered,
      SUM(COALESCE(collected_amount,0)) AS collected_total,
      SUM(CASE WHEN DATE(collected_at)=CURDATE() THEN COALESCE(collected_amount,0) ELSE 0 END) AS collected_today
    FROM orders
    WHERE delivery_id = $did
")->fetch_assoc();
?>

<h2>🚴 Delivery Dashboard</h2>

<div style="display:flex; gap:20px; align-items:center;">
    <div>📦 Assigned: <b><?= $stats['assigned'] ?? 0; ?></b></div>
    <div>🚚 On Way: <b><?= $stats['onway'] ?? 0; ?></b></div>
    <div>✅ Delivered: <b><?= $stats['delivered'] ?? 0; ?></b></div>
    <div>💰 Collected: <b>₹<?= number_format($stats['collected_total'] ?? 0,2) ?></b> <span class="muted">(Today: ₹<?= number_format($stats['collected_today'] ?? 0,2) ?>)</span></div>
</div>
