<?php
include 'auth.php';
include '../includes/db.php';
include 'includes/nav.php';

$order_id = (int)$_GET['id'];
$did = (int)$_SESSION['delivery_id'];

/* fetch order and ensure it belongs to this delivery boy */
$stmt = $conn->prepare("SELECT delivery_status, total, delivery_id, COALESCE(collected_amount,0) AS collected_amount, payment_method FROM orders WHERE order_id = ? LIMIT 1");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    echo "<h3>Order not found</h3>";
    exit;
}

if ((int)$order['delivery_id'] !== $did) {
    echo "<h3>Unauthorized</h3>";
    exit;
}

$current_status = $order['delivery_status'];
$final_statuses = ['Delivered','Undelivered'];

// If already final, show read-only info (delivery boy cannot change)
if (in_array($current_status, $final_statuses)) {
    echo "<h3>Order status is final: " . htmlspecialchars($current_status) . "</h3>";
    if (!empty($order['collected_amount'])) {
        echo "<p>Collected: ₹".number_format($order['collected_amount'],2)."</p>";
    }
    if (!empty($order['payment_method'])) {
        echo "<p>Payment Method: " . htmlspecialchars($order['payment_method']) . "</p>";
    }
    echo "<p><a href='orders.php'>Back to orders</a></p>";
    exit;
} 

if (isset($_POST['update'])) {

    $allowed = ['Pending','Assigned','Out for Pickup','Out for Delivery','Delivered','Undelivered'];
    $status = trim($_POST['delivery_status']);

    if (!in_array($status, $allowed)) {
        die("Invalid status selected!");
    }

    // disallow changing if already final
    if (in_array($current_status, $final_statuses)) {
        die("Status already final (".$current_status."). You cannot change it.");
    }

    $collected = isset($_POST['collected']) ? 1 : 0;
    $payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';
    $allowed_methods = ['Cash','Card','UPI','Prepaid','Other'];
    if ($payment_method === '' || !in_array($payment_method, $allowed_methods)) {
        die('Please select a valid payment method before updating status.');
    }

    if ($status === 'Delivered') {
        if ($collected) {
            $upd = $conn->prepare("UPDATE orders SET delivery_status=?, delivered_at=NOW(), collected_amount=?, collected_at=NOW(), payment_method=? WHERE order_id=?");
            $col_amount = floatval($order['total']);
            $upd->bind_param('sdis', $status, $col_amount, $payment_method, $order_id);
        } else {
            $upd = $conn->prepare("UPDATE orders SET delivery_status=?, delivered_at=NOW(), payment_method=? WHERE order_id=?");
            $upd->bind_param('ssi', $status, $payment_method, $order_id);
        }
        $ok = $upd->execute();
    } else {
        $upd = $conn->prepare("UPDATE orders SET delivery_status=?, payment_method=? WHERE order_id=?");
        $upd->bind_param('ssi', $status, $payment_method, $order_id);
        $ok = $upd->execute();
    }

    if ($ok) {
        // write an order update event for real-time clients
        $ins = $conn->prepare("INSERT INTO order_updates (order_id, delivery_status, payment_method, collected_amount) VALUES (?, ?, ?, ?)");
        $col_amt = ($collected ? floatval($order['total']) : 0.0);
        $pm = $payment_method ?? '';
        $ins->bind_param('issd', $order_id, $status, $pm, $col_amt);
        $ins->execute();

        header("Location: orders.php");
        exit;
    } else {
        die("Failed to update status");
    }
}

$form_method = $order['payment_method'] ?? '';
?>

<form method="post">
    <label>Status</label>
    <select name="delivery_status" required>
        <option value="Pending"<?= $current_status === 'Pending' ? ' selected' : '' ?>>Pending</option>
        <option value="Assigned"<?= $current_status === 'Assigned' ? ' selected' : '' ?>>Assigned</option>
        <option value="Out for Pickup"<?= $current_status === 'Out for Pickup' ? ' selected' : '' ?>>Out For Pickup</option>
        <option value="Out for Delivery"<?= $current_status === 'Out for Delivery' ? ' selected' : '' ?>>Out for Delivery</option>
        <option value="Delivered"<?= $current_status === 'Delivered' ? ' selected' : '' ?>>Delivered</option>
        <option value="Undelivered"<?= $current_status === 'Undelivered' ? ' selected' : '' ?>>Undelivered</option>
    </select>

    <div style="margin-top:8px;">
        <label><input type="checkbox" name="collected" value="1"> Collected cash from customer (₹<?= number_format($order['total'],2) ?>)</label>
    </div>

    <div style="margin-top:8px;">
        <label>Payment Method</label>
        <select name="payment_method" required>
            <option value=""<?= $form_method === '' ? ' selected' : '' ?>>-- Select --</option>
            <option value="Cash"<?= $form_method === 'Cash' ? ' selected' : '' ?>>Cash</option>
            <option value="Card"<?= $form_method === 'Card' ? ' selected' : '' ?>>Card</option>
            <option value="UPI"<?= $form_method === 'UPI' ? ' selected' : '' ?>>UPI</option>
            <option value="Prepaid"<?= $form_method === 'Prepaid' ? ' selected' : '' ?>>Prepaid (already paid)</option>
            <option value="Other"<?= $form_method === 'Other' ? ' selected' : '' ?>>Other</option>
        </select>
    </div>

    <div style="margin-top:10px;">
        <button name="update" type="submit">Update Status</button>
        <a href="orders.php" class="btn btn-outline" style="margin-left:8px">Cancel</a>
    </div>
</form>
