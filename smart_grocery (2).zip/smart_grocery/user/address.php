<?php
session_start();
include '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

/* Set default address */
if (isset($_GET['default'])) {
    $aid = (int)$_GET['default'];

    $conn->query("UPDATE user_addresses SET is_default=0 WHERE user_id=$user_id");
    $conn->query("UPDATE user_addresses SET is_default=1 WHERE address_id=$aid AND user_id=$user_id");

    header("Location: addresses.php");
    exit;
}

/* Add address */
if (isset($_POST['add_address'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];

    $stmt = $conn->prepare("
        INSERT INTO user_addresses 
        (user_id, name, phone, address, city, pincode) 
        VALUES (?,?,?,?,?,?)
    ");
    $stmt->bind_param("isssss", $user_id, $name, $phone, $address, $city, $pincode);
    $stmt->execute();

    header("Location: addresses.php");
    exit;
}

/* Fetch addresses */
$addresses = $conn->query("
    SELECT * FROM user_addresses 
    WHERE user_id=$user_id 
    ORDER BY is_default DESC, address_id DESC
");
?>
<div class="container mt-4">

<h3>My Addresses</h3>

<div class="row">

<?php while($a = $addresses->fetch_assoc()) { ?>
    <div class="col-md-4">
        <div class="card mb-3 <?= $a['is_default'] ? 'border-success' : '' ?>">
            <div class="card-body">
                <h6><?= htmlspecialchars($a['name']) ?></h6>
                <p><?= htmlspecialchars($a['phone']) ?></p>
                <p>
                    <?= htmlspecialchars($a['address']) ?><br>
                    <?= htmlspecialchars($a['city']) ?> - <?= htmlspecialchars($a['pincode']) ?>
                </p>

                <?php if ($a['is_default']) { ?>
                    <span class="badge bg-success">Default</span>
                <?php } else { ?>
                    <a href="?default=<?= $a['address_id'] ?>" class="btn btn-sm btn-outline-success">
                        Set Default
                    </a>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>

</div>

<hr>

<h4>Add New Address</h4>

<form method="post">
    <input type="text" name="name" class="form-control mb-2" placeholder="Full Name" required>
    <input type="text" name="phone" class="form-control mb-2" placeholder="Phone" required>
    <textarea name="address" class="form-control mb-2" placeholder="Address" required></textarea>
    <input type="text" name="city" class="form-control mb-2" placeholder="City" required>
    <input type="text" name="pincode" class="form-control mb-2" placeholder="Pincode" required>
    <button class="btn btn-success" name="add_address">Save Address</button>
</form>

</div>
