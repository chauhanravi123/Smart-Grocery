<?php
include '../includes/db.php';  
session_start();    

$username = $_POST['username'];
$password = $_POST['password'];
$stmt = $conn->prepare("SELECT user_id , password  FROM users WHERE phone=? OR email=?");
$stmt ->bind_param("ss", $username, $username);
$stmt ->execute();
$result = $stmt ->get_result();
if($result->num_rows == 0)
{
    echo json_encode(["status"=>"error","message"=>"User Not Registered"]);
    exit;
}

$user =$result->fetch_assoc();
if(!password_verify($password, $user['password']))
{
    echo json_encode(["status"=>"error","message"=>"InCorrect Password"]);
    exit;
}
$_SESSION['user_id'] = $user['user_id'];

echo json_encode(["status"=>"success" , "message"=>"Login Successful"]);

?>