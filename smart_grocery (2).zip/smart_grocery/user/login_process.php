<?php
session_start();
include '../includes/db.php';

$phone_email = $_POST['phone_email'] ?? '';
$password    = $_POST['password'] ?? '';

$sql = "SELECT user_id, password FROM users WHERE phone=? OR email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $phone_email, $phone_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    if (password_verify($password, $row['password'])) {

        $_SESSION['user_id'] = $row['user_id'];

        // ✅ redirect back
        if (isset($_SESSION['redirect_to'])) {
            $redirect = $_SESSION['redirect_to'];
            unset($_SESSION['redirect_to']);
            header("Location: $redirect");
        } else {
            header("Location: ../index.php");
        }
        exit;
    }
}

header("Location: login.php?error=1");
exit;
