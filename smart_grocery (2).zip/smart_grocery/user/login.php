<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

<div class="login-container">

    <div class="login-card">
        <h2>User Login</h2>

        <?php if (isset($_GET['error'])) { ?>
            <p class="error-msg">Invalid login credentials</p>
        <?php } ?>

        <form method="POST" action="login_process.php">
            <input type="text" name="phone_email" placeholder="Email or Phone" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>

        <!-- Admin Login Button -->
        <a href="../admin/login.php" class="admin-btn">Admin Login</a>
        <a href="../delivery/login.php" class="delivery-btn">Delivery Login</a>
        <!-- Register Link -->
        <p class="register-text">
            New user? <a href="../register.php">Create an account</a>
        </p>

    </div>

</div>

</body>
</html>
