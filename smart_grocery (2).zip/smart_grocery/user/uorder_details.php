<?php
include '../includes/db.php';
include '../user_auth.php';


$user_id  = (int)$_SESSION['user_id'];
$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($order_id <= 0) {
    die("Invalid Order ID.");
}

/* =========================
   FETCH ORDER (SECURE)
========================= */
$stmt = $conn->prepare("
    SELECT order_id, name, phone, address, total, delivery_status
    FROM orders
    WHERE order_id = ? AND user_id = ?
");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    die("Invalid Order.");
}

/* =========================
   FETCH ORDER ITEMS
========================= */
$stmt2 = $conn->prepare("
    SELECT 
        oi.quantity,
        oi.price,
        (oi.quantity * oi.price) AS subtotal,
        p.product_name,
        GROUP_CONCAT(pi.image SEPARATOR ',') AS images
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id
    WHERE oi.order_id = ?
    GROUP BY oi.product_id, oi.quantity, oi.price, p.product_name
");

$stmt2->bind_param("i", $order_id);
$stmt2->execute();
$items = $stmt2->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Order #<?= $order_id ?> Details</title>
    <style>
    
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background: #f4f6f9;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 1000px;
        margin: 40px auto;
        background: #ffffff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }

    h2 {
        margin-bottom: 20px;
        font-size: 24px;
        border-bottom: 2px solid #eee;
        padding-bottom: 10px;
    }

    .order-info {
        background: #fafafa;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 25px;
        line-height: 1.8;
        font-size: 15px;
    }

    .order-info strong {
        display: inline-block;
        width: 100px;
        color: #555;
    }

    .status {
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: bold;
        display: inline-block;
    }

    .pending { background: #fff3cd; color: #856404; }
    .delivered { background: #d4edda; color: #155724; }
    .cancelled { background: #f8d7da; color: #721c24; }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        font-size: 14px;
    }

    th {
        background: #f1f3f6;
        padding: 12px;
        text-align: left;
        border-bottom: 2px solid #ddd;
        font-weight: 600;
    }

    td {
        padding: 12px;
        border-bottom: 1px solid #eee;
        vertical-align: middle;
    }

    tr:hover {
        background: #fafafa;
    }

    .product-cell {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .product-cell img {
        width: 70px;
        height: 70px;
        object-fit: cover;
        border-radius: 10px;
        border: 1px solid #eee;
    }

    .price {
        font-weight: 500;
        color: #333;
    }

    .subtotal {
        font-weight: 600;
        color: #000;
    }

    .total-row td {
        font-size: 16px;
        font-weight: bold;
        background: #fafafa;
    }

    .grand-total {
        text-align: right;
        font-size: 18px;
        font-weight: bold;
        margin-top: 20px;
    }

    .back-btn {
        display: inline-block;
        margin-top: 25px;
        padding: 10px 18px;
        background: #2874f0;
        color: #fff;
        text-decoration: none;
        border-radius: 6px;
        transition: 0.3s;
    }

    .back-btn:hover {
        background: #1c5dc9;
    }

    /* Responsive */
    @media(max-width:768px){
        .product-cell {
            flex-direction: column;
            align-items: flex-start;
        }

        th, td {
            font-size: 13px;
        }
    }

    </style>
</head>
<body>
<div class="container">

<h2>Order #<?= $order_id ?></h2>

<p>
<!--<strong>Date:</strong> <?= htmlspecialchars($order['created_at'] ?? '') ?><br>-->
<strong>Name:</strong> <?= htmlspecialchars($order['name']) ?><br>
<strong>Phone:</strong> <?= htmlspecialchars($order['phone']) ?><br>
<strong>Address:</strong> <?= htmlspecialchars($order['address']) ?><br>

<?php
$status = strtolower($order['delivery_status'] ?? 'pending');
$statusClass = 'pending';

if ($status === 'delivered') $statusClass = 'delivered';
if ($status === 'cancelled') $statusClass = 'cancelled';
?>

<strong>Status:</strong> 
<span class="status <?= $statusClass ?>">
    <?= ucfirst($status) ?>
</span>
</p>

<h3>Order Items</h3>

<table>
<tr>
    <th>Product</th>
    <th>Image</th>
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Subtotal</th>
</tr>

<?php while ($row = $items->fetch_assoc()): 
    $image = 'no-image.png';
    if (!empty($row['images'])) {
        $imgArr = explode(',', $row['images']);
        $image = $imgArr[0];
    }
?>

<tr>
    <td><?= htmlspecialchars($row['product_name']) ?></td>

    <td>
        <img src="../assets/images/products/<?= htmlspecialchars($image) ?>" 
             width="60"
             height="60"
             style="object-fit:cover;"
             alt="Product"
             onerror="this.src='../assets/images/no-image.png'">
    </td>

    <td><?= (int)$row['quantity'] ?></td>

    <td>₹<?= number_format($row['price'], 2) ?></td>

    <td>₹<?= number_format($row['subtotal'], 2) ?></td>
</tr>
<?php endwhile; ?>

<tr class="total-row">
    <td colspan="4" align="right">Grand Total</td>
    <td>₹<?= number_format($order['total'], 2) ?></td>
</tr>

</table>

<br>
<a href="my_orders.php">← Back to My Orders</a>
</div>
</body>
</html>
