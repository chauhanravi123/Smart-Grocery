<?php

include '../includes/db.php';

if(empty($_SESSION['cart'])) {
    die("Cart is empty");
}

// Collect form data
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$payment = $_POST['payment_method'];
$total = 0;

// Calculate total
foreach($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['qty'];
}

// Insert order into database (orders table)
$conn->query("INSERT INTO orders (name, phone, address, payment_method, total) 
              VALUES ('$name', '$phone', '$address', '$payment', '$total')");

$order_id = $conn->insert_id;

// Insert order items (order_items table)
foreach($_SESSION['cart'] as $pid => $item) {
    $conn->query("INSERT INTO order_items (order_id, product_id, qty, price) 
                  VALUES ($order_id, $pid, {$item['qty']}, {$item['price']})");
}

// Clear cart
unset($_SESSION['cart']);

echo "<p>Order placed successfully! Your Order ID is $order_id</p>";
echo "<a href='index.php'>Continue Shopping</a>";
?>