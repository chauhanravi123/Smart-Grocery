-- Migration: add collected_amount and collected_at to orders
-- Run this once (e.g. in MySQL client or phpMyAdmin)

ALTER TABLE `orders`
  ADD COLUMN `collected_amount` DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER `total`,
  ADD COLUMN `collected_at` DATETIME NULL AFTER `collected_amount`;

-- Optional: add index if you will query by collected_at
-- CREATE INDEX idx_orders_collected_at ON orders(collected_at);
