-- Migration: add order_updates table to store real-time updates
-- Run this once (e.g. in MySQL client or phpMyAdmin)

CREATE TABLE `order_updates` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_id` INT NOT NULL,
  `delivery_status` VARCHAR(100) NOT NULL,
  `payment_method` VARCHAR(50) NULL,
  `collected_amount` DECIMAL(10,2) DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX (`order_id`),
  INDEX (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
