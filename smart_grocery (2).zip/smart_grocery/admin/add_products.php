<?php

include '../includes/db.php';
include 'admin_header.php';
// Fetch Categories //
$cats = $conn->query("SELECT * FROM categories WHERE status=1");

// Add Products
if (isset($_POST['add_product'])) {

    $name        = $_POST['product_name'];
    $price       = $_POST['price'];
    $category_id = (int)$_POST['category_id'];
    $description = $_POST['description'];
    $stock       = (int)$_POST['stock'];



    $mrp = (float)($_POST['mrp'] ?? 0.00);
    $short_desc = trim($_POST['short_description'] ?? '');

    /* INSERT PRODUCT FIRST */
    $stmt = $conn->prepare(
        "INSERT INTO products (category_id, product_name, price, mrp, stock_qty, description, short_description) VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("isddiss", $category_id, $name, $price, $mrp, $stock, $description, $short_desc);
    if (!$stmt->execute()) {
        die("Product insert failed: " . $stmt->error);
    }
    $product_id = $conn->insert_id;

    /* UPLOAD AND INSERT IMAGES */
    $uploadDir = "../assets/images/products/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (!empty($_FILES['product_images']['name'][0])) {
        foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp) {
            if (empty($_FILES['product_images']['name'][$key])) continue;

            $ext = strtolower(pathinfo($_FILES['product_images']['name'][$key], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
                $img = time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($tmp, $uploadDir . $img);

                /* INSERT INTO product_images TABLE */
                $stmt2 = $conn->prepare("INSERT INTO product_images (product_id, image) VALUES (?, ?)");
                $stmt2->bind_param("is", $product_id, $img);
                $stmt2->execute();
            }
        }
    }

    echo "<p class='success-msg'>Product added successfully!</p>";
}

?>

<div class="product-container">

    <h2>Add New Product</h2>

    <form method="POST" enctype="multipart/form-data">

        <label for="category_id">Category</label>
        <select id="category_id" name="category_id" required>
            <option value="">Select Category</option>
            <?php while ($cat = $cats->fetch_assoc()) { ?>
                <option value="<?php echo $cat['category_id']; ?>">
                    <?php echo $cat['category_name']; ?>
                </option>
            <?php } ?>
        </select>

        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" required>

        <label for="price">Price (₹)</label>
        <input type="number" id="price" name="price" step="0.01" required>

        <label for="mrp">MRP (Actual Price)</label>
        <input type="number" id="mrp" name="mrp" step="0.01" required>

        <label for="short_description">Short Description (optional)</label>
        <input type="text" id="short_description" name="short_description">
        
        <label for="stock">Stock</label>
        <input type="number" id="stock" name="stock" min="0" required>

        <label>Product Image</label>
        <input type="file" name="product_images[]" multiple accept="image/*">

        <label for="description">Description</label>
        <textarea id="description" name="description" rows="4" required></textarea>

        <button type="submit" name="add_product">Add Product</button>

    </form>

</div>