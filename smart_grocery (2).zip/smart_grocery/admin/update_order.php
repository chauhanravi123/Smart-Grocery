<?php
include '../includes/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $order_id = (int) $_POST['order_id'];
    $status   = $_POST['status'];

    $allowed = ['pending', 'processing', 'delivered', 'cancelled'];

    if (in_array($status, $allowed)) {

        $stmt = $conn->prepare("UPDATE orders SET status=? WHERE order_id=?");
        $stmt->bind_param("si", $status, $order_id);

        if ($stmt->execute()) {
            header("Location: orders.php?success=1");
            exit;
        } else {
            echo "Failed to update status";
        }
    }
}
