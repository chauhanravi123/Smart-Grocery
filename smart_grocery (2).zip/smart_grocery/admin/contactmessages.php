<?php
include 'admin_auth.php';
include '../includes/db.php';

$result = $conn->query("SELECT * FROM contactus ORDER BY id DESC");
?>

<h2>Contact Messages</h2>

<table border="1" width="100%" cellpadding="8">
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Subject</th>
    <th>Message</th>
    <th>Date</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>
<tr>
    <td><?= $row['name'] ?></td>
    <td><?= $row['email'] ?></td>
    <td><?= $row['subject'] ?></td>
    <td><?= $row['message'] ?></td>
    <td><?= $row['created_at'] ?></td>
</tr>
<?php } ?>
</table>
