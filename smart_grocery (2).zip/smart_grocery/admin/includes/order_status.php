<?php
include '../includes/db.php';

// optional filter: date or delivery_id
$filter_date = isset($_GET['date']) ? $_GET['date'] : '';
$filter_delivery = isset($_GET['delivery_id']) ? (int)$_GET['delivery_id'] : 0;

$sql = "SELECT o.order_id, o.delivery_status, o.delivery_id, d.name AS delivery_name, d.phone AS delivery_phone 
        FROM orders o 
        LEFT JOIN delivery_boys d ON o.delivery_id = d.delivery_id";

$params = [];
$types = '';
$conditions = [];

if($filter_date){
    $conditions[] = "DATE(o.order_date) = ?";
    $params[] = $filter_date;
    $types .= 's';
}

if($filter_delivery){
    $conditions[] = "o.delivery_id = ?";
    $params[] = $filter_delivery;
    $types .= 'i';
}

if($conditions){
    $sql .= " WHERE " . implode(' AND ', $conditions);
}

$sql .= " ORDER BY o.order_id DESC";

$stmt = $conn->prepare($sql);
if($params){
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$res = $stmt->get_result();

$orders = [];
while($row = $res->fetch_assoc()){
    $orders[$row['order_id']] = $row;
}

header('Content-Type: application/json');
echo json_encode($orders);
?>
<script>
function refreshOrders(){
    fetch('orders_status.php')
    .then(res => res.json())
    .then(data => {
        for(let orderId in data){
            const order = data[orderId];

            // update delivery name/phone
            const delCell = document.getElementById('delivery_' + orderId);
            if(delCell){
                if(order.delivery_name){
                    delCell.innerHTML = order.delivery_name + ' <span class="small muted">(' + order.delivery_phone + ')</span>';
                }else{
                    delCell.innerHTML = '<em class="muted">Unassigned</em>';
                }
            }

            // update status
            const statusCell = document.getElementById('status_' + orderId);
            if(statusCell){
                statusCell.innerText = order.delivery_status;
            }
        }
    });
}

// Refresh every 5 seconds
setInterval(refreshOrders, 5000);

// initial refresh
refreshOrders();
</script>
