<?php
include 'admin_auth.php';
include '../includes/db.php';

/* Total Products */
$result = $conn->query("SELECT COUNT(*) AS total FROM products");
$row = $result->fetch_assoc();
$totalProducts = $row['total'];

/* Total categories */
$result = $conn->query("SELECT COUNT(*) AS total FROM categories");
$row = $result->fetch_assoc();
$totalCategory = $row['total'];

/* Total Orders */
$result = $conn->query("SELECT COUNT(*) AS total FROM orders");
$row = $result->fetch_assoc();
$totalorders = $row['total'];

/*Pending Orders */
$result = $conn->query("
    SELECT COUNT(*) AS total 
    FROM orders 
    WHERE LOWER(TRIM(status)) = 'pending'
");
$row = $result->fetch_assoc();
$pendingorders = $row['total'] ?? 0;


/*Processing orders */
$result = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='processing'");
$row = $result->fetch_assoc();
$processingorders = $row['total'];

/* Delivered Orders */
$result = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='Delivered'");
$row = $result->fetch_assoc();
$deliveredorders = $row['total'];

/*Cancelled Orders*/
$result  = $conn->query("SELECT COUNT(*) AS total FROM orders WHERE status='cancelled'");
$row = $result->fetch_assoc();
$cancelledorders = $row['total'];

/* Total Revenue */
$result = $conn->query("SELECT SUM(total) AS revenue FROM orders WHERE status='Delivered'");
$totalrevenue = $result->fetch_assoc()['revenue'] ?? 0;

/* Total Customers */
$result = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role='user'");
$totalcustomer = $result->fetch_assoc()['total'];

/* Recent Orders */
$recentOrders = $conn->query("
    SELECT order_id, name, total, status
    FROM orders
    ORDER BY order_id DESC
    LIMIT 5
");

?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Smart Grocery</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="assets/js/admin.js" defer></script>
</head>


<body>

    <div class="dashboard">
        <?php include 'sidebar.php'; ?>
        <!-- Main Content -->
        <main class="main-content">

            <header class="topbar">
                <h1>Admin Dashboard</h1>
                <span>Welcome, <?php echo $_SESSION['admin_name']; ?></span>
            </header>

            <div id="mainContent">
                <?php include 'dashboard_content.php'; ?>
            </div>

        </main>
    </div>

    <!-- Modal container for AJAX dialogs -->
    <div id="adminModal" class="modal" aria-hidden="true">
        <div class="modal-backdrop" onclick="document.getElementById('adminModal').classList.remove('open')"></div>
        <div class="modal-dialog">
            <div class="modal-content" id="adminModalContent"></div>
        </div>
    </div>


</body>

</html>