<aside class="sidebar">
    <div class="brand">
        <div class="logo">SG</div>
        <h2>Smart Grocery</h2>
    </div>
    <nav>
        <ul>
            <li class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">
                <a href="dashboard.php" class="nav-link" data-page="dashboard.php"><i class="fa fa-chart-pie"></i><span class="label">Dashboard</span></a>
            </li>

            <li class="<?= basename($_SERVER['PHP_SELF'])=='add_category.php'?'active':'' ?>">
                <a href="add_category.php" class="nav-link" data-page="add_category.php"><i class="fa fa-folder-plus"></i><span class="label">Add Categories</span></a>
            </li>

            <li class="<?= basename($_SERVER['PHP_SELF'])=='add_products.php'?'active':'' ?>">
                <a href="add_products.php" class="nav-link" data-page="add_products.php"><i class="fa fa-box-open"></i><span class="label">Add Products</span></a>
            </li>

            <li class="<?= basename($_SERVER['PHP_SELF'])=='manage_category.php'?'active':'' ?>">
                <a href="manage_category.php" class="nav-link" data-page="manage_category.php"><i class="fa fa-list"></i><span class="label">Manage Categories</span></a>
            </li>

            <li class="<?= basename($_SERVER['PHP_SELF'])=='edit_product.php'?'active':'' ?>">
                <a href="manage_products.php" class="nav-link" data-page="manage_products.php"><i class="fa fa-boxes"></i><span class="label">Manage Products</span></a>
            </li>
            <li class="<?=  basename($_SERVER['PHP_SELF'])== 'assign_delivery.php'?'active' :''?>">
                <a href="assign_delivery.php" class="nav-link" data-page="assign_delivery.php"><i class="fa fa-car"></i><span class="label">Delivery</span></a>
            </li>
            <li class="<?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>">
                <a href="orders.php" class="nav-link" data-page="orders.php"><i class="fa fa-receipt"></i><span class="label">Orders</span></a>
            </li>

            <li>
                <a href="logout.php" target="_top"><i class="fa fa-sign-out-alt"></i><span class="label">Logout</span></a>
            </li>
        </ul>
    </nav>
    <div class="footer">v1.0 · Smart Grocery</div>
</aside>