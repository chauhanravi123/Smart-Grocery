// admin.js - AJAX page loader, sidebar toggle, counters

document.addEventListener('DOMContentLoaded', function(){
  const sidebar = document.querySelector('.sidebar');
  const toggleBtn = document.getElementById('sidebarToggle');
  const mainContent = document.getElementById('mainContent');

  // sidebar collapsed state restore
  try{ if(localStorage.getItem('admin_sidebar_collapsed')==='1') sidebar.classList.add('collapsed'); }catch(e){}
  if(toggleBtn){ toggleBtn.addEventListener('click', function(){ sidebar.classList.toggle('collapsed'); localStorage.setItem('admin_sidebar_collapsed', sidebar.classList.contains('collapsed') ? '1' : '0'); }); }

  // helper: execute scripts from HTML string / Document
  function runScripts(node){
    // run inline scripts
    node.querySelectorAll('script').forEach(s=>{
      const newScript = document.createElement('script');
      if(s.src) newScript.src = s.src;
      if(s.type) newScript.type = s.type;
      if(!s.src) newScript.textContent = s.textContent;
      document.body.appendChild(newScript).parentNode.removeChild(newScript);
    });
  }
  document.addEventListener("DOMContentLoaded", function () {

    const links = document.querySelectorAll(".nav-link");
    const mainContent = document.getElementById("mainContent");

    links.forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();

            const page = this.getAttribute("data-page");

            fetch(page)
                .then(response => response.text())
                .then(data => {
                    mainContent.innerHTML = data;
                })
                .catch(error => {
                    mainContent.innerHTML = "<p>Error loading page.</p>";
                    console.error(error);
                });
        });
    });

});


  async function loadPage(url, push = true){
    if(!url) return;
    // show loader
    if(mainContent){ mainContent.innerHTML = '<div class="table-section loader"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>'; }

    try{
      const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const html = await res.text();
      // parse
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');
      // prefer main or #mainContent or body
      const fragment = doc.querySelector('main')?.innerHTML || doc.querySelector('#main-content')?.innerHTML || doc.body.innerHTML;
      if(mainContent) mainContent.innerHTML = fragment || '<p class="muted">No content</p>';
      // run scripts inside fetched content
      runScripts(doc);

      // animate counters
      animateCounts();

      // update active link
      document.querySelectorAll('.sidebar nav li').forEach(li=>li.classList.remove('active'));
      const path = url.split('/').pop().split('?')[0];
      const link = document.querySelector('.sidebar a.nav-link[data-page="'+path+'"]');
      if(link) link.parentElement.classList.add('active');

      if(push) history.pushState({url}, '', url);
    }catch(e){
      if(mainContent) mainContent.innerHTML = '<div class="table-section"><p class="muted">Error loading page</p></div>';
      console.error(e);
    }
  }

  // Attach click handlers to sidebar links
  document.querySelectorAll('.sidebar nav a.nav-link').forEach(a=>{
    a.removeAttribute('target');
    a.addEventListener('click', function(e){ e.preventDefault(); const href = this.getAttribute('href'); loadPage(href, true); });
  });

  // Modal helpers
  const adminModal = document.getElementById('adminModal');
  const adminModalContent = document.getElementById('adminModalContent');
  function showModal(html){
    if(!adminModal) return;
    adminModalContent.innerHTML = html;
    adminModal.classList.add('open');
    // run any scripts inside
    runScripts(adminModalContent);
  }
  function closeModal(){ if(adminModal) adminModal.classList.remove('open'); }

  // Delegate clicks on links inside main content to load via AJAX (prevents full reload)
  if(mainContent){
    mainContent.addEventListener('click', function(e){
      const a = e.target.closest('a');
      if(!a) return;
      const href = a.getAttribute('href');
      // If this is an assign link, open in modal
      if(href && href.indexOf('assign_delivery.php') !== -1){
        e.preventDefault();
        (async function(){
          try{
            const res = await fetch(href, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const html = await res.text();
            showModal(html);
            // attach submit handler
            const form = adminModalContent.querySelector('form');
            if(form){
              form.addEventListener('submit', async function(ev){
                ev.preventDefault();
                const data = new FormData(form);
                try{
                  const r = await fetch(form.action, { method: 'POST', body: data, headers: { 'X-Requested-With':'XMLHttpRequest' } });
                  const json = await r.json();
                  if(json && json.success){
                    closeModal();
                    // reload orders table
                    loadPage('orders.php', false);
                  }else{
                    const err = adminModalContent.querySelector('.error-msg') || document.createElement('div');
                    err.className = 'error-msg';
                    err.textContent = (json && json.message) ? json.message : 'Failed to assign';
                    adminModalContent.prepend(err);
                  }
                }catch(err){
                  console.error(err);
                }
              });
            }
          }catch(err){ console.error(err); }
        })();
        return;
      }

      // ignore external links, anchors, JavaScript, and links with target _top/_blank
      if(!href || href.startsWith('http') || href.startsWith('mailto:') || href.startsWith('#') || a.target==='_' || a.target==='__blank') return;
      // ignore links that are meant to be downloaded or non-GET (data-no-ajax)
      if(a.hasAttribute('data-no-ajax')) return;
      e.preventDefault();
      loadPage(href, true);
    });

    // Handle inline assign form submissions inside the orders table
    mainContent.addEventListener('submit', async function(e){
      const form2 = e.target;
      if(!form2 || !form2.classList.contains('assign-row-form')) return;
      e.preventDefault();
      const submitBtn = form2.querySelector('button[type="submit"]');
      if(submitBtn) submitBtn.disabled = true;
      try{
        const r = await fetch(form2.action || 'assign_delivery.php', { method: 'POST', body: new FormData(form2), headers: { 'X-Requested-With':'XMLHttpRequest' } });
        const json = await r.json();
        if(json && json.success){
          const row = form2.closest('tr');
          const deliveryCell = row.querySelector('.delivery-cell');
          if(deliveryCell){
            deliveryCell.innerHTML = json.delivery ? `${json.delivery.name} <span class="small muted">(${json.delivery.phone})</span>` : '<em class="muted">Unassigned</em>';
          }
          if(submitBtn) submitBtn.textContent = 'Reassign';
        }else{
          let err = form2.querySelector('.error-msg');
          if(!err){ err = document.createElement('div'); err.className = 'error-msg'; form2.prepend(err); }
          err.textContent = (json && json.message) ? json.message : 'Failed to assign';
        }
      }catch(err){ console.error(err); }
      if(submitBtn) submitBtn.disabled = false;
    });
  }

  // handle back/forward
  window.addEventListener('popstate', function(e){ const url = (e.state && e.state.url) ? e.state.url : location.pathname.split('/').pop(); loadPage(url, false); });

  // animate number counters
  function animateCounts(){
    document.querySelectorAll('.count').forEach(el=>{
      const target = parseFloat(el.getAttribute('data-target')) || 0;
      const start = 0;
      const duration = 800;
      let startTime = null;
      const step = (timestamp)=>{
        if(!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime)/duration,1);
        const value = Math.round(progress * (target-start) + start);
        el.textContent = value.toLocaleString();
        if(progress<1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }

  // search input behaviour: open orders with query
  const searchInput = document.querySelector('.search input');
  if(searchInput){
    searchInput.addEventListener('keydown', function(e){ if(e.key === 'Enter'){ const q = encodeURIComponent(searchInput.value.trim()); loadPage('orders.php?q=' + q); } });
  }

  // initial load: if current page is dashboard.php, include content from dashboard_content.php
  const initial = location.pathname.split('/').pop() || 'dashboard.php';
  // if we are on admin dashboard root use dashboard_content.php
  if(initial === 'dashboard.php' || initial === '' ){
    loadPage('dashboard_content.php', false);
  }

  // close modal on Escape
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape'){ const m = document.getElementById('adminModal'); if(m) m.classList.remove('open'); } });

});