<?php
session_start();
include '../includes/db.php';

// ============================
// CHECK ADMIN ACCESS
// ============================
if (!isset($_SESSION['admin_id'])) {
    die("Access Denied. Please login as admin.");
}

// ============================
// GET ORDER ID
// ============================
$order_id = 0;
if (isset($_GET['oid'])) {
    $order_id = (int)$_GET['oid'];
} elseif (isset($_GET['id'])) {
    $order_id = (int)$_GET['id'];
}

if ($order_id <= 0) {
    die("Invalid Order ID");
}


// ============================
// FETCH ORDER DETAILS
// ============================
$stmt = $conn->prepare("
    SELECT o.*, u.name AS user_name, u.phone AS user_phone
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.user_id
    WHERE o.order_id = ?
");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

// ============================
// FETCH ORDER ITEMS
// ============================
$items = $conn->query("
    SELECT 
        oi.quantity,
        oi.price,
        p.product_name,
        GROUP_CONCAT(pi.image SEPARATOR ',') AS images
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id
    WHERE oi.order_id = $order_id
    GROUP BY oi.product_id, oi.quantity, oi.price, p.product_name
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order #<?= $order_id ?> Details</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f7f7f7;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 900px;
    margin: 40px auto;
    background: #fff;
    padding: 20px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}
h2 {
    margin-bottom: 20px;
    color: #333;
}
.order-info p {
    margin: 5px 0;
    font-size: 15px;
}
.status {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 4px;
    font-weight: bold;
    color: #fff;
}
.status.pending { background: orange; }
.status.delivered { background: green; }
.status.cancelled { background: red; }
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}
th {
    background: #f5f5f5;
}
img {
    max-width: 60px;
    max-height: 60px;
    object-fit: cover;
    border-radius: 6px;
}
.total-row td {
    font-weight: bold;
    background: #fafafa;
}
.back-link {
    display: inline-block;
    margin-top: 20px;
    text-decoration: none;
    color: #555;
    font-weight: bold;
}
.back-link:hover {
    color: #000;
}
</style>
</head>
<body>
<div class="container">
<h2>Order #<?= $order_id ?></h2>

<div class="order-info">
<p><strong>User Name:</strong> <?= htmlspecialchars($order['user_name'] ?? $order['name']); ?></p>
<p><strong>Phone:</strong> <?= htmlspecialchars($order['user_phone'] ?? $order['phone']); ?></p>
<p><strong>Address:</strong> <?= htmlspecialchars($order['address']); ?></p>

<?php
$status = strtolower($order['delivery_status'] ?? 'pending');
?>
<p><strong>Status:</strong> <span class="status <?= $status ?>"><?= ucfirst($status) ?></span></p>
</div>

<h3>Order Items</h3>
<table>
<tr>
    <th>Product</th>
    <th>Image</th>
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Subtotal</th>
</tr>

<?php while($row = $items->fetch_assoc()):
    $image = 'no-image.png';
    if (!empty($row['images'])) {
        $imgArr = explode(',', $row['images']);
        $image = $imgArr[0];
    }
    $subtotal = $row['quantity'] * $row['price'];
?>
<tr>
    <td><?= htmlspecialchars($row['product_name']) ?></td>
    <td><img src="../assets/images/products/<?= htmlspecialchars($image) ?>" width="60" height="60" alt="Product" onerror="this.src='../assets/images/no-image.png'"></td>
    <td><?= (int)$row['quantity'] ?></td>
    <td>₹<?= number_format($row['price'], 2) ?></td>
    <td>₹<?= number_format($subtotal, 2) ?></td>
</tr>
<?php endwhile; ?>

<tr class="total-row">
    <td colspan="4" align="right">Grand Total</td>
    <td>₹<?= number_format($order['total'], 2) ?></td>
</tr>
</table>

<a class="back-link" href="orders.php">← Back to Orders</a>
</div>
</body>
</html>
