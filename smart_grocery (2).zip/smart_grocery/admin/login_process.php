<?php
session_start();
include '../includes/db.php';

$email = $_POST['email'];
$password = $_POST['password'];

$q = $conn->query("SELECT * FROM admin WHERE email='$email' AND password='$password'");

if ($q->num_rows == 1) {
    $admin = $q->fetch_assoc();

    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_name'] = $admin['name'];

    header("Location: dashboard.php");
    exit;
} else {
    header("Location: login.php?error=1");
    exit;
}
