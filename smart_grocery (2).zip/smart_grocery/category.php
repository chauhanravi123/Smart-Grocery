<?php
session_start();
include 'includes/db.php';
include 'includes/header.php';
/* Init cart */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* UPDATE CART WITH + / - */
if (isset($_POST['qty_action'])) {
    $pid = (int)$_POST['product_id'];

    if ($_POST['qty_action'] === 'plus') {
        $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + 1;
    }

    if ($_POST['qty_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }
}

/* Get all categories */
$categoriesRes = $conn->query("SELECT * FROM categories WHERE status=1 ORDER BY category_name ASC");

/* Get selected category if slug exists */
$slug = $_GET['slug'] ?? '';
$category = null;
$products = [];

if ($slug != '') {
    $slug_safe = $conn->real_escape_string($slug);
    $catRes = $conn->query("SELECT * FROM categories WHERE slug='$slug_safe' AND status=1");
    $category = $catRes->fetch_assoc();

    if ($category) {
        $productsRes = $conn->query("SELECT p.*, GROUP_CONCAT(pi.image SEPARATOR ',') AS images FROM products p LEFT JOIN product_images pi ON p.product_id = pi.product_id WHERE p.category_id=" . (int)$category['category_id'] . " GROUP BY p.product_id");
        $products = $productsRes->fetch_all(MYSQLI_ASSOC);
    }
}
?>

<link rel="stylesheet" href="assets/css/products.css">
<style>
.category-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}
.category-list a {
    padding: 10px 15px;
    background-color: #eee;
    border-radius: 5px;
    text-decoration: none;
    color: #333;
}
.category-list a:hover {
    background-color: #ccc;
}
.product-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}
.product-card {
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 5px;
    width: 200px;
}
.qty-form {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 5px;
}
.qty-form button {
    width: 32px;
    height: 32px;
    font-size: 20px;
    border-radius: 5px;
    cursor: pointer;
}
.qty {
    min-width: 20px;
    text-align: center;
    font-weight: bold;
}
</style>

<h2>All Categories</h2>
<div class="category-list">
    <?php while ($cat = $categoriesRes->fetch_assoc()) { ?>
        <a href="category.php?slug=<?= htmlspecialchars($cat['slug']); ?>">
            <?= htmlspecialchars($cat['category_name']); ?>
            <!--<?= htmlspecialchars($cat['category_image']); ?>-->
        </a>
    <?php } ?>
</div>

<?php if ($category): ?>
    <h2 class="page-title"><?= htmlspecialchars($category['category_name']); ?></h2>
    <?php if (!empty($products)): ?>
    <div class="product-grid">
        <?php foreach ($products as $row) { 
            // Get first image from product_images
            $firstImage = 'no-image.png';
            if (!empty($row['images'])) {
                $images = explode(',', $row['images']);
                $firstImage = $images[0];
            }
        ?>
            <div class="product-card">
                <img src="assets/images/products/<?= htmlspecialchars($firstImage); ?>" alt="<?= htmlspecialchars($row['product_name']); ?>" width="180" onerror="this.src='assets/images/no-image.png'">
                <h4><?= htmlspecialchars($row['product_name']); ?></h4>
                <p>₹<?= htmlspecialchars($row['price']); ?></p>

                <?php $qty = $_SESSION['cart'][$row['product_id']] ?? 0; ?>
                <form method="post" class="qty-form">
                    <input type="hidden" name="product_id" value="<?= $row['product_id']; ?>">
                    <button type="submit" name="qty_action" value="minus">−</button>
                    <span class="qty"><?= $qty ?></span>
                    <button type="submit" name="qty_action" value="plus">+</button>
                </form>
            </div>
        <?php } ?>
    </div>
    <?php else: ?>
        <p>No products found in this category.</p>
    <?php endif; ?>
<?php else: ?>
    <p>Please select a category to see products.</p>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
