<?php
session_start();
include 'includes/db.php';

/* CART INIT */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* ADD / REMOVE CART */
if (isset($_POST['cart_action'])) {
    $pid = (int)$_POST['product_id'];

    if ($_POST['cart_action'] === 'plus') {
        $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + 1;
    }

    if ($_POST['cart_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }
}

/* PRODUCT FETCH */
$id = (int)($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM products WHERE product_id = $id");
$product = $res->fetch_assoc();

if (!$product) {
    die("Product not found");
}

/* Fetch product images */
$imagesRes = $conn->query("SELECT image FROM products WHERE product_id = $id");
$images = $imagesRes ? $imagesRes->fetch_all(MYSQLI_ASSOC) : [];

$qty = $_SESSION['cart'][$id] ?? 0;

/* Calculate discount & savings */
$mrp = (float)($product['mrp'] ?? 0);
$price = (float)($product['price'] ?? 0);
$discount = 0;
$saveAmount = 0;
if ($mrp > 0 && $mrp > $price) {
    $discount = round((($mrp - $price) / $mrp) * 100);
    $saveAmount = round($mrp - $price, 2);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title><?= htmlspecialchars($product['product_name']); ?> | Smart Grocery</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --primary: #0d6efd;
            --accent: #28a745;
            --danger: #d9534f;
            --muted: #6c757d;
            --bg: #f8f9fa;
            --radius: 10px;
        }

        * { box-sizing: border-box; }
        body { font-family: system-ui, -apple-system, sans-serif; margin: 0; background: var(--bg); }

        /* Navbar */
        .navbar {
            background: var(--primary);
            color: #fff;
            padding: 14px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-left: 16px;
            font-weight: 500;
            transition: opacity 0.2s;
        }

        .navbar a:hover {
            opacity: 0.9;
        }

        .cart-count {
            background: #dc3545;
            padding: 3px 7px;
            border-radius: 50%;
            font-size: 12px;
            font-weight: 700;
        }

        /* Container */
        .container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 30px 16px;
        }

        /* Product detail grid */
        .product-detail {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            background: #fff;
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: 0 6px 20px rgba(0,0,0,0.05);
        }

        /* Gallery section */
        .gallery-section {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .main-image {
            width: 100%;
            max-width: 400px;
            height: 400px;
            object-fit: contain;
            border-radius: var(--radius);
            background: #fafafa;
            border: 1px solid #e9ecef;
        }

        .gallery-thumbnails {
            display: flex;
            gap: 8px;
            overflow-x: auto;
        }

        .gallery-thumbnails img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 6px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.2s;
        }

        .gallery-thumbnails img:hover,
        .gallery-thumbnails img.active {
            border-color: var(--primary);
        }

        /* Product info section */
        .product-info h1 {
            margin: 0 0 12px 0;
            font-size: 1.8rem;
            color: #222;
        }

        .product-rating {
            color: var(--muted);
            margin-bottom: 16px;
            font-size: 0.95rem;
        }

        /* Pricing */
        .pricing {
            margin: 20px 0;
            padding: 16px;
            background: #fef5f5;
            border-radius: 8px;
        }

        .price-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .price-label {
            color: var(--muted);
            font-size: 0.9rem;
        }

        .mrp {
            color: #999;
            text-decoration: line-through;
            font-size: 1rem;
        }

        .price {
            font-size: 1.6rem;
            font-weight: 700;
            color: #111;
        }

        .discount-badge {
            background: var(--danger);
            color: #fff;
            padding: 6px 12px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 0.9rem;
            display: inline-block;
        }

        .savings {
            color: var(--accent);
            font-weight: 600;
            font-size: 0.95rem;
            margin-top: 8px;
        }

        /* Stock status */
        .stock-status {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 16px 0;
            font-weight: 600;
        }

        .stock-status.in-stock {
            color: var(--accent);
        }

        .stock-status.out-stock {
            color: var(--danger);
        }

        .stock-indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }

        .stock-status.in-stock .stock-indicator {
            background: var(--accent);
        }

        .stock-status.out-stock .stock-indicator {
            background: var(--danger);
        }

        /* Description */
        .short-description {
            color: #666;
            font-size: 0.95rem;
            margin: 16px 0;
            line-height: 1.5;
        }

        .full-description {
            margin: 24px 0;
            color: #555;
            line-height: 1.7;
        }

        .full-description h3 {
            margin-top: 20px;
            color: #222;
        }

        /* Cart controls */
        .cart-controls {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 24px 0;
        }

        .qty-input {
            display: flex;
            align-items: center;
            border: 1px solid #ddd;
            border-radius: 6px;
            overflow: hidden;
        }

        .qty-input button {
            background: #f0f0f0;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-weight: 700;
            transition: background 0.2s;
        }

        .qty-input button:hover {
            background: #e0e0e0;
        }

        .qty-input span {
            padding: 8px 16px;
            min-width: 40px;
            text-align: center;
            font-weight: 600;
        }

        .add-cart-btn {
            background: var(--accent);
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }

        .add-cart-btn:hover {
            background: #228832;
        }

        .add-cart-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        /* Back link */
        .back-link {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            margin-top: 20px;
            display: inline-block;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .product-detail {
                grid-template-columns: 1fr;
                gap: 24px;
                padding: 20px;
            }

            .product-info h1 {
                font-size: 1.4rem;
            }

            .price {
                font-size: 1.4rem;
            }

            .main-image {
                max-width: 100%;
                height: auto;
            }
        }

        /* Accessibility */
        button:focus, a:focus {
            outline: 3px solid rgba(13, 110, 253, 0.15);
            outline-offset: 2px;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <div>
            <a href="index.php" style="margin-left:0;"><b>🛒 SmartGrocery</b></a>
        </div>
        <div>
            <a href="products.php">Products</a>
            <a href="index.php">Home</a>
            <a href="cart.php">
                Cart <span class="cart-count"><?= array_sum($_SESSION['cart'] ?? []); ?></span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user/logout.php">Logout</a>
            <?php } else { ?>
                <a href="user/login.php">Login</a>
            <?php } ?>
        </div>
    </div>

    <div class="container">

        <div class="product-detail">
            <!-- Gallery Section -->
            <div class="gallery-section">
                <img id="mainImage" 
                     src="assets/images/products<?= htmlspecialchars($images[0]['image'] ?? 'no-image.png'); ?>" 
                     alt="<?= htmlspecialchars($product['product_name']); ?>"
                     class="main-image">

                <?php if (!empty($images)): ?>
                    <div class="gallery-thumbnails">
                        <?php foreach ($images as $idx => $img) { ?>
                            <img src="assets/images/products<?= htmlspecialchars($img['image']); ?>" 
                                 alt="Product image <?= $idx + 1 ?>"
                                 class="<?= $idx === 0 ? 'active' : '' ?>"
                                 onclick="document.getElementById('mainImage').src='assets/images/products<?= htmlspecialchars($img['image']); ?>'; document.querySelectorAll('.gallery-thumbnails img').forEach(e => e.classList.remove('active')); this.classList.add('active');">
                        <?php } ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Product Info Section -->
            <div class="product-info">
                <h1><?= htmlspecialchars($product['product_name']); ?></h1>

                <div class="product-rating">
                    Sold by <strong>Smart Grocery</strong> ✓
                </div>

                <!-- Pricing -->
                <div class="pricing">
                    <div class="price-row">
                        <span class="price">₹<?= number_format($price, 2) ?></span>
                        <?php if ($discount > 0): ?>
                            <span class="discount-badge">-<?= $discount ?>%</span>
                        <?php endif; ?>
                    </div>

                    <?php if ($mrp > 0 && $mrp > $price): ?>
                        <div class="price-row">
                            <span class="price-label">MRP:</span>
                            <span class="mrp">₹<?= number_format($mrp, 2) ?></span>
                        </div>
                        <div class="savings">
                            You save ₹<?= number_format($saveAmount, 2) ?> (<?= $discount ?>% off)
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Stock Status -->
                <?php if ($product['stock_qty'] > 0): ?>
                    <div class="stock-status in-stock">
                        <span class="stock-indicator"></span>
                        In Stock (<?= (int)$product['stock_qty'] ?> available)
                    </div>
                <?php else: ?>
                    <div class="stock-status out-stock">
                        <span class="stock-indicator"></span>
                        Out of Stock
                    </div>
                <?php endif; ?>

                <!-- Short Description -->
                <?php if (!empty($product['short_description'])): ?>
                    <div class="short-description">
                        <?= htmlspecialchars($product['short_description']); ?>
                    </div>
                <?php endif; ?>

                <!-- Cart Controls -->
                <?php if ($product['stock_qty'] > 0): ?>
                    <form method="post" style="margin:0;">
                        <div class="cart-controls">
                            <div class="qty-input">
                                <button type="submit" name="cart_action" value="minus">−</button>
                                <span><?= $qty ?></span>
                                <button type="submit" name="cart_action" value="plus">+</button>
                            </div>
                            <input type="hidden" name="product_id" value="<?= $product['product_id']; ?>">
                            <button type="submit" class="add-cart-btn" name="add_cart" value="1">
                                <?= $qty > 0 ? 'Update Cart' : 'Add to Cart' ?>
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <button class="add-cart-btn" disabled>Out of Stock</button>
                <?php endif; ?>

                <!-- Full Description -->
                <div class="full-description">
                    <h3>Product Details</h3>
                    <?= nl2br(htmlspecialchars($product['description'])); ?>
                </div>

                <a href="products.php" class="back-link">← Back to Products</a>
            </div>
        </div>

    </div>

</body>
                    <script>
    function updateCart(productId, action, stockQty = 0) {

        const qtyEl = document.getElementById('qty-' + productId);
        const currentQty = parseInt(qtyEl.textContent);

        if (action === 'plus') {

            const allowed = Math.min(6, stockQty);

            if (currentQty >= allowed) {
                alert("Only " + allowed + " items allowed.");
                return;
            }
        }

        fetch('products.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `product_id=${productId}&cart_action=${action}`
            })
            .then(response => response.json())
            .then(data => {
                if (data && data.success) {
                    const qtyEl = document.getElementById('qty-' + productId);
                    if (qtyEl) qtyEl.textContent = data.qty;
                    const cartEl = document.getElementById('cart-count');
                    if (cartEl) cartEl.textContent = data.cartCount;
                } else if (data.message) {
                    // Show the limit message from server
                    alert(data.message);
                } else {
                    location.reload();
                }
            })
            .catch(() => location.reload());
    }
</script>
</html>