-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 29, 2026 at 06:19 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'jay', 'jay@gmail.com', 'Jay@123');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `slug`, `image`, `status`, `created_at`) VALUES
(1, 'Cold drinks & soft drinks', 'cold-drinks-soft-drinks', '1765991585_cold-drinks.jpg', 1, '2025-12-17 17:13:05'),
(3, 'Biscuits & Cookies', 'biscuits-cookies', '1765992237_biscuits-cookies.jpg', 1, '2025-12-17 17:23:57'),
(4, 'Chips & Namkeens', 'chips-namkeens', '1766028778_694375ea5df50.jpg', 1, '2025-12-17 17:24:50'),
(5, 'Chocolates & Candies', 'chocolates-candies', '1769616560_697a34b01f86d.jpg', 1, '2025-12-17 17:25:41'),
(6, 'Indian Sweets', 'Indian-Sweets', '1769616526_697a348ee9f91.jpg', 1, '2025-12-17 17:26:19');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'jaydip', 'jaydip@gmail.com', 'delivery related', 'i order with smart_grocery when i get my items', '2025-12-29 05:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_boys`
--

CREATE TABLE `delivery_boys` (
  `delivery_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery_boys`
--

INSERT INTO `delivery_boys` (`delivery_id`, `name`, `phone`, `email`, `password`, `status`, `created_at`) VALUES
(1, 'Ravi Kanzariya', '9724682789', 'Ravi@gmail.com', '$2y$10$m04X0df4bfJJQ91wYggjhO9yEdT/UWFu5FH8kibzW.m22bwCmsHj6', 1, '2026-01-07 11:42:31'),
(2, 'Divyang', '9824323465', 'divyang@gmail.com', '$2y$10$Ah08DWkobgBpj0WHZlaNFeysXkClvekc9stYzaN6ORRe1aZHKlysi', 1, '2026-01-07 12:27:32');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `total` decimal(65,2) DEFAULT NULL,
  `collected_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `collected_at` datetime DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `order_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','processing','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `address_id` int DEFAULT NULL,
  `delivery_id` int DEFAULT NULL,
  `delivery_status` enum('Pending','Assigned','Out for Pickup','Out for Delivery','Delivered','Undelivered') DEFAULT 'Pending',
  `delivery_otp` varchar(6) DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `name`, `phone`, `address`, `total`, `collected_amount`, `collected_at`, `payment_method`, `order_date`, `status`, `address_id`, `delivery_id`, `delivery_status`, `delivery_otp`, `delivered_at`) VALUES
(1, NULL, 'jaydip', '9824536561', 'Astron chowk,rajkot', 240.00, 240.00, '2026-01-11 10:26:41', NULL, '2025-12-21 04:23:27', 'delivered', NULL, 1, 'Delivered', NULL, '2026-01-11 10:26:41'),
(2, NULL, 'jaydip', '9824536561', 'Astron chowk,rajkot', 240.00, 0.00, NULL, NULL, '2025-12-21 04:29:14', 'delivered', NULL, NULL, 'Assigned', NULL, NULL),
(3, NULL, 'jaydip', '1234567890', 'botad', 120.00, 0.00, NULL, NULL, '2025-12-22 05:16:40', 'delivered', NULL, NULL, 'Assigned', NULL, NULL),
(4, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 40.00, 0.00, NULL, NULL, '2025-12-23 03:53:34', 'delivered', NULL, NULL, 'Assigned', NULL, NULL),
(5, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 0.00, 0.00, NULL, NULL, '2025-12-23 04:00:44', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL),
(6, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 40.00, 0.00, NULL, NULL, '2025-12-23 04:08:14', 'delivered', NULL, NULL, 'Assigned', NULL, NULL),
(7, NULL, 'Ashish Parmar', '9157230857', 'bapa sitaram chowk, raiya road, rajkot', 0.00, 0.00, NULL, NULL, '2025-12-23 04:13:10', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL),
(8, NULL, 'ravi', '1234567889', 'rajkot', 12630.00, 0.00, NULL, NULL, '2025-12-23 05:12:16', 'pending', NULL, NULL, 'Assigned', NULL, NULL),
(9, NULL, 'jaydip', '1234567890', 'botad', 40.00, 0.00, NULL, NULL, '2025-12-29 05:44:27', 'delivered', NULL, 2, 'Delivered', NULL, '2026-01-08 17:47:16'),
(10, NULL, 'jay', '9824234526', 'near k.k.v hall, kalavad road, rajkot.', 1136.00, 0.00, NULL, NULL, '2025-12-30 04:08:19', 'pending', NULL, NULL, 'Assigned', NULL, NULL),
(11, NULL, 'jay', '9824234526', 'Bapa sitaram chowk, Raiya road ,Rajkot.', 10.00, 0.00, NULL, NULL, '2025-12-30 04:17:03', 'pending', NULL, NULL, 'Assigned', NULL, NULL),
(12, 3, 'jay', '9824234526', 'Dhakaniya Road,Botad ,Gujrat', 40.00, 0.00, NULL, NULL, '2025-12-30 04:25:18', 'pending', NULL, NULL, 'Assigned', NULL, NULL),
(13, 5, 'Ashish', '9157230155', '', 312.00, 0.00, NULL, NULL, '2026-01-06 06:04:52', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL),
(14, 3, 'Ashish', '9157230155', '', 10.00, 0.00, NULL, NULL, '2026-01-06 06:27:34', 'cancelled', NULL, NULL, 'Assigned', NULL, NULL),
(15, 3, 'Ashish', '9157230155', 'Hanuman Madhi, Raiya Road, Rajkot                                , Rajkot - 360007', 150.00, 0.00, NULL, NULL, '2026-01-06 06:40:21', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-07 18:23:12'),
(16, 3, 'Ashish Parmar', '9157230156', 'Hanuman Madhi, Raiya Road, Rajkot                                , Rajkot - 360007', 312.00, 312.00, '2026-01-11 10:41:06', '0', '2026-01-06 06:42:04', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-11 10:41:06'),
(17, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot, Rajkot - 360007', 190.00, 0.00, NULL, 'Cash', '2026-01-11 05:07:58', 'pending', NULL, 1, 'Out for Pickup', NULL, NULL),
(18, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 80.00, 80.00, '2026-01-27 22:02:51', '0', '2026-01-27 06:00:32', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-27 22:02:51'),
(19, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 346.00, 346.00, '2026-01-27 22:03:31', '0', '2026-01-27 16:25:30', 'pending', NULL, 1, 'Delivered', NULL, '2026-01-27 22:03:31'),
(20, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot, Rajkot - 360002', 90.00, 90.00, '2026-01-28 22:02:08', '0', '2026-01-28 16:00:32', 'pending', NULL, 2, 'Delivered', NULL, '2026-01-28 22:02:08');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `image`, `price`) VALUES
(1, 1, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(2, 1, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(3, 1, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(4, 2, 5, 3, '1766288607_69476cdfd88b6.webp', 40.00),
(5, 2, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(6, 2, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(7, 3, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(8, 3, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(9, 4, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(10, 6, 7, 1, '1766288857_69476dd90acd6.webp', 40.00),
(11, 8, 1, 113, '1766033094_694386c65fc7f.webp', 110.00),
(12, 8, 6, 5, '1766288712_69476d489e474.webp', 40.00),
(13, 9, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(14, 10, 2, 11, '1766056873_6943e3a9cf140.webp', 78.00),
(15, 10, 3, 1, '1766057140_6943e4b4e6bc3.webp', 78.00),
(16, 10, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(17, 10, 7, 4, '1766288857_69476dd90acd6.webp', 40.00),
(18, 11, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(19, 12, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(20, 13, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(21, 14, 4, 1, '1766057257_6943e529a6625.webp', 10.00),
(22, 15, 4, 3, '1766057257_6943e529a6625.webp', 10.00),
(23, 15, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(24, 15, 6, 2, '1766288712_69476d489e474.webp', 40.00),
(25, 16, 3, 4, '1766057140_6943e4b4e6bc3.webp', 78.00),
(26, 17, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(27, 17, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(28, 17, 6, 1, '1766288712_69476d489e474.webp', 40.00),
(29, 18, 6, 1, '1768109318_products1766288712_69476d489e474.webp', 40.00),
(30, 18, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(31, 19, 6, 1, '1769493812_products1766288712_69476d489e474.webp', 40.00),
(32, 19, 3, 2, '1766057140_6943e4b4e6bc3.webp', 78.00),
(33, 19, 5, 1, '1766288607_69476cdfd88b6.webp', 40.00),
(34, 19, 1, 1, '1766033094_694386c65fc7f.webp', 110.00),
(35, 20, 10, 2, '', 45.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_updates`
--

CREATE TABLE `order_updates` (
  `id` int NOT NULL,
  `order_id` int NOT NULL,
  `delivery_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collected_amount` decimal(10,2) DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_updates`
--

INSERT INTO `order_updates` (`id`, `order_id`, `delivery_status`, `payment_method`, `collected_amount`, `created_at`) VALUES
(1, 17, 'Out for Pickup', 'Cash', 190.00, '2026-01-11 10:51:59'),
(2, 18, 'Assigned', 'Cash', 80.00, '2026-01-27 22:02:31'),
(3, 18, 'Delivered', 'Cash', 80.00, '2026-01-27 22:02:51'),
(4, 19, 'Delivered', 'Cash', 346.00, '2026-01-27 22:03:31'),
(5, 20, 'Out for Pickup', 'Cash', 90.00, '2026-01-28 22:01:48'),
(6, 20, 'Delivered', 'Cash', 90.00, '2026-01-28 22:02:08');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `mrp` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock` int DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `status` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `category_id`, `product_name`, `short_description`, `price`, `mrp`, `stock`, `image`, `description`, `status`) VALUES
(1, 3, 'Parle-g gold Biscuits-1kg', NULL, 110.00, 0.00, 101, '1766033094_694386c65fc7f.webp', 'General Information\r\nBrand	Parle-G\r\nManufacturer	Parle Products Pvt. Ltd.\r\nManufacturer Address	\r\nAnand Food Products\r\n16-1-486 Saidabad, Haderabad, 500059\r\n\r\nManufacturer Email	cs@parle.biz\r\nManufacturer Website	www.parleproducts.com\r\nSold By	Reliance Retail\r\nJioMart Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	56.25 g\r\nProduct Type	Glucose Biscuits\r\nUsage Details\r\nFood Preference	Vegetarian\r\nAllergens Included	Wheat\r\nProduct Specifications\r\nProduct Type	Glucose & Milk Biscuits\r\nItem Dimensions\r\nHeight	260 mm\r\nLength	40 mm\r\nWidth	210 mm\r\nNet Quantity	1 kg', 1),
(3, 3, 'Parle-g original gluose biscuits', NULL, 78.00, 0.00, 51, '1766057140_6943e4b4e6bc3.webp', 'Parle-G Original Glucose Biscuits are filled with the goodness of milk and wheat. Parle-G has been a source of all-round nourishment for growing kids and it has also been an all-time favourite choice for years. Whatever be the occasion, it has always been around to fight the hunger pangs. So, go ahead and get your pack of Parle-G Biscuits online now!\r\nDisclaimer:\r\nDespite our attempts to provide you with the most accurate information possible, the actual packaging, ingredients and colour of the product may sometimes vary. Please read the label, directions and warnings carefully before use.\r\n\r\nProduct Information\r\nGeneral Information\r\nBrand	Parle\r\nManufacturer	Parle Products Pvt. Ltd.\r\nManufacturer Address	\r\nShivshakti Processed Foods\r\n54,Village State, Vadgaon, Maharashtra -412106.\r\n\r\nManufacturer Email	cs@parle.biz\r\nManufacturer Website	www.parleproducts.com\r\nSold By	Reliance Retail\r\nJioMart Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	250 g\r\nUsage Details\r\nProduct Type	Glucose Biscuits\r\nProduct Specifications\r\nProduct Type	Glucose & Milk Biscuits\r\nItem Dimensions\r\nHeight	300 mm\r\nLength	300 mm\r\nWidth	40 mm\r\nNet Quantity	800 g', 1),
(4, 3, 'Oreo cream Biscuits', NULL, 10.00, 0.00, 51, '1766057257_6943e529a6625.webp', 'Food Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	41.75 g\r\nProduct Type	Cream Biscuits\r\nUsage Details\r\nNutrient Content	Wheat\r\nProduct Specifications\r\nProduct Type	Cream Biscuits & Wafers\r\nItem Dimensions\r\nHeight	45 mm\r\nLength	45 mm\r\nWidth	85 mm\r\nNet Quantity	1 N', 1),
(5, 1, 'Thums-up 750ml', NULL, 40.00, 0.00, 101, '1766288607_69476cdfd88b6.webp', 'Delight your guests with Thums Up. It is the perfect drink for any weather. Gatherings are incomplete without it. One glass is never enough! So go ahead buy this product online today.\r\nDisclaimer:\r\nDespite our attempts to provide you with the most accurate information possible, the actual packaging, ingredients and colour of the product may sometimes vary. Please read the label, directions and warnings carefully before use.\r\n\r\nProduct Information\r\nGeneral Information\r\nBrand	Thums Up\r\nManufacturer	Coca-Cola India Pvt. Ltd.\r\nManufacturer Address	\r\nHindustan Coca Cola Beverages Pvt Ltd\r\nPlot No 18, Bidadi Industrial Area, Bidadi Hobli, Bangalore Rural, Karnataka - 562109\r\n\r\nManufacturer Email	indiahelpline@coca-cola.com', 1),
(6, 1, 'Sprite 750ml', NULL, 40.00, 0.00, 101, '1769493812_products1766288712_69476d489e474.webp', 'Product Information\r\nGeneral Information\r\nBrand	Sprite\r\nManufacturer	Coca-Cola India Pvt. Ltd.\r\nManufacturer Address	\r\nHindustan Coca Cola Beverages Pvt Ltd\r\nPlot No 18, Bidadi Industrial Area, Bidadi Hobli, Bangalore Rural, Karnataka - 562109\r\n\r\nCoca Cola Pvt Ltd\r\nGurgaon, Haryana, India - 122008\r\n\r\nManufacturer Email	indiahelpline@coca-cola.com\r\nManufacturer Website	www.coca-cola.com\r\nSold By	Reliance Retail\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nProduct Details\r\nNet Quantity	750 ml\r\nProduct Type	Other Drinks\r\nUsage Details\r\nFood Preference	Vegetarian\r\nPack Of	1\r\nProduct Specifications\r\nProduct Type	Cold Drinks\r\nItem Dimensions\r\nHeight	200 mm\r\nLength	75 mm\r\nWidth	75 mm\r\nNet Quantity	1 N', 1),
(10, 5, ' Cadbury Dairy Milk Fruit & Nut Chocolate Bar 36 g ', 'Product Type	Chocolates Item Dimensions Height	96 mm Length	47 mm Width	10 mm Net Quantity	36 g', 45.00, 49.00, 50, NULL, 'General Information\r\nBrand	Cadbury\r\nManufacturer	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	\r\nMondelez India Foods Pvt. Ltd\r\nMondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\n\r\nSold By	Smart Grocery\r\nJioMart Customer Care Phone	1800 890 1222\r\nFood Type	Food Type\r\nCountry of Origin	India\r\nOrigin Country	India\r\nManufacturer Name	Mondelez India Foods Pvt. Ltd\r\nManufacturer Address	Mondelez India Foods Pvt. Ltd., 6055, Central Expressway, Sector-25, Sricity, Chittoor District -517 544, Andhra Pradesh.\r\nProduct Details\r\nNet Quantity	80 g\r\nUsage Details\r\nProduct Type	Other Chocolates', 1),
(13, 4, 'Balaji wafers Farali Chevdo 235 g', 'Balaji wafers Farali Chevdo 235 g', 42.00, 45.00, 50, NULL, 'Farali Chevdo 235 g.', 1),
(14, 4, 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g', 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g', 38.00, 40.00, 50, '1769528114_balaji-simply-salted-potato-wafers-135-g-product-images-o490025528-p490025528-0-202411131812.webp', 'Balaji Wafers Crunchem Simply Salted Potato Wafers 135 g\r\n', 1),
(16, 6, 'Haldiram Mini Kaju Katli 250gm', 'Haldiram Mini Kaju Katli 250gm', 249.00, 300.00, 25, NULL, 'Haldiram Mini Kaju Katli 250gm', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `image_id` int NOT NULL,
  `product_id` int NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`image_id`, `product_id`, `image`, `created_at`) VALUES
(1, 16, '1769529049_6978ded90c84b.webp', '2026-01-27 15:50:49'),
(3, 14, '1769530680_6978e53868232.webp', '2026-01-27 16:18:00'),
(4, 13, '1769530701_6978e54d39c17.webp', '2026-01-27 16:18:21'),
(5, 10, '1769530715_6978e55b52951.jpg', '2026-01-27 16:18:35'),
(6, 6, '1769530728_6978e568b9171.webp', '2026-01-27 16:18:48'),
(7, 5, '1769530741_6978e575b6ace.webp', '2026-01-27 16:19:01'),
(8, 4, '1769530757_6978e5850dadb.webp', '2026-01-27 16:19:17'),
(9, 3, '1769530775_6978e597bba20.webp', '2026-01-27 16:19:35'),
(10, 1, '1769530805_6978e5b558012.webp', '2026-01-27 16:20:05'),
(11, 1, '1769616610_697a34e2c224e.webp', '2026-01-28 16:10:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `phone`, `email`, `password`, `role`, `address`, `city`, `pincode`) VALUES
(1, 'Bhavik', '8975234526', 'bhavik@gmail.com', '$2y$10$WYWKzjMgPrqZfgAEmtdAoOdTem5V0M8XoNY0THRX.ii5tSMzda.MC', 'user', NULL, NULL, NULL),
(2, 'jaydip', '9823467542', 'jaydip@gmail.com', '$2y$10$UHOe/p/oN7Gc2lGk6bbwYOs35Q4TYbgBCeNR.lr/Tj3wnhh4FHzfG', 'user', 'mavdi chokdi, 150-feet ring road, rajkot', 'rajkot', '360005'),
(3, 'jay', '1234567889', 'jay@gmail.com', '$2y$10$euy33MUKamItXLHkxzlvjOjA/ZkuvQY0gHm6SkgUXngZEN3S91lBC', 'user', 'Hanuman Madhi, Raiya Road, Rajkot', 'Rajkot', '360007'),
(4, 'chetan', '9878234569', 'chetan@gmail.com', '$2y$10$Qgm/FsLKpYYjjVQKrzPIl.JrrELzfjkJWJ/bt1jKUDbsoNR8slvIa', 'user', NULL, NULL, NULL),
(5, 'Ashish', '9157230155', 'Ashish@gmail.com', '$2y$10$NoUdHQFAIj1w/wGKVHuH5e9sg9z4JwlXwADUBNs8gB0yHhvfnnBjS', 'user', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `address_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pincode` varchar(10) DEFAULT NULL,
  `is_default` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`address_id`, `user_id`, `name`, `phone`, `address`, `city`, `pincode`, `is_default`, `created_at`) VALUES
(1, 5, 'Ashish Parmar', '09157230156', 'Hanuman Madhi, raiya road, rajkot', 'Rajkot', '360007', 0, '2026-01-06 06:03:00'),
(2, 3, 'Ashish Parmar', '9157230156', 'Hanuman Madhi, Raiya Road, Rajkot                                ', 'Rajkot', '360007', 0, '2026-01-06 06:39:43'),
(3, 2, 'Jaydip Parmar', '7019693154', 'trikon baug, Dhebar road, rajkot', 'Rajkot', '360002', 1, '2026-01-06 11:15:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `fk_orders_users` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_updates`
--
ALTER TABLE `order_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `fk_products_category` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`address_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery_boys`
--
ALTER TABLE `delivery_boys`
  MODIFY `delivery_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `order_updates`
--
ALTER TABLE `order_updates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `image_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `address_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_orders_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
