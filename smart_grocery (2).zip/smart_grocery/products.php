<?php
session_start();                // ✅ MUST BE FIRST
include 'includes/db.php';
/* CART INIT */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* ADD / REMOVE CART */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_action'])) {

    $pid = (int)$_POST['product_id'];
    $max_limit = 6; // Set your limit here
    $error_message = '';

    if ($_POST['cart_action'] === 'plus') {
        $current_qty = $_SESSION['cart'][$pid] ?? 0;

        if ($current_qty < $max_limit) {
            $_SESSION['cart'][$pid] = $current_qty + 1;
        } else {
            $error_message = "Maximum limit of $max_limit reached for this item.";
        }
    }

    if ($_POST['cart_action'] === 'minus') {
        if (isset($_SESSION['cart'][$pid])) {
            $_SESSION['cart'][$pid]--;
            if ($_SESSION['cart'][$pid] <= 0) {
                unset($_SESSION['cart'][$pid]);
            }
        }
    }

    // If the request is AJAX, return JSON
    $cartCount = array_sum($_SESSION['cart'] ?? []);
    $qty = $_SESSION['cart'][$pid] ?? 0;

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => ($error_message === ''),
            'qty' => $qty,
            'cartCount' => $cartCount,
            'message' => $error_message
        ]);
        exit;
    }
}
// Per-product price/discount will be calculated inside the products loop.


/* 🔹 SEARCH & CATEGORY FILTER */
$search = $_GET['search'] ?? '';
$cat = $_GET['category'] ?? '';

$where = "WHERE 1";
if ($search !== '') {
    $search_safe = $conn->real_escape_string($search);
    $where .= " AND product_name LIKE '%$search_safe%'";
}
if ($cat !== '') {
    $cat_safe = (int)$cat;
    $where .= " AND category_id = $cat_safe";
}

/* 🔹 FETCH PRODUCTS */
$products = $conn->query("SELECT p.*, GROUP_CONCAT(pi.image SEPARATOR ',') AS images FROM products p LEFT JOIN product_images pi ON p.product_id = pi.product_id $where GROUP BY p.product_id");

/* 🔹 FETCH CATEGORIES */
$categories = $conn->query("SELECT * FROM categories");

/*cart count*/
$cartCount = array_sum($_SESSION['cart'] ?? []);


if (!empty($_SESSION['cart'])) {
    $cartCount = array_sum($_SESSION['cart']);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Products</title>
    <style>
        body {
            font-family: Arial;
            margin: 0;
        }

        .navbar {
            background: #0d6efd;
            color: #fff;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            margin-right: 15px;
        }

        .cart-count {
            background: red;
            padding: 2px 6px;
            border-radius: 50%;
            font-size: 12px;
        }

        .container {
            padding: 20px;
        }

        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }

        .card {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        button {
            padding: 6px 12px;
            cursor: pointer;
        }

        .search-box {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        .discount-badge {
            background: #28a745;
            color: #fff;
            padding: 6px 8px;
            border-radius: 6px;
            font-weight: 700;
            position: absolute;
            top: 10px;
            left: 10px;
        }

        .mrp {
            color: #888;
            font-size: 0.95rem;
            margin-top: 6px;
        }

        .price {
            font-size: 1.15rem;
            font-weight: 700;
            color: #111;
            margin-top: 6px;
        }

        .short-desc {
            color: #666;
            font-size: 0.95rem;
            margin-top: 8px;
        }
    </style>
</head>

<body>
    <!-- 🔹 NAVBAR -->
    <div class="navbar">
        <div>
            <a href="products.php"><b>🛒 SmartGrocery</b></a>
        </div>
        <div>
            <a href="products.php">Menu</a>
            <a href="index.php">Home</a>
            <a href="cart.php">
                Cart <span class="cart-count" id="cart-count"><?= $cartCount ?></span>
            </a>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <a href="user/logout.php">Logout</a>
            <?php } else { ?>
                <a href="../user/login.php">Login</a>
            <?php } ?>
        </div>
    </div>
    <div class="container">
        <!-- 🔹 SEARCH + FILTER -->
        <form method="get" class="search-box">
            <input type="text" name="search" placeholder="Search product..." value="<?= htmlspecialchars($search) ?>">
            <select name="category">
                <option value="">All Categories</option>
                <?php while ($c = $categories->fetch_assoc()) { ?>
                    <option value="<?= $c['category_id']; ?>" <?= $cat == $c['category_id'] ? 'selected' : '' ?>>
                        <?= $c['category_name']; ?>
                    </option>
                <?php } ?>
            </select>
            <button>Search</button>
        </form>

        <!-- 🔹 PRODUCT GRID -->
        <div class="products">

            <?php if ($products && $products->num_rows > 0) {
                while ($p = $products->fetch_assoc()) {
                    $qty = $_SESSION['cart'][$p['product_id']] ?? 0;

                    // Per-product pricing and discount
                    $mrp = (float)($p['mrp'] ?? 0);
                    $price = (float)($p['price'] ?? 0);
                    $discount = 0;
                    if ($mrp > 0 && $mrp > $price) {
                        $discount = (int) round((($mrp - $price) / $mrp) * 100);
                    }

                    // Get first image from product_images
                    $firstImage = 'no-image.png';
                    if (!empty($p['images'])) {
                        $images = explode(',', $p['images']);
                        $firstImage = $images[0];
                    }
            ?>
                    <div class="card">
                        <img src="assets/images/products/<?= htmlspecialchars($firstImage); ?>" alt="<?= htmlspecialchars($p['product_name']); ?>" onerror="this.src='assets/images/no-image.png'">

                        <h4>
                            <a href="product.php?id=<?= $p['product_id']; ?>" style="text-decoration:none;color:#000">
                                <?= $p['product_name']; ?>
                            </a>
                        </h4>
                        <div class="price">₹<?= number_format($price, 2) ?></div>
                        <?php if ($discount > 0): ?>
                            <!-- <div class="discount-badge">-<?= $discount ?>%</div> -->
                            <div class="mrp"> <s>₹<?= number_format($mrp, 2) ?></s> </div>
                        <?php endif; ?>

                        <p class="short-desc"><?= htmlspecialchars($p['short_description'] ?? '') ?></p>
                        <?php $saveAmount = $mrp ? round($mrp - $price, 2) : 0;
                        if ($saveAmount > 0) {
                            echo "<div class='save'>You save ₹" . number_format($saveAmount, 2) . " ({$discount}%)</div>";
                        } ?>
                        <p>
                            <?= $p['stock_qty'] > 0 ? "<span style='color:green'>In Stock</span>" : "<span style='color:red'>Out of Stock</span>" ?>
                        </p>

                        <?php if ($p['stock_qty'] > 0) { ?>
                            <div class="cart-controls">
                                <button onclick="updateCart(<?= $p['product_id'] ?>, 'minus')">−</button>
                                <strong id="qty-<?= $p['product_id'] ?>"><?= $qty ?></strong>
                                <button onclick="updateCart(<?= $p['product_id'] ?>, 'plus', <?= $p['stock_qty'] ?>)">+</button>

                            </div>
                        <?php } else { ?>
                            <button disabled>Out of Stock</button>
                        <?php } ?>
                    </div>
                <?php }
            } else { ?>
                <p>No products found.</p>
            <?php } ?>

        </div>
    </div>

</body>
<script>
    function updateCart(productId, action, stockQty = 0) {

        const qtyEl = document.getElementById('qty-' + productId);
        const currentQty = parseInt(qtyEl.textContent);

        if (action === 'plus') {

            const allowed = Math.min(6, stockQty);

            if (currentQty >= allowed) {
                alert("Only " + allowed + " items allowed.");
                return;
            }
        }

        fetch('products.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `product_id=${productId}&cart_action=${action}`
            })
            .then(response => response.json())
            .then(data => {
                if (data && data.success) {
                    const qtyEl = document.getElementById('qty-' + productId);
                    if (qtyEl) qtyEl.textContent = data.qty;
                    const cartEl = document.getElementById('cart-count');
                    if (cartEl) cartEl.textContent = data.cartCount;
                } else if (data.message) {
                    // Show the limit message from server
                    alert(data.message);
                } else {
                    location.reload();
                }
            })
            .catch(() => location.reload());
    }
</script>

</html>